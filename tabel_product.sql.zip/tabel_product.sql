-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2021 at 11:32 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inilhoit_2021`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_product`
--

CREATE TABLE `tabel_product` (
  `id` int(11) NOT NULL,
  `product` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `category` varchar(128) NOT NULL,
  `code` varchar(50) NOT NULL,
  `catalog` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_product`
--

INSERT INTO `tabel_product` (`id`, `product`, `price`, `category`, `code`, `catalog`) VALUES
(31, 'Kampoes Perdjoeangan', '140000', 'Hoodie', 'HD-01', 'hd01-front.png'),
(32, 'Arek ITS Cak', '140000', 'Hoodie', 'HD-02', 'hd02-front.png'),
(33, 'Arek ITS Cak', '90000', 'T-Shirt', 'TS-01', 'ts01-front.png'),
(34, 'Vivat 10 Nop', '90000', 'T-Shirt', 'TS-02', 'ts02-front.png'),
(35, 'Future Engineer (Black)', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-01', 'ts-tdye-01.png'),
(36, 'Future Engineer (Purple)', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-02', 'ts-tdye-02.png'),
(37, 'Future Engineer (Blue)', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-03', 'ts-tdye-03.png'),
(38, 'Stay Up Late', '55000', 'Totebag', 'TB-01', 'tb01.png'),
(39, '(Snooze) Sleep', '55000', 'Totebag', 'TB-02', 'tb02.png'),
(40, 'Tie Die World Class Engineer', '55000', 'Totebag', 'TB-TDYE-01', 'tb-tdye-01.png'),
(41, '1957 ITS Robot', '15000', 'Keychain', 'KC-01', 'kc01.png'),
(42, 'Attention Please', '15000', 'Keychain', 'KC-02', 'kc02.png'),
(43, 'Your Future Engineer', '15000', 'Keychain', 'KC-03', 'kc03.png'),
(44, '10 Nopember', '15000', 'Gelang', 'RB-01', 'rb01.jpg'),
(45, 'World Class Engineer', '15000', 'Gelang', 'RB-02', 'rb02.jpg'),
(46, 'World Class Engineer', '15000', 'Lanyard', 'LY-01', 'ly01.jpg'),
(47, '8 in 1 Collection', '20000', 'Stiker', 'SB-01', 'stickerpack.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_product`
--
ALTER TABLE `tabel_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_product`
--
ALTER TABLE `tabel_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
