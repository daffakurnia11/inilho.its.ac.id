-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2021 at 11:09 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inilhoit_2021`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_order`
--

CREATE TABLE `data_order` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `province` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal` varchar(10) NOT NULL,
  `courier` varchar(10) NOT NULL,
  `package` varchar(25) NOT NULL,
  `weight` int(12) NOT NULL,
  `shipping` int(12) NOT NULL,
  `subtotal` int(12) NOT NULL,
  `referral` varchar(128) DEFAULT NULL,
  `total` int(12) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_order`
--

INSERT INTO `data_order` (`id`, `no_order`, `receiver`, `phone`, `address`, `province`, `city`, `postal`, `courier`, `package`, `weight`, `shipping`, `subtotal`, `referral`, `total`, `status`) VALUES
(40, '30012021-864', 'Daffa Kurnia Fatah', '085156317473', 'Buduran', 'Jawa Timur', 'Sidoarjo', '61252', 'jne', 'CTCYES', 1400, 20000, 324000, 'ilitsxsidoarjo', 182000, 'Belum Bayar');

-- --------------------------------------------------------

--
-- Table structure for table `data_store`
--

CREATE TABLE `data_store` (
  `id` int(11) NOT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` int(50) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_store`
--

INSERT INTO `data_store` (`id`, `sender`, `address`, `city`, `phone`) VALUES
(1, 'Daffa Kurnia Fatah', 'Perum. Gading Fajar 1 B6/21 RT/RW 19/05 Desa Siwalan Panji, Buduran, Sidoarjo, Jawa Timur', 444, '085156317473');

-- --------------------------------------------------------

--
-- Table structure for table `order_bundle`
--

CREATE TABLE `order_bundle` (
  `id` int(11) NOT NULL,
  `no_order` varchar(50) NOT NULL,
  `product_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `bundle` varchar(256) NOT NULL,
  `size` varchar(10) DEFAULT NULL,
  `hoodie` varchar(128) DEFAULT NULL,
  `tshirt` varchar(128) DEFAULT NULL,
  `totebag` varchar(128) DEFAULT NULL,
  `cap` varchar(128) DEFAULT NULL,
  `keychain` varchar(128) DEFAULT NULL,
  `bracelet` varchar(128) DEFAULT NULL,
  `lanyard` varchar(128) DEFAULT NULL,
  `stickerbook` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_bundle`
--

INSERT INTO `order_bundle` (`id`, `no_order`, `product_id`, `qty`, `bundle`, `size`, `hoodie`, `tshirt`, `totebag`, `cap`, `keychain`, `bracelet`, `lanyard`, `stickerbook`) VALUES
(5, '30012021-864', 8, 1, 'Bundle Peach Pack', 'L', NULL, NULL, NULL, 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `product_id` int(8) NOT NULL,
  `notes` text DEFAULT NULL,
  `product` varchar(256) NOT NULL,
  `qty` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `no_order`, `product_id`, `notes`, `product`, `qty`) VALUES
(75, '30012021-864', 32, 'L', 'Hoodie Arek ITS Cak', 1),
(76, '30012021-864', 34, 'M', 'T-Shirt Vivat 10 Nop', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_bundle`
--

CREATE TABLE `tabel_bundle` (
  `id` int(11) NOT NULL,
  `product` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `hoodie` int(11) DEFAULT NULL,
  `shirt` int(11) DEFAULT NULL,
  `totebag` int(11) DEFAULT NULL,
  `cap` int(11) DEFAULT NULL,
  `keychain` int(11) DEFAULT NULL,
  `bracelet` int(11) DEFAULT NULL,
  `lanyard` int(11) DEFAULT NULL,
  `stickerbook` int(11) DEFAULT NULL,
  `data-target` varchar(128) NOT NULL,
  `weight` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_bundle`
--

INSERT INTO `tabel_bundle` (`id`, `product`, `price`, `hoodie`, `shirt`, `totebag`, `cap`, `keychain`, `bracelet`, `lanyard`, `stickerbook`, `data-target`, `weight`) VALUES
(1, 'Red Pack', '229000', NULL, 1, 1, 1, 1, 1, 1, 1, 'red-pack', 1000),
(2, 'Orange Pack', '199000', NULL, 1, 1, NULL, 1, 1, 1, 1, 'orange-pack', 1000),
(3, 'Yellow Pack', '149000', NULL, NULL, 1, 1, 1, 1, NULL, 1, 'yellow-pack', 1000),
(4, 'Green Pack', '149000', NULL, 1, NULL, NULL, 1, 1, 1, 1, 'green-pack', 1000),
(5, 'Blue Pack', '285000', 1, NULL, 1, 1, 1, 1, 1, 1, 'blue-pack', 1000),
(6, 'Purple Pack', '249000', 1, NULL, 1, NULL, 1, 1, 1, 1, 'purple-pack', 1000),
(7, 'Lylac Pack', '185000', 1, NULL, NULL, NULL, 1, 1, 1, 1, 'lylac-pack', 1000),
(8, 'Peach Pack', '94000', NULL, NULL, NULL, 1, 1, 1, 1, 1, 'peach-pack', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_images`
--

CREATE TABLE `tabel_images` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `image` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_images`
--

INSERT INTO `tabel_images` (`id`, `code`, `image`) VALUES
(1, 'HD-01', 'hd01-front.png'),
(2, 'HD-01', 'hd01-back.png'),
(4, 'HD-02', 'hd02-front.png'),
(5, 'HD-02', 'hd02-back.png'),
(6, 'TS-01', 'ts01-front.png'),
(7, 'TS-01', 'ts01-back.png'),
(8, 'TS-02', 'ts02-front.png'),
(9, 'TS-02', 'ts02-back.png'),
(10, 'TS-TDYE-01', 'ts-tdye-01.png'),
(11, 'TS-TDYE-02', 'ts-tdye-02.png'),
(12, 'TS-TDYE-03', 'ts-tdye-03.png'),
(13, 'TB-01', 'tb01.png'),
(14, 'TB-02', 'tb02.png'),
(15, 'TB-TDYE-01', 'tb-tdye-01.png'),
(16, 'KC-01', 'kc01.png'),
(17, 'KC-02', 'kc02.png'),
(18, 'KC-03', 'kc03.png'),
(19, 'RB-01', 'rb01.jpg'),
(20, 'RB-02', 'rb02.jpg'),
(21, 'LY-01', 'ly01.jpg'),
(22, 'SB-01', 'stickerpack.png'),
(23, 'DC-01', 'dc01.jpg'),
(24, 'DC-02', 'dc02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_product`
--

CREATE TABLE `tabel_product` (
  `id` int(11) NOT NULL,
  `product` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `category` varchar(128) NOT NULL,
  `code` varchar(50) NOT NULL,
  `catalog` varchar(128) NOT NULL,
  `weight` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_product`
--

INSERT INTO `tabel_product` (`id`, `product`, `price`, `category`, `code`, `catalog`, `weight`) VALUES
(31, 'Kampoes Perdjoeangan', '140000', 'Hoodie', 'HD-01', 'hd01-front.png', 200),
(32, 'Arek ITS Cak', '140000', 'Hoodie', 'HD-02', 'hd02-front.png', 200),
(33, 'Arek ITS Cak', '90000', 'T-Shirt', 'TS-01', 'ts01-front.png', 200),
(34, 'Vivat 10 Nop', '90000', 'T-Shirt', 'TS-02', 'ts02-front.png', 200),
(35, 'Future Engineer Black', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-01', 'ts-tdye-01.png', 200),
(36, 'Future Engineer Purple', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-02', 'ts-tdye-02.png', 200),
(37, 'Future Engineer Blue', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-03', 'ts-tdye-03.png', 200),
(38, 'Stay Up Late', '55000', 'Totebag', 'TB-01', 'tb01.png', 200),
(39, 'Snooze or Sleep', '55000', 'Totebag', 'TB-02', 'tb02.png', 200),
(40, 'Tie Dye World Class Engineer', '55000', 'Totebag', 'TB-TDYE-01', 'tb-tdye-01.png', 200),
(41, '1957 ITS Robot', '15000', 'Keychain', 'KC-01', 'kc01.png', 200),
(42, 'Attention Please', '15000', 'Keychain', 'KC-02', 'kc02.png', 200),
(43, 'Your Future Engineer', '15000', 'Keychain', 'KC-03', 'kc03.png', 200),
(44, '10 Nopember', '15000', 'Gelang', 'RB-01', 'rb01.jpg', 200),
(45, 'World Class Engineer', '15000', 'Gelang', 'RB-02', 'rb02.jpg', 200),
(46, 'World Class Engineer', '15000', 'Lanyard', 'LY-01', 'ly01.jpg', 200),
(47, '8 in 1 Collection', '20000', 'Stiker', 'SB-01', 'stickerpack.png', 200),
(48, 'OG 10 Nop', '40000', 'Dad Cap', 'DC-01', 'dc01.jpg', 200),
(49, 'OG Logo White', '40000', 'Dad Cap', 'DC-02', 'dc02.jpg', 200);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_referral`
--

CREATE TABLE `tabel_referral` (
  `id` int(11) NOT NULL,
  `code` varchar(128) DEFAULT NULL,
  `forda` varchar(128) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_referral`
--

INSERT INTO `tabel_referral` (`id`, `code`, `forda`, `discount`) VALUES
(1, 'ILITSxSIDOARJO', 'Sidoarjo', 50),
(3, 'ILITSxGRESIK', 'Gresik', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_order`
--
ALTER TABLE `data_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_store`
--
ALTER TABLE `data_store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_bundle`
--
ALTER TABLE `order_bundle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_bundle`
--
ALTER TABLE `tabel_bundle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_images`
--
ALTER TABLE `tabel_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_product`
--
ALTER TABLE `tabel_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_referral`
--
ALTER TABLE `tabel_referral`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_order`
--
ALTER TABLE `data_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `data_store`
--
ALTER TABLE `data_store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_bundle`
--
ALTER TABLE `order_bundle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `tabel_bundle`
--
ALTER TABLE `tabel_bundle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tabel_images`
--
ALTER TABLE `tabel_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tabel_product`
--
ALTER TABLE `tabel_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tabel_referral`
--
ALTER TABLE `tabel_referral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
