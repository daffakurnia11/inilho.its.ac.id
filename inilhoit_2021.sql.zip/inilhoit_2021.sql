-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 27, 2021 at 08:45 AM
-- Server version: 5.6.51
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inilhoit_2021`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_order`
--

CREATE TABLE `data_order` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `province` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal` varchar(10) NOT NULL,
  `courier` varchar(10) NOT NULL,
  `package` varchar(25) NOT NULL,
  `weight` int(12) NOT NULL,
  `shipping` int(12) NOT NULL,
  `subtotal` int(12) NOT NULL,
  `referral` varchar(128) DEFAULT NULL,
  `bonus` varchar(128) DEFAULT NULL,
  `total` int(12) NOT NULL,
  `status` varchar(50) NOT NULL,
  `transfer` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_order`
--

INSERT INTO `data_order` (`id`, `no_order`, `receiver`, `phone`, `address`, `province`, `city`, `postal`, `courier`, `package`, `weight`, `shipping`, `subtotal`, `referral`, `bonus`, `total`, `status`, `transfer`) VALUES
(1, '05022021-607', 'Alia Dewi Kartika', '6281231071334', 'Jalan Raya Bringkang no 127, Menganti, Gresik, Jawa Timur 61174 (depan perumahan taman Menganti emas/ UD Sumber rejeki)', 'Jawa Timur', 'Gresik', '61174', 'jne', 'REG', 2200, 16000, 458000, NULL, NULL, 474000, 'Sudah Upload', '05022021-607_image.jpg'),
(2, '05022021-941', 'Abdul Aziz Ardiansyah', '6281298941671', 'Jln. Gunung Halimun Blok H-115 Komplek Mabad Rempoa Kota Tangerang Selatan- Ciputat Timur', 'Banten', 'Tangerang Selatan', '15412', 'jne', 'REG', 600, 18000, 94000, NULL, NULL, 112000, 'Sudah Upload', '05022021-941_image.png'),
(4, '05022021-372', 'Cinta Rinandyta', '6289687317881', 'Jalan Plemahan XI No. 35 D, RT 006, RW 009, Kelurahan Kedungdoro, Kecamatan Tegalsari, Kota Surabaya, Provinsi Jawa Timur, Kode Pos 60261', 'Jawa Timur', 'Surabaya', '60261', 'jne', 'CTCYES', 100, 10000, 15000, NULL, NULL, 25000, 'Sudah Upload', '05022021-372_image.jpg'),
(5, '05022021-591', 'Osha Aguisti', '6281294429206', 'Perumahan pondok kopi blok R 10/8 RT 003 RW 007 Duren sawit', 'DKI Jakarta', 'Jakarta Timur', '13460', 'jne', 'OKE', 250, 12000, 90000, NULL, NULL, 102000, 'Sudah Upload', '05022021-591_image.jpg'),
(6, '05022021-237', 'Ardito Ghulam Nugraha', '6285971713118', 'Jalan Pusri No. 33 RT05/RW10 Balun Kandangdoro, Kec.Cepu', 'Jawa Tengah', 'Blora', '58311', 'jne', 'REG', 500, 23000, 140000, NULL, NULL, 163000, 'Sudah Upload', '05022021-237_image.jpg'),
(7, '05022021-419', 'Aina Jabrail Zahrawani', '6281703874676', 'Western village blok b5 no 8, Kel.Sememi, Kec.Benowo', 'Jawa Timur', 'Surabaya', '60198', 'jne', 'CTC', 600, 7000, 94000, NULL, NULL, 101000, 'Sudah Upload', '05022021-419_image.jpg'),
(9, '05022021-603', 'Edgarrafi', '6282229621877', 'Puri Sewon Asri Blok D20, Panggungharjo, Sewon, Bantul Regency, Jogja, 55188', 'DI Yogyakarta', 'Bantul', '55188', 'jne', 'REG', 300, 15000, 75000, 'ILITSxJOGJA', 'Gelang/Stiker', 90000, 'Sudah Upload', '05022021-603_image.jpg'),
(11, '06022021-812', 'Sarah Pontoh', '6282170989311', 'Jalan Pemuda, Komplek Sari Residence Blok B7 no. 10, Kel. Tirtasiak, Kec. Payung Sekaki', 'Riau', 'Pekanbaru', '28292', 'jne', 'OKE', 900, 46000, 180000, NULL, NULL, 226000, 'Sudah Upload', '06022021-812_image.jpg'),
(12, '06022021-806', 'Aditya Bayhaqi', '6287788907377', 'Apartemen Kalibata City Tower Damar Unit D05CS', 'DKI Jakarta', 'Jakarta Selatan', '12750', 'jne', 'OKE', 200, 12000, 40000, NULL, NULL, 52000, 'Sudah Upload', '06022021-806_image.jpg'),
(14, '06022021-358', 'Nathanael Yoan Putra Lazarus', '6282112723565', 'Viscany Residence Blok E19, Jalan Raya Boulevard Grand Depok City, Kalimulya, Cilodong, Depok', 'Jawa Barat', 'Depok', '16413', 'jne', 'OKE', 250, 15000, 90000, NULL, NULL, 105000, 'Sudah Upload', NULL),
(15, '07022021-701', 'Tegar Isnain Muharram', '6282334823132', 'Jalan Raya Nyalaran nomor 207 Pamekasan', 'Jawa Timur', 'Pamekasan', '69314', 'jne', 'REG', 850, 8000, 199000, NULL, NULL, 207000, 'Sudah Upload', '07022021-701_image.jpg'),
(18, '07022021-938', 'Samuel Bagas', '6281392473907', 'Jl. Lantana 1 Blok D1 No.1, Sepanjang Jaya, Rawalumbu, Kota Bekasi, 17114', 'Jawa Barat', 'Bekasi', '17114', 'pos', 'Express Next Day Barang', 500, 26000, 180000, NULL, NULL, 206000, 'Sudah Upload', '07022021-938_image.jpg'),
(20, '07022021-749', 'Rama', '6282312026838', 'Jalan Jati Padang Raya, No.51B, RT 04, RW 09, Jati Padang, Pasar Minggu, Jakarta Selatan, DKI Jakarta, 12540', 'DKI Jakarta', 'Jakarta Selatan', '12540', 'jne', 'OKE', 1050, 12000, 350000, NULL, NULL, 362000, 'Sudah Upload', '07022021-749_image.jpg'),
(22, '07022021-804', 'Josefino Eleonard Widodo', '62895364479447', 'Jalan Kober Pedati no 15A, RT06 RW02, Jatinegara, JakartaTimur', 'DKI Jakarta', 'Jakarta Timur', '13310', 'jne', 'REG', 600, 15000, 94000, NULL, NULL, 109000, 'Sudah Upload', '07022021-804_image.jpg'),
(23, '07022021-074', 'Putu Nadya Iswaridewi', '6285237356012', 'Jalan Pulau Kawe no. 44', 'Bali', 'Denpasar', '80114', 'jne', 'REG', 300, 20000, 50000, NULL, NULL, 70000, 'Sudah Upload', '07022021-074_image.jpg'),
(24, '07022021-157', 'krishna', '628111691198', 'JALAN TAMAN MALAKA UTARA 2B BLOK C8 NOMOR 20A', 'DKI Jakarta', 'Jakarta Timur', '13460', 'tiki', 'REG', 300, 15000, 55000, 'ILITSxJAKARTA', 'Gelang/Stiker', 70000, 'Sudah Upload', '07022021-157_image.jpg'),
(26, '08022021-948', 'DHILA PRITHA AMALIA', '6281350084960', 'JL GAJAH MADA 108 KEC.REMBANG KAB.REMBANG JAWA TENGAH', 'Jawa Tengah', 'Rembang', '59213', 'jne', 'REG', 750, 23000, 164000, 'ILITSXSEMARANG', 'Gelang/Stiker', 187000, 'Sudah Upload', '08022021-948_image.jpg'),
(28, '08022021-945', 'yus ardliyah', '6285156830202', 'Jalan Pandean Gg. 5 No. 66, Kelurahan Ngingas, Kecamatan Waru, Kabupaten Sidoarjo, Jawa Timur (pojok, cat kuning)\r\n61256', 'Jawa Timur', 'Sidoarjo', '61256', 'pos', 'Paket Kilat Khusus', 100, 7000, 15000, 'ILITSxSIDOARJO', 'Gelang/Stiker', 22000, 'Sudah Upload', '08022021-945_image.jpg'),
(30, '08022021-738', 'Fariza Hasna Mahdiyah', '6285748928166', 'Jalan K.H Kasan Besari no 41', 'Jawa Timur', 'Ponorogo', '63414', 'jne', 'REG', 250, 8000, 90000, NULL, NULL, 98000, 'Sudah Upload', '08022021-738_image.jpg'),
(31, '08022021-197', 'Edwin Selanjaya', '6283856676117', 'WARKOP KEBANGSAAN, JL. Simo Magerejo 14 No. 1, Simomulyo, Sukomanunggal', 'Jawa Timur', 'Surabaya', '60181', 'jne', 'CTCYES', 900, 10000, 185000, NULL, NULL, 195000, 'Sudah Upload', '08022021-197_image.jpg'),
(32, '08022021-387', 'Fidah', '6282255297709', 'Permata jingga blok AA no. 16, Kota Malang', 'Jawa Timur', 'Malang', '65143', 'tiki', 'ECO', 200, 6000, 60000, NULL, NULL, 66000, 'Sudah Upload', NULL),
(33, '08022021-982', 'Rheza Naufal Aflah Zakaria', '6281216613529', 'Jl. Candi Mendut Selatan No. 28 Malang', 'Jawa Timur', 'Malang', '65141', 'jne', 'YES', 500, 14000, 140000, NULL, NULL, 154000, 'Sudah Upload', '08022021-982_image.jpg'),
(34, '08022021-378', 'Nawfal Pramudya', '6287855854114', 'Jl. Medokan Baru III/3 Perum Griya Semampir Surabaya', 'Jawa Timur', 'Surabaya', '60119', 'jne', 'CTC', 750, 7000, 230000, 'ILITSxTangerang', 'Gelang/Stiker', 237000, 'Sudah Upload', '08022021-378_image.jpg'),
(37, '09022021-307', 'Ailsashofa Alfadhila', '6285708660675', 'Jl. Budi Utomo No.11D, RT03 RW03, Ronowijayan, Siman, Ponorogo, Jawa Timur', 'Jawa Timur', 'Ponorogo', '63471', 'jne', 'OKE', 450, 7000, 150000, NULL, NULL, 157000, 'Sudah Upload', '09022021-307_image.jpg'),
(42, '09022021-783', 'Reyhan Aditya', '6282233917112', 'Wonocolo 2/29 RT. 2 RW. 4', 'Jawa Timur', 'Surabaya', '60237', 'tiki', 'ECO', 400, 4000, 90000, 'ILITSxSIDOARJO', 'Gelang/Stiker', 94000, 'Sudah Upload', '09022021-783_image.jpg'),
(43, '10022021-235', 'Vian Setya', '6285649281940', 'Dsn. Kembang sore RT 2 RW 2 Ds. Terung Kulon Kec. Krian Kab. Sidoarjo', 'Jawa Timur', 'Sidoarjo', '61262', 'jne', 'CTC', 750, 7000, 230000, NULL, NULL, 237000, 'Sudah Upload', '10022021-235_image.jpg'),
(44, '10022021-978', 'Jasinda Wijdannysa', '6285101591455', 'Bapak Supriyadi Guru, RT 11 RW 03, Kelurahan Takeran, Kecamatan Takeran, Kabupaten Magetan, Jawa Timur', 'Jawa Timur', 'Magetan', '63383', 'jne', 'OKE', 500, 7000, 85000, 'ILITSxMADIUN', 'Gelang/Stiker', 92000, 'Sudah Upload', '10022021-978_image.jpg'),
(49, '10022021-935', 'Bastian Sitompul', '6281326660266', 'Jalan Edelweis 8, RT/RW 4/5, Perumahan Limbangan Baru', 'Jawa Tengah', 'Banjarnegara', '53413', 'jne', 'OKE', 550, 16000, 135000, 'AKUMASUKITS', '3 Stiker ', 151000, 'Sudah Upload', '10022021-935_image.jpg'),
(51, '10022021-103', 'Amanda Palupi Estiningtyas', '6281385594175', 'Taman Kutabumi Blok C12 No. 13, Jalan Mawar Selatan, Kelurahan Kutabumi, Kecamatan Pasar Kemis, Kabupaten Tangerang, Banten', 'Banten', 'Tangerang', '15560', 'pos', 'Paket Kilat Khusus', 200, 14000, 35000, 'ILITSxTANGERANG', 'Gelang/Stiker', 49000, 'Sudah Upload', '10022021-103_image.jpg'),
(52, '10022021-480', 'Muhammad Thoriq Isman', '6281977484901', 'Jl Raden  Fatah gg Haji lecang no 77b rt 03 rw 06 Sudimara barat, Ciledug, Tangerang', 'Banten', 'Tangerang', '15151', 'jne', 'REG', 450, 18000, 130000, NULL, NULL, 148000, 'Sudah Upload', NULL),
(53, '10022021-573', 'Gabriela Rintai Sendini Karubaba', '6282135303740', 'Jl. Makam Keputih No 10 Blok C, kecamatan Sukolilo, kota Surabaya', 'Jawa Timur', 'Surabaya', '60119', 'jne', 'CTC', 450, 7000, 135000, NULL, NULL, 142000, 'Sudah Upload', '10022021-573_image.jpg'),
(56, '10022021-078', 'adiwira surya susanto', '6281381451739', 'Banten, Tangerang Selatan, Serpong, BSD City, Nusaloka, Jalan Kalimantan 2, Blok E6 no.9', 'Banten', 'Tangerang Selatan', '15321', 'jne', 'OKE', 700, 15000, 155000, 'ILITSXTANGERANG', 'Gelang/Stiker', 170000, 'Sudah Upload', '10022021-078_image.jpg'),
(57, '10022021-109', 'Ajeng Almira Tarisha Asri', '6281330038580', 'Sidosermo PDK IVB/128 Surabaya', 'Jawa Timur', 'Surabaya', '60239', 'tiki', 'ECO', 500, 4000, 140000, 'AKUMASUKITS', '3 Stiker ', 144000, 'Sudah Upload', '10022021-109_image.jpg'),
(58, '10022021-728', 'Awang Ganda Sausa', '6282299262130', 'Perumahan Bumimas 1 Blok L no 4', 'Jawa Timur', 'Madiun', '63139', 'tiki', 'ONS', 2000, 30000, 640000, 'AKUMASUKITS', '3 Stiker ', 670000, 'Sudah Upload', '10022021-728_image.jpg'),
(59, '10022021-834', 'Agung Handayanto', '6281235544301', 'Kebraon Indah Permai Blok E No. 30, RT 04, RW 13, Kelurahan Kebraon, Kecamatan Karang Pilang, Kota Surabaya, Jawa Timur, Kode pos 60222.', 'Jawa Timur', 'Surabaya', '60222', 'jne', 'CTC', 200, 7000, 30000, NULL, NULL, 37000, 'Sudah Upload', '10022021-834_image.jpg'),
(60, '11022021-107', 'Alifia', '6288809374547', 'Jl panca 7 rt14/001 serdang no 10D', 'DKI Jakarta', 'Jakarta Pusat', '10650', 'jne', 'REG', 100, 15000, 15000, 'ILITSxJAKARTA', 'Gelang/Stiker', 30000, 'Sudah Upload', '11022021-107_image.jpg'),
(63, '11022021-716', 'Fahrezi Tyas Bahtiar', '6289530377581', 'Jaya Regency AH-24', 'Jawa Timur', 'Sidoarjo', '61253', 'jne', 'CTCYES', 500, 10000, 140000, 'AKUMASUKits', '3 Stiker ', 150000, 'Sudah Upload', '11022021-716_image.jpg'),
(64, '11022021-532', 'Sulthan Rafly', '6281283918480', 'Jln. Kemang Dahlia Raya Blok AK 38, Kemang Pratama 2', 'Jawa Barat', 'Bekasi', '17116', 'jne', 'REG', 200, 18000, 60000, NULL, NULL, 78000, 'Sudah Upload', '11022021-532_image.jpg'),
(65, '11022021-859', 'Muhammad Baihaqy Abdurrahim', '6285233211433', 'Jl. Batoro Katong no. 180 kertosari, Babadan, Ponorogo', 'Jawa Timur', 'Ponorogo', '63491', 'jne', 'REG', 250, 8000, 90000, 'AKUMASUKITS', '3 Stiker ', 98000, 'Sudah Upload', '11022021-859_image.jpg'),
(66, '12022021-296', 'Kevin Arnandes', '6281325242065', 'jl. saubari no. 71 jetis lor parakan kauaman\r\nKAB. TEMANGGUNG - PARAKAN\r\nJAWA TENGAH\r\nID 56254', 'Jawa Tengah', 'Temanggung', '56254', 'jne', 'OKE', 200, 16000, 35000, NULL, NULL, 51000, 'Sudah Upload', '12022021-296_image.jpg'),
(68, '12022021-648', 'Denise', '628113111910', 'Alamat lengkap : Ry. darmo permai utara no 72 (sblh radio sonora)\r\nKelurahan : pradah\r\nKecamatan : dukuh pakis\r\nKota / Kab : Surabaya', 'Jawa Timur', 'Surabaya', '60226', 'jne', 'CTCYES', 200, 10000, 35000, NULL, NULL, 45000, 'Sudah Upload', '12022021-648_image.jpg'),
(69, '12022021-037', 'Erlangga Putra', '6282104072002', 'Kantor Pos Pasinan , Jalan raya pasinan Rt 10 Rw 03 Kecamatan Wringinanom Kab. Gresik', 'Jawa Timur', 'Gresik', '61176', 'pos', 'Express Next Day Barang', 900, 10000, 185000, 'AKUMASUKITS', '3 Stiker ', 195000, 'Sudah Upload', '12022021-037_image.jpg'),
(71, '13022021-543', 'Kayla Ari Sophie Kencana', '6281333901414', 'PRIMUSS SUMBER JAYA FURNITURE AND ART\r\nKramat RT 02/ RW 07 Trangsan, Gatak, Sukoharjo, Jawa Tengah\r\n57557', 'Jawa Tengah', 'Sukoharjo', '57557', 'pos', 'Paket Kilat Khusus', 250, 14000, 90000, NULL, NULL, 104000, 'Sudah Upload', '13022021-543_image.jpg'),
(72, '13022021-432', 'Daffa Kurnia Fatah', '6285156317473', 'AMBIL SENDIRI', 'Jawa Timur', 'Surabaya', '61252', 'jne', 'CTC', 500, 0, 180000, 'BuatDaffa', '150000', 30000, 'Sudah Upload', '13022021-432_image.jpg'),
(73, '13022021-590', 'Annisa Septyana Ningrum', '6282247544818', 'AMBIL SENDIRI', 'Jawa Timur', 'Surabaya', '61252', 'jne', 'CTC', 1100, 0, 229000, NULL, NULL, 229000, 'Sudah Upload', '13022021-590_image.jpg'),
(74, '13022021-481', 'Ilma Fahma Syadidah', '6281286092002', 'Komplek Metro Cilegon Mediterania Blok B7 No. 3', 'Banten', 'Cilegon', '42412', 'jne', 'REG', 400, 20000, 70000, 'ILITSxBANTEN', 'Gelang/Stiker', 90000, 'Sudah Upload', '13022021-481_image.jpg'),
(75, '14022021-761', 'Nugraha Akbar Nurhakim', '6287855431437', 'Perum Griya Permata Alam Blok IC No. 13 Desa Ngijo Kecamatan Karangploso', 'Jawa Timur', 'Malang', '65152', 'jne', 'OKE', 1300, 7000, 385000, NULL, NULL, 392000, 'Sudah Upload', '14022021-761_image.jpg'),
(77, '15022021-042', 'Marissa Naomi', '62895705878430', 'Jalan Wonokromo Tengah 8 no 12a', 'Jawa Timur', 'Surabaya', '60243', 'jne', 'CTC', 250, 7000, 90000, NULL, NULL, 97000, 'Sudah Upload', '15022021-042_image.jpg'),
(78, '15022021-826', 'Akbar Zaidan', '6285648266154', 'Jl. Madyopuro, Perumahan Griya Santika, No.4', 'Jawa Timur', 'Malang', '65138', 'jne', 'REG', 600, 8000, 94000, NULL, NULL, 102000, 'Sudah Upload', '15022021-826_image.jpg'),
(79, '15022021-023', 'Muhammad Birawa Balapati', '6281994932044', 'Lorong Slamet Riadi No.034, RT.005/RW.001, Kelurahan Bukit Sangkal, Kecamatan Kalidoni', 'Sumatera Selatan', 'Palembang', '30114', 'jne', 'OKE', 750, 36000, 210000, NULL, NULL, 246000, 'Sudah Upload', '15022021-023_image.jpg'),
(80, '15022021-876', 'Afif Muhammad Zarir Fatadina', '62081318939259', 'Perumahan Indah Kirana Residence, Blok A 14, Jalan Sukahati, Sukahati, Cibinong, Kabupaten Bogor, Jawa Barat (Dekat Gudang Walls)', 'Jawa Barat', 'Bogor', '16913', 'jne', 'REG', 500, 18000, 140000, NULL, NULL, 158000, 'Sudah Upload', '15022021-876_image.jpg'),
(81, '16022021-590', 'Andania', '6285746355594', 'Tenggulunan, rt 03 rw 01 no.4', 'Jawa Timur', 'Sidoarjo', '61271', 'jne', 'CTCYES', 700, 10000, 175000, NULL, NULL, 185000, 'Sudah Upload', '16022021-590_image.jpg'),
(82, '16022021-461', 'Olivia Natasa', '6281316870074', 'Alamat Rumah.\r\nJalan BANYO 2 Blok B5 No.1.\r\nRt08/RW 08.\r\nPegangsaandua.Kelapa Gading.Jakarta Utara.14250', 'DKI Jakarta', 'Jakarta Utara', '14250', 'jne', 'REG', 650, 15000, 149000, NULL, NULL, 164000, 'Sudah Upload', '16022021-461_image.jpg'),
(83, '16022021-527', 'Dehan', '6285156718018', 'Jl. Kebon Kelapa Rt.13/09 No.05 Utan Kayu Selatan, Matraman, Jakarta Timur', 'DKI Jakarta', 'Jakarta Timur', '13220', 'jne', 'OKE', 650, 12000, 149000, NULL, NULL, 161000, 'Sudah Upload', '16022021-527_image.jpg'),
(84, '16022021-530', 'Adam Daiva Syahputra', '6281334273250', 'Perum Mutiara Pratama Blok B-03 Berkoh, Purwokerto Selatan, Jawa Tengah 53146', 'Jawa Tengah', 'Banyumas', '53146', 'tiki', 'ONS', 850, 24000, 189000, NULL, NULL, 213000, 'Sudah Upload', '16022021-530_image.jpg'),
(85, '16022021-507', 'Ananta Rafi', '6281247438054', 'Perumahan Amarapura Blok B4/24, Kademangan, Setu', 'Banten', 'Tangerang Selatan', '15314', 'jne', 'REG', 900, 18000, 185000, NULL, NULL, 203000, 'Sudah Upload', '16022021-507_image.jpg'),
(86, '16022021-907', 'Farhan arief w', '6281235241904', 'Diambil', 'Jawa Timur', 'Surabaya', '60233', 'jne', 'CTCYES', 200, 10000, 35000, NULL, NULL, 45000, 'Sudah Upload', '16022021-907_image.jpg'),
(88, '16022021-625', 'Nurlia Febriyanti', '6282197629801', 'Jln Makam Keputih No 10 Blok C, kecamatan Sukolilo, kota Surabaya, kode pos 60119', 'Jawa Timur', 'Surabaya', '60119', 'jne', 'CTC', 1100, 7000, 229000, NULL, NULL, 236000, 'Sudah Upload', '16022021-625_image.jpg'),
(89, '17022021-685', 'Fawwaz Akmal Syafiq', '6288299277377', 'Jl. Kp. Baru Timur Rt 01/09 (Gang Muslim) Cikampek Utara, Kotabaru, Karawang, Jawa Barat 41374', 'Jawa Barat', 'Karawang', '41374', 'jne', 'OKE', 850, 17000, 185000, NULL, NULL, 202000, 'Sudah Upload', '17022021-685_image.jpg'),
(90, '17022021-016', 'Karina Endriana', '6285156245647', 'Rungkut Menanggal Harapan Blok O No.26', 'Jawa Timur', 'Surabaya', '60293', 'tiki', 'ONS', 650, 9000, 149000, NULL, NULL, 158000, 'Sudah Upload', '17022021-016_image.jpg'),
(91, '17022021-204', 'Hisyam Maulana Akbar', '6281217660168', 'Jl. Semarang No.92, Kel. Bubutan, Kec. Bubutan, Kota Surabaya, 60174', 'Jawa Timur', 'Surabaya', '60174', 'tiki', 'ONS', 200, 9000, 40000, NULL, NULL, 49000, 'Sudah Upload', NULL),
(92, '17022021-765', 'Febrian Abdan Husnan', '6285158289552', 'Jalan Gayung Kebonsari Timur no 29', 'Jawa Timur', 'Surabaya', '60235', 'jne', 'CTCYES', 450, 10000, 130000, NULL, NULL, 140000, 'Sudah Upload', '17022021-765_image.jpg'),
(94, '18022021-842', 'Admiral Yagi Al Ghifari', '6282233159296', 'Jl. Kertanegara, Perum. Kertanegara Regency No. D3, Karangploso, Kabupaten Malang. Kode pos 65152', 'Jawa Timur', 'Malang', '65152', 'jne', 'OKE', 300, 7000, 75000, 'ILITSxBONTANG', 'Gelang/Stiker', 82000, 'Sudah Upload', '18022021-842_image.jpg'),
(95, '18022021-569', 'M RESA AL FARIZI', '6281252889128', 'Vila Nusa Indah 2 blok DD 10 no 46. Bojong Kulur, Gunung Putri, Kab. Bogor', 'Jawa Barat', 'Bogor', '16969', 'jne', 'OKE', 650, 15000, 149000, NULL, NULL, 164000, 'Sudah Upload', '18022021-569_image.jpg'),
(96, '18022021-205', 'Tossan Ajie C', '6287755888219', 'Perumahan pln no 8 jalan menur pumpungan', 'Jawa Timur', 'Surabaya', '60118', 'jne', 'CTC', 600, 7000, 94000, NULL, NULL, 101000, 'Sudah Upload', '18022021-205_image.jpg'),
(97, '18022021-637', 'Bony Albert Vancius', '6282112105217', 'jalan setia mekar no 41 rt/rw 03/16 kedung gede. [deket perumahan bulog lewat dikit kalau dari arah rel , rumah lantai coklat model batu, pagar hitam rolingdoor hijau', 'Jawa Barat', 'Bekasi', '17510', 'jne', 'REG', 1100, 18000, 229000, 'ILITSXBEKASI', 'Gelang/Stiker', 247000, 'Sudah Upload', '18022021-637_image.jpg'),
(98, '18022021-547', 'faisal nur arif', '6285731109646', 'puri surya jaya, taman pasadena d5/02, gedangan, sidoarjo', 'Jawa Timur', 'Sidoarjo', '61254', 'jne', 'CTC', 700, 7000, 149000, NULL, NULL, 156000, 'Sudah Upload', NULL),
(99, '19022021-350', 'Pinkan Tanika Jelita', '6282334814534', 'Jalan Sadewo No.2 Desa Kepuh, Kecamatan Kertosono, Kabupaten Nganjuk, Jawa Timur', 'Jawa Timur', 'Nganjuk', '64315', 'jne', 'REG', 700, 8000, 200000, NULL, NULL, 208000, 'Sudah Upload', '19022021-350_image.jpg'),
(100, '19022021-930', 'Muhammad Fauzan Alfito', '6281336441353', 'Jalan Gang Makam No.14, Keputih, Surabaya (KOS PUTRA)', 'Jawa Timur', 'Surabaya', '60111', 'jne', 'CTC', 250, 7000, 90000, NULL, NULL, 97000, 'Sudah Upload', '19022021-930_image.jpg'),
(101, '20022021-926', 'Anfasa Aliffian', '6281932868250', 'Perumahan Bogor Raya Permai FA 5/15', 'Jawa Barat', 'Bogor', '16113', 'jne', 'OKE', 500, 15000, 95000, NULL, NULL, 110000, 'Sudah Upload', '20022021-926_image.jpg'),
(102, '20022021-218', 'Erawan Faqih Ibrahim', '6285770189734', 'Jl. Madrasah No.66 RT06/05 Kalibaru, Cilodong, Kota Depok', 'Jawa Barat', 'Depok', '16413', 'jne', 'REG', 650, 18000, 165000, 'ILITSxDepok', 'Gelang/Stiker', 183000, 'Sudah Upload', '20022021-218_image.jpg'),
(103, '20022021-195', 'Ranadea Muhamad Gunawan', '6285156035403', 'Jl Persahabatan IIA No. 54A, Kelapa Dua Wetan, Ciracas', 'DKI Jakarta', 'Jakarta Timur', '13730', 'jne', 'REG', 500, 15000, 140000, NULL, NULL, 155000, 'Sudah Upload', '20022021-195_image.jpg'),
(104, '20022021-018', 'RIYAN YULIADI SANTOSO', '6287805948467', 'Jalan. Gading 43, Dsn. Puhrejo, Ds. Sekoto, Kec. Badas, Kab. Kediri', 'Jawa Timur', 'Kediri', '64223', 'jne', 'REG', 200, 8000, 30000, 'ILITSxKEDIRI', 'Gelang/Stiker', 38000, 'Sudah Upload', '20022021-018_image.jpg'),
(107, '20022021-645', 'Adinda Suci Lestari', '6287857172746', 'Taman Pondok Jati T-8, Geluran, Taman, Sidoarjo, 61257', 'Jawa Timur', 'Sidoarjo', '61257', 'jne', 'CTC', 300, 7000, 75000, 'LASTMINUTE', '15000', 67000, 'Sudah Upload', '20022021-645_image.jpg'),
(109, '20022021-394', 'Muhammad Fuad Salim', '62081913926196', 'JL. SULTAN ABDUR RAHMAN GG7 No.2 Perum. Bumi Sumekar Asri', 'Jawa Timur', 'Sumenep', '69417', 'jne', 'REG', 1050, 12000, 290000, NULL, NULL, 302000, 'Sudah Upload', '20022021-394_image.jpg'),
(111, '20022021-631', 'Ardhea Yavanitta Putri', '6281342403010', 'Jl.MH. Thamrin Gg. Ngalimun No.34 kec. Bojonegoro kab. Bojonegoro', 'Jawa Timur', 'Bojonegoro', '62112', 'tiki', 'REG', 700, 10000, 150000, NULL, NULL, 160000, 'Sudah Upload', '20022021-631_image.jpg'),
(112, '20022021-780', 'Mohammad Fadhil Rasyidin Parinduri', '6285945943489', 'Jalan Perkici X Blok EA.9 No.10 Bintaro Jaya Sektor 5, Jurangmangu Timur, Pondok Aren, Kota Tangerang Selatan, Banten 15222', 'Banten', 'Tangerang Selatan', '15222', 'jne', 'REG', 900, 18000, 220000, 'LASTMINUTE', '15000', 223000, 'Sudah Upload', '20022021-780_image.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `data_store`
--

CREATE TABLE `data_store` (
  `id` int(11) NOT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(128) DEFAULT NULL,
  `city_id` int(50) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_store`
--

INSERT INTO `data_store` (`id`, `sender`, `address`, `city`, `city_id`, `phone`) VALUES
(1, 'Nabbil Gibran', 'Jl. ngagel tirto no.3\r\nkec. wonokromo/kel. ngagel rejo\r\n60245, surabaya', 'Surabaya', 444, '6282234666582');

-- --------------------------------------------------------

--
-- Table structure for table `merchandise_slider`
--

CREATE TABLE `merchandise_slider` (
  `id` int(11) NOT NULL,
  `nama_foto` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `merchandise_slider`
--

INSERT INTO `merchandise_slider` (`id`, `nama_foto`) VALUES
(1, 'slider_1.jpg'),
(2, 'slider_2.jpg'),
(3, 'slider_3.jpg'),
(4, 'slider_4.jpg'),
(5, 'slider_5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_bundle`
--

CREATE TABLE `order_bundle` (
  `id` int(11) NOT NULL,
  `no_order` varchar(50) NOT NULL,
  `product_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `bundle` varchar(256) NOT NULL,
  `size` varchar(10) DEFAULT NULL,
  `hoodie` varchar(128) DEFAULT NULL,
  `tshirt` varchar(128) DEFAULT NULL,
  `totebag` varchar(128) DEFAULT NULL,
  `cap` varchar(128) DEFAULT NULL,
  `keychain` varchar(128) DEFAULT NULL,
  `bracelet` varchar(128) DEFAULT NULL,
  `lanyard` varchar(128) DEFAULT NULL,
  `stickerbook` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_bundle`
--

INSERT INTO `order_bundle` (`id`, `no_order`, `product_id`, `qty`, `bundle`, `size`, `hoodie`, `tshirt`, `totebag`, `cap`, `keychain`, `bracelet`, `lanyard`, `stickerbook`) VALUES
(1, '05022021-607', 1, 1, 'Bundle Red Pack', 'M', NULL, 'T-Shirt Vivat 10 Nop', 'Totebag Tie Dye World Class Engineer', 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(2, '05022021-607', 1, 1, 'Bundle Red Pack', 'M', NULL, 'T-Shirt Vivat 10 Nop', 'Totebag Tie Dye World Class Engineer', 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(3, '05022021-941', 8, 1, 'Bundle Peach Pack', NULL, NULL, NULL, NULL, 'Dad Cap OG 10 Nop', 'Keychain 1957 ITS Robot', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(4, '05022021-419', 8, 1, 'Bundle Peach Pack', NULL, NULL, NULL, NULL, 'Dad Cap OG 10 Nop', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(5, '07022021-701', 2, 1, 'Bundle Orange Pack', 'M', NULL, 'Tie Dye T-Shirt Future Engineer Black', 'Totebag Tie Dye World Class Engineer', NULL, 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(7, '07022021-804', 8, 1, 'Bundle Peach Pack', NULL, NULL, NULL, NULL, 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(9, '08022021-948', 4, 1, 'Bundle Green Pack', 'M', NULL, 'T-Shirt Vivat 10 Nop', NULL, NULL, 'Keychain 1957 ITS Robot', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(10, '08022021-197', 7, 1, 'Bundle Lylac Pack', 'L', 'Hoodie Arek ITS Cak', NULL, NULL, NULL, 'Keychain 1957 ITS Robot', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(26, '12022021-037', 7, 1, 'Bundle Lylac Pack', 'M', 'Hoodie Arek ITS Cak', NULL, NULL, NULL, 'Keychain Attention Please', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(27, '13022021-590', 1, 1, 'Bundle Red Pack', 'XL', NULL, 'T-Shirt Arek ITS Cak', 'Totebag Snooze or Sleep', 'Dad Cap OG Logo White', 'Keychain 1957 ITS Robot', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(29, '15022021-826', 8, 1, 'Bundle Peach Pack', NULL, NULL, NULL, NULL, 'Dad Cap OG Logo White', 'Keychain 1957 ITS Robot', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(30, '16022021-461', 4, 1, 'Bundle Green Pack', 'XL', NULL, 'Tie Dye T-Shirt Future Engineer Purple', NULL, NULL, 'Keychain 1957 ITS Robot', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(31, '16022021-527', 4, 1, 'Bundle Green Pack', 'XL', NULL, 'T-Shirt Vivat 10 Nop', NULL, NULL, 'Keychain 1957 ITS Robot', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(32, '16022021-530', 4, 1, 'Bundle Green Pack', 'XL', NULL, 'Tie Dye T-Shirt Future Engineer Black', NULL, NULL, 'Keychain Attention Please', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(33, '16022021-507', 7, 1, 'Bundle Lylac Pack', 'M', 'Hoodie Arek ITS Cak', NULL, NULL, NULL, 'Keychain 1957 ITS Robot', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(35, '16022021-625', 1, 1, 'Bundle Red Pack', 'L', NULL, 'T-Shirt Arek ITS Cak', 'Totebag Snooze or Sleep', 'Dad Cap OG 10 Nop', 'Keychain 1957 ITS Robot', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(36, '17022021-016', 4, 1, 'Bundle Green Pack', 'S', NULL, 'T-Shirt Vivat 10 Nop', NULL, NULL, 'Keychain Attention Please', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(37, '18022021-205', 8, 1, 'Bundle Peach Pack', NULL, NULL, NULL, NULL, 'Dad Cap OG 10 Nop', 'Keychain Your Future Engineer', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(38, '18022021-637', 1, 1, 'Bundle Red Pack', 'M', NULL, 'T-Shirt Vivat 10 Nop', 'Totebag Snooze or Sleep', 'Dad Cap OG Logo White', 'Keychain Attention Please', 'Gelang 10 Nopember', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(39, '18022021-547', 3, 1, 'Bundle Yellow Pack', NULL, NULL, NULL, 'Totebag Stay Up Late', 'Dad Cap OG 10 Nop', 'Keychain 1957 ITS Robot', 'Gelang 10 Nopember', NULL, 'Stiker 8 in 1 Collection');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `product_id` int(8) NOT NULL,
  `notes` text,
  `product` varchar(256) NOT NULL,
  `qty` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `no_order`, `product_id`, `notes`, `product`, `qty`) VALUES
(3, '05022021-372', 45, NULL, 'Gelang World Class Engineer', 1),
(4, '05022021-591', 35, 'M', 'Tie Dye T-Shirt Future Engineer Black', 1),
(5, '05022021-237', 31, 'XL', 'Hoodie Kampoes Perdjoeangan', 1),
(12, '05022021-603', 45, NULL, 'Gelang World Class Engineer', 1),
(13, '05022021-603', 39, NULL, 'Totebag Snooze or Sleep', 1),
(16, '06022021-812', 40, NULL, 'Totebag Tie Dye World Class Engineer', 1),
(17, '06022021-812', 41, NULL, 'Keychain 1957 ITS Robot', 2),
(18, '06022021-812', 43, NULL, 'Keychain Your Future Engineer', 1),
(19, '06022021-812', 46, NULL, 'Lanyard World Class Engineer', 1),
(20, '06022021-812', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(21, '06022021-812', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(22, '06022021-806', 49, NULL, 'Dad Cap OG Logo White', 1),
(25, '06022021-358', 37, 'M', 'Tie Dye T-Shirt Future Engineer Blue', 1),
(28, '07022021-938', 35, 'XL', 'Tie Dye T-Shirt Future Engineer Black', 1),
(29, '07022021-938', 37, 'XL', 'Tie Dye T-Shirt Future Engineer Blue', 1),
(30, '07022021-749', 35, 'XXL', 'Tie Dye T-Shirt Future Engineer Black', 1),
(31, '07022021-749', 36, 'L', 'Tie Dye T-Shirt Future Engineer Purple', 1),
(32, '07022021-749', 37, 'XXL', 'Tie Dye T-Shirt Future Engineer Blue', 1),
(33, '07022021-749', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(34, '07022021-749', 39, NULL, 'Totebag Snooze or Sleep', 1),
(37, '07022021-074', 43, NULL, 'Keychain Your Future Engineer', 1),
(38, '07022021-074', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(39, '07022021-074', 42, NULL, 'Keychain Attention Please', 1),
(40, '07022021-157', 47, NULL, 'Stiker 8 in 1 Collection', 2),
(41, '07022021-157', 46, NULL, 'Lanyard World Class Engineer', 1),
(42, '08022021-948', 43, NULL, 'Keychain Your Future Engineer', 1),
(44, '08022021-945', 45, NULL, 'Gelang World Class Engineer', 1),
(46, '08022021-738', 35, 'L', 'Tie Dye T-Shirt Future Engineer Black', 1),
(47, '08022021-387', 39, NULL, 'Totebag Snooze or Sleep', 1),
(48, '08022021-982', 31, 'XXL', 'Hoodie Kampoes Perdjoeangan', 1),
(49, '08022021-378', 32, 'L', 'Hoodie Arek ITS Cak', 1),
(50, '08022021-378', 34, 'L', 'T-Shirt Vivat 10 Nop', 1),
(51, '09022021-307', 34, 'L', 'T-Shirt Vivat 10 Nop', 1),
(52, '09022021-307', 39, NULL, 'Totebag Snooze or Sleep', 1),
(59, '09022021-783', 38, NULL, 'Totebag Stay Up Late', 1),
(60, '09022021-783', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(61, '09022021-783', 46, NULL, 'Lanyard World Class Engineer', 1),
(62, '10022021-235', 32, NULL, 'Hoodie Arek ITS Cak', 1),
(63, '10022021-235', 34, NULL, 'T-Shirt Vivat 10 Nop', 1),
(64, '10022021-978', 42, NULL, 'Keychain Attention Please', 1),
(65, '10022021-978', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(66, '10022021-978', 47, NULL, 'Stiker 8 in 1 Collection', 2),
(67, '10022021-978', 43, NULL, 'Keychain Your Future Engineer', 1),
(72, '10022021-935', 34, NULL, 'T-Shirt Vivat 10 Nop', 1),
(73, '10022021-935', 41, NULL, 'Keychain 1957 ITS Robot', 3),
(79, '10022021-103', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(80, '10022021-103', 42, NULL, 'Keychain Attention Please', 1),
(81, '10022021-480', 49, NULL, 'Dad Cap OG Logo White', 1),
(82, '10022021-480', 35, 'M', 'Tie Dye T-Shirt Future Engineer Black', 1),
(83, '10022021-573', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(84, '10022021-573', 35, 'XXL', 'Tie Dye T-Shirt Future Engineer Black', 1),
(87, '10022021-078', 45, NULL, 'Gelang World Class Engineer', 1),
(88, '10022021-078', 49, NULL, 'Dad Cap OG Logo White', 1),
(89, '10022021-078', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(90, '10022021-078', 39, NULL, 'Totebag Snooze or Sleep', 1),
(91, '10022021-109', 32, 'XL', 'Hoodie Arek ITS Cak', 1),
(92, '10022021-728', 32, 'L', 'Hoodie Arek ITS Cak', 1),
(93, '10022021-728', 34, 'L', 'T-Shirt Vivat 10 Nop', 3),
(94, '10022021-728', 32, 'XL', 'Hoodie Arek ITS Cak', 1),
(95, '10022021-728', 33, 'XL', 'T-Shirt Arek ITS Cak', 1),
(96, '10022021-834', 44, NULL, 'Gelang 10 Nopember', 2),
(97, '11022021-107', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(98, '11022021-716', 32, 'L', 'Hoodie Arek ITS Cak', 1),
(99, '11022021-532', 39, NULL, 'Totebag Snooze or Sleep', 1),
(100, '11022021-859', 33, 'XL', 'T-Shirt Arek ITS Cak', 1),
(101, '12022021-296', 46, NULL, 'Lanyard World Class Engineer', 1),
(102, '12022021-296', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(108, '12022021-648', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(109, '12022021-648', 42, NULL, 'Keychain Attention Please', 1),
(111, '13022021-543', 33, 'S', 'T-Shirt Arek ITS Cak', 1),
(112, '13022021-432', 34, 'S', 'T-Shirt Vivat 10 Nop', 1),
(113, '13022021-432', 34, 'M', 'T-Shirt Vivat 10 Nop', 1),
(114, '13022021-481', 47, NULL, 'Stiker 8 in 1 Collection', 2),
(115, '13022021-481', 41, NULL, 'Keychain 1957 ITS Robot', 2),
(116, '14022021-761', 31, 'XXL', 'Hoodie Kampoes Perdjoeangan', 1),
(117, '14022021-761', 34, 'L', 'T-Shirt Vivat 10 Nop', 2),
(118, '14022021-761', 47, NULL, 'Stiker 8 in 1 Collection', 3),
(119, '15022021-042', 34, 'XL', 'T-Shirt Vivat 10 Nop', 1),
(120, '15022021-023', 34, 'XL', 'T-Shirt Vivat 10 Nop', 1),
(121, '15022021-023', 39, NULL, 'Totebag Snooze or Sleep', 1),
(122, '15022021-023', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(123, '15022021-023', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(124, '15022021-876', 32, 'XL', 'Hoodie Arek ITS Cak', 1),
(125, '16022021-590', 32, 'XXL', 'Hoodie Arek ITS Cak', 1),
(126, '16022021-590', 43, NULL, 'Keychain Your Future Engineer', 1),
(127, '16022021-590', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(128, '16022021-530', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(129, '16022021-907', 44, NULL, 'Gelang 10 Nopember', 1),
(130, '16022021-907', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(131, '17022021-685', 43, NULL, 'Keychain Your Future Engineer', 1),
(132, '17022021-685', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(133, '17022021-685', 44, NULL, 'Gelang 10 Nopember', 1),
(134, '17022021-685', 45, NULL, 'Gelang World Class Engineer', 1),
(135, '17022021-685', 46, NULL, 'Lanyard World Class Engineer', 1),
(136, '17022021-685', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(137, '17022021-685', 35, 'L', 'Tie Dye T-Shirt Future Engineer Black', 1),
(138, '17022021-204', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(139, '17022021-765', 34, 'M', 'T-Shirt Vivat 10 Nop', 1),
(140, '17022021-765', 49, NULL, 'Dad Cap OG Logo White', 1),
(143, '18022021-842', 46, NULL, 'Lanyard World Class Engineer', 1),
(144, '18022021-842', 40, NULL, 'Totebag Tie Dye World Class Engineer', 1),
(145, '19022021-350', 40, NULL, 'Totebag Tie Dye World Class Engineer', 1),
(146, '19022021-350', 31, 'M', 'Hoodie Kampoes Perdjoeangan', 1),
(147, '19022021-930', 34, 'M', 'T-Shirt Vivat 10 Nop', 1),
(148, '20022021-926', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(149, '20022021-926', 49, NULL, 'Dad Cap OG Logo White', 1),
(150, '20022021-926', 45, NULL, 'Gelang World Class Engineer', 1),
(151, '20022021-218', 37, 'L', 'Tie Dye T-Shirt Future Engineer Blue', 1),
(152, '20022021-218', 42, NULL, 'Keychain Attention Please', 1),
(153, '20022021-218', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(154, '20022021-218', 49, NULL, 'Dad Cap OG Logo White', 1),
(155, '20022021-195', 32, 'XL', 'Hoodie Arek ITS Cak', 1),
(156, '20022021-018', 46, NULL, 'Lanyard World Class Engineer', 1),
(157, '20022021-018', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(160, '20022021-645', 40, NULL, 'Totebag Tie Dye World Class Engineer', 1),
(161, '20022021-645', 45, NULL, 'Gelang World Class Engineer', 1),
(166, '20022021-394', 49, NULL, 'Dad Cap OG Logo White', 2),
(167, '20022021-394', 39, NULL, 'Totebag Snooze or Sleep', 1),
(168, '20022021-394', 40, NULL, 'Totebag Tie Dye World Class Engineer', 1),
(169, '20022021-394', 37, 'L', 'Tie Dye T-Shirt Future Engineer Blue', 1),
(174, '20022021-631', 39, NULL, 'Totebag Snooze or Sleep', 1),
(175, '20022021-631', 43, NULL, 'Keychain Your Future Engineer', 2),
(176, '20022021-631', 49, NULL, 'Dad Cap OG Logo White', 1),
(177, '20022021-631', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(178, '20022021-780', 31, 'M', 'Hoodie Kampoes Perdjoeangan', 1),
(179, '20022021-780', 49, NULL, 'Dad Cap OG Logo White', 1),
(180, '20022021-780', 48, NULL, 'Dad Cap OG 10 Nop', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shorten_link`
--

CREATE TABLE `shorten_link` (
  `id` int(11) NOT NULL,
  `namalink` varchar(128) NOT NULL,
  `urllink` varchar(2000) NOT NULL,
  `shortenurl` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shorten_link`
--

INSERT INTO `shorten_link` (`id`, `namalink`, `urllink`, `shortenurl`) VALUES
(5, 'Absensi Gathering 1', 'https://forms.gle/H8YXXuwSPn76Rzgn6', 'Absensigathering1'),
(6, 'Feedback gathering 1', 'https://forms.gle/qewnTbKfjTUfVW9Z9', 'Feedbackgathering1'),
(7, 'Pendaftaran Forda ILITS 2021', 'https://drive.google.com/drive/folders/1FO9KHq2znZixqIVmeR9Z4lIx9GChN_Y-?usp=sharing', 'PendaftaranFordaILITS2021'),
(15, 'Informasi Gathering Forda 2', 'https://drive.google.com/drive/folders/1-T_whGaopcf9R0rrpCsNOCD4OvfSKjR8?usp=sharing', 'InformasiGatheringForda2'),
(10, 'Proposal Keikutsertaan Forda', 'https://docs.google.com/spreadsheets/d/10uQvsefC6sUVooKMRmaXbAnv0aIdEUpd/edit#gid=1615080396', 'ProposalKeikutsertaanForda'),
(22, 'Feedback Dan Evaluasi Gathering Forda 2 Inilhoits! 2021', 'https://forms.gle/SBawQgogU5YQAHFq8', 'FeedbackGathForda2'),
(18, 'Form Pertanyaan Booklet', 'https://docs.google.com/forms/d/e/1FAIpQLScUm20XIGvOsCA9IuI-J4STqpYJMfpN20PVoHjTYQpeDth4SQ/viewform', 'FormPertanyaanBooklet'),
(19, 'Informasi Gathering Forda 1', 'https://drive.google.com/drive/folders/1KkWxf4ZiawtJNYqsubOFlA4PxyXVShNF?usp=sharing', 'InformasiGatheringForda1'),
(20, 'Data Departemen 2021', 'https://docs.google.com/forms/d/e/1FAIpQLSeD2QKEGrb6jBqt0eXtnsxz0onnNiNvmHkBT21haURDOAzE3A/viewform', 'DataDepartemen2021'),
(21, 'Data BEMF 2021', 'https://docs.google.com/forms/d/1jvfc7t6D9a2AAzE7871i0E2VvOf9-pDHAOrNOGY3oX0/edit', 'DataBEMF2021'),
(23, 'Presensi Kehadiran Gathering Forda 2', 'https://forms.gle/Hgqo2xdyT7vbowg57', 'PresensiGathForda2'),
(24, 'Notulensi Gathering Forda 2 Inilhoits! 2021', 'https://docs.google.com/document/d/1uVGcZn3fAxwuR1Lfn_6xTqk_W4x6n2rfZ7z_POID4b4/edit?usp=sharing', 'NotulensiGathForda2'),
(26, 'PPT Gathering Forda II', 'https://drive.google.com/file/d/1Zungr3Y3lglajeZeTIhiOI_nzWIPugSI/view', 'PPTGatheringFordaII'),
(27, 'Pertanyaan Booklet 2', 'https://docs.google.com/document/d/1spsHpyf5Kew4O48zoD6gWb4BZgh0fLrLIpAj5m_8pmw/edit', 'PertanyaanBooklet2'),
(28, 'Presensi Kehadiran Panitia Gathering Forda 2', 'https://forms.gle/FE7hdQM3dhZHnECq8', 'PresensiPanitiaGathForda2'),
(29, 'Form Feedback Pemateri', 'https://docs.google.com/forms/d/e/1FAIpQLSf85XupX_dudlctttJKjQuEFaFRkegLfLzBWXSlCMdbbuVt5A/viewform?usp=sf_link', 'FeedbackPemateriTraining'),
(32, 'Form Pemesanan Merchandise Ilits', 'https://docs.google.com/forms/d/e/1FAIpQLSdV8abfZf6D5MCo29LhiNQ8_BxqmlkEYcH0BEOX_rX1Mz2Urw/viewform', 'FormPemesananMerch'),
(33, 'Informasi Upgrading Forda Day 1', 'https://drive.google.com/drive/folders/15HOM9lBOLI1tW36G5nSafr_cydln_xub?usp=sharing', 'InformasiUpgradingFordaDay1'),
(34, 'Presensi Upgrading Forda Day 1', 'https://forms.gle/ratfDPqGBnWuXsNVA', 'PresensiUpgradingFordaDay1'),
(35, 'Feedback Upgrading Forda Day 1', 'https://forms.gle/yXRVR2F9TcQfrytG6', 'FeedbackUpgradingFordaDay1'),
(36, 'Post Test Pengelolaan kepanitiaan', 'https://docs.google.com/forms/d/e/1FAIpQLScIvsnh-vAAVgZ9RbDntsEMB_jvLrL3yKeymkw-3n6rA5URGQ/viewform?usp=sf_link', 'PostTestMateri1'),
(37, 'Post Test Best Service Level', 'https://forms.gle/UnFe6iqrVk3tKNdV9', 'PostTestMateri2'),
(38, 'Link Berita Acara Visit Forda Bali', 'https://drive.google.com/drive/folders/1kRE9_662YnL7l_aCN752zoJWsbBRPV5o?usp=sharing', 'VisitFordaBali'),
(39, 'Link Berita Acara Visit Forda Balikpapan', 'https://drive.google.com/drive/folders/1QS6SxOLus6R64FTqmCQIdAZi3T8tXuR_?usp=sharing', 'VisitFordaBalikpapan'),
(40, 'Link Berita Acara Visit Forda Bandung', 'https://drive.google.com/drive/folders/11U7WQMjPHcYIXPAG7tKmRKFgvieSUSA7?usp=sharing', 'VisitFordaBandung'),
(41, 'Link Berita Acara Visit Forda Bangkalan', 'https://drive.google.com/drive/folders/1yxh-ilU5xN5llsNunotwHKQ3M2senBdc?usp=sharing', 'VisitFordaBangkalan'),
(42, 'Link Berita Acara Visit Forda Banten', 'https://drive.google.com/drive/folders/1OAN1TaLigDVWTT88CHESkeENMJu4KS9E?usp=sharing', 'VisitFordaBanten'),
(43, 'Link Berita Acara Visit Forda Banyumas', 'https://drive.google.com/drive/folders/12RTypjDBAsClKT4uppbKf6bnlAGZaqlE?usp=sharing', 'VisitFordaBanyumas'),
(44, 'Link Berita Acara Visit Forda Banyuwangi', 'https://drive.google.com/drive/folders/1KnUhzb7tj8ZxPBz8XwSk0koJuZc-bWa_?usp=sharing', 'VisitFordaBanyuwangi'),
(45, 'Link Berita Acara Visit Forda Batu', 'https://drive.google.com/drive/folders/1sGEE0AXYfjXfFxFJuAEu8CqsKAlvnxbw?usp=sharing', 'VisitFordaBatu'),
(46, 'Link Berita Acara Visit Forda Bekasi', 'https://drive.google.com/drive/folders/1c2KnnlqMjis5CXQdL50IpqiwGBLZopVz?usp=sharing', 'VisitFordaBekasi'),
(47, 'Link Berita Acara Visit Forda Bengkulu', 'https://drive.google.com/drive/folders/1BC1Ve5iezjq4u_MAekvbNeF9uI1_uh-m?usp=sharing', 'VisitFordaBengkulu'),
(48, 'Link Berita Acara Visit Forda Blitar', 'https://drive.google.com/drive/folders/1vgmV8XtcFq-UODBA1F1XprExCL4sO6A2?usp=sharing', 'VisitFordaBlitar'),
(49, 'Link Berita Acara Visit Forda Bojonegoro', 'https://drive.google.com/drive/folders/1f06wUlbPZM7kN4Yg6nO08cLQr28kabX6?usp=sharing', 'VisitFordaBojonegoro'),
(50, 'Link Berita Acara Visit Forda Bontang', 'https://drive.google.com/drive/folders/1v9KyiDCDHLJFHNbDdKTpfM3U4eVt5KiG?usp=sharing', 'VisitFordaBontang'),
(51, 'Link Berita Acara Visit Forda Cepu', 'https://drive.google.com/drive/folders/1LaZWMgkkHcUc7242-ie62EoZLBxOgMhr?usp=sharing', 'VisitFordaCepu'),
(52, 'Link Berita Acara Visit Forda Depok', 'https://drive.google.com/drive/folders/1tPK41auxYAlYT776t8YOSZl-gGQ8Ejr7?usp=sharing', 'VisitFordaDepok'),
(53, 'Link Berita Acara Visit Forda DKI JAKARTA', 'https://drive.google.com/drive/folders/1cIaUxurpA7OiaE3YOqY_pR8IYn73ghwD?usp=sharing', 'VisitFordaJakarta'),
(54, 'Link Berita Acara Visit Forda Gresik', 'https://drive.google.com/drive/folders/1o7wxoMwt12iuYxNGBu8a0f7SqzN_cUf-?usp=sharing', 'VisitFordaGresik'),
(55, 'Link Berita Acara Visit Forda Jember', 'https://drive.google.com/drive/folders/1BN0vOGq6Iyx_PQFQ-8QUojhfy2iXhj2H?usp=sharing', 'VisitFordaJember'),
(56, 'Link Berita Acara Visit Forda Jombang', 'https://drive.google.com/drive/folders/1Sk-otvFzlGf_ZXdPCHG2cvOfwvmAwP71?usp=sharing', 'VisitFordaJombang'),
(57, 'Link Berita Acara Visit Forda Kalimantan Barat', 'https://drive.google.com/drive/folders/1a8-AI0uI2zWTR00JRxDGo7l9frUKQSkE?usp=sharing', 'VisitFordaKalbar'),
(58, 'Link Berita Acara Visit Forda Karanganyar', 'https://drive.google.com/drive/folders/1I-_grXG9kedjf6Qv_e-jYBr7CHwo-Tka?usp=sharing', 'VisitFordaKaranganyar'),
(59, 'Link Berita Acara Visit Forda Kediri', 'https://drive.google.com/drive/folders/1bmXZM9XMsoBXn0Qksy_LVLTFU9j15-M0?usp=sharing', 'VisitFordaKediri'),
(60, 'Link Berita Acara Visit Forda Klaten', 'https://drive.google.com/drive/folders/1REWvJaWqneHzmZDOQ-9KG4sUOk7-_0we?usp=sharing', 'VisitFordaKlaten'),
(61, 'Link Berita Acara Visit Forda Pekalongan', 'https://drive.google.com/drive/folders/11FlAU2F4E7-pjkf3XW-fPL-7k7tR8-uI?usp=sharing', 'VisitFordaPekalongan'),
(62, 'Link Berita Acara Visit Forda Kudus', 'https://drive.google.com/drive/folders/1CU-o5ZKhRXzES3o9GQT6kvAqHXtXIx9f?usp=sharing', 'VisitFordaKudus'),
(63, 'Link Berita Acara Visit Forda Lamongan', 'https://drive.google.com/drive/folders/1c3JaAyY0JuhntC6tRDxpTAl-RENccZ1B?usp=sharing', 'VisitFordaLamongan'),
(64, 'Link Berita Acara Visit Forda Lampung', 'https://drive.google.com/drive/folders/1Ha69RJjvPoE_NZqZtjFrHGbA4-5W94KG?usp=sharing', 'VisitFordaLampung'),
(65, 'Link Berita Acara Visit Forda Lombok', 'https://drive.google.com/drive/folders/1fTp1VYMRvvS3C27iT6jgt1maOxD-d6Kz?usp=sharing', 'VisitFordaLombok'),
(66, 'Link Berita Acara Visit Forda Madiun', 'https://drive.google.com/drive/folders/1XA2F060rb5R1w0PHEXgtNZi4-ha7df4M?usp=sharing', 'VisitFordaMadiun'),
(67, 'Link Berita Acara Visit Forda Magelang', 'https://drive.google.com/drive/folders/1PhufjedbxfVIHnGV9qBOkN9t9cZvHhMM?usp=sharing', 'VisitFordaMagelang'),
(68, 'Link Berita Acara Visit Forda Manado', 'https://drive.google.com/drive/folders/13O-i__LZjdr2eX59533tKftpiqd4HzkP?usp=sharing', 'VisitFordaManado'),
(69, 'Link Berita Acara Visit Forda Mojokerto', 'https://drive.google.com/drive/folders/1GpTiO8eEQbxnecpmm6Mae2GOspCW-o0C?usp=sharing', 'VisitFordaMojokerto'),
(70, 'Link Berita Acara Visit Forda Nganjuk', 'https://drive.google.com/drive/folders/19figgbL4Hs4kzWMBTtuGOSgIEnWP-jmt?usp=sharing', 'VisitFordaNganjuk'),
(71, 'Link Berita Acara Visit Forda Ngaw', 'https://drive.google.com/drive/folders/1EqKAVG7wPb6M4T_FTg3nHL5O_I1tv_2x?usp=sharing', 'VisitFordaNgawi'),
(72, 'Link Berita Acara Visit Forda Pamekasan', 'https://drive.google.com/drive/folders/1m7WuggisycE6Q_a0Q94iaeppZhvxTLau?usp=sharing', 'VisitFordaPamekasan'),
(73, 'Link Berita Acara Visit Forda Pasuruan', 'https://drive.google.com/drive/folders/1hN3d7KXqPpYRCOM9088LtUI1CpsKK3L9?usp=sharing', 'VisitFordaPasuruan'),
(74, 'Link Berita Acara Visit Forda Pati', 'https://drive.google.com/drive/folders/1YlPDMthzMfIB7XHIO-LxVEEyZv0vvNoa?usp=sharing', 'VisitFordaPati'),
(75, 'Link Berita Acara Visit Forda Ponorogo', 'https://drive.google.com/drive/folders/1bQnfTH5yOGfPLKzCUJQykYzhJdjdu2aR?usp=sharing', 'VisitFordaPonorogo'),
(76, 'Link Berita Acara Visit Forda Probolinggo', 'https://drive.google.com/drive/folders/1c6AtnboaLsTdVtvdsR0f33oldB_HhAUD?usp=sharing', 'VisitFordaProbolinggo'),
(77, 'Link Berita Acara Visit Forda Purworejo', 'https://drive.google.com/drive/folders/1wW6Lxs0QYzlymvpx2sJvzR-uYJ4v5b_Z?usp=sharing', 'VisitFordaPurworejo'),
(78, 'Link Berita Acara Visit Forda Riau', 'https://drive.google.com/drive/folders/1xbPErpM30O5stQ5n_GBQSm-6rvgYX-zt?usp=sharing', 'VisitFordaRiau'),
(79, 'Link Berita Acara Visit Forda Salatiga', 'https://drive.google.com/drive/folders/1_6v3Ul99RULl3f4EmFCMC4ftLRLBleTS?usp=sharing', 'VisitFordaSalatiga'),
(80, 'Link Berita Acara Visit Forda Samarinda', 'https://drive.google.com/drive/folders/1AoxZMms39HjSfHqiN7bTVXd1VLyql69C?usp=sharing', 'VisitFordaSamarinda'),
(81, 'Link Berita Acara Visit Forda Sampang', 'https://drive.google.com/drive/folders/1bVnXcvTzoaw2qv09DWUWGb1ZdOqU5CuO?usp=sharing', 'VisitFordaSampang'),
(82, 'Link Berita Acara Visit Forda Semarang', 'https://drive.google.com/drive/folders/1-ap0dGwJOMjziG_jB4hQnQSx3sfcwKsP?usp=sharing', 'VisitFordaSemarang'),
(83, 'Link Berita Acara Visit Forda Sidoarjo', 'https://drive.google.com/drive/folders/15wmLDMlkXcCiEl0Yg7gVkF81LpF7Jd9-?usp=sharing', 'VisitFordaSidoarjo'),
(84, 'Link Berita Acara Visit Forda Situbondo', 'https://drive.google.com/drive/folders/1wVI4e_YQdfGp8Qhng6YWhdCbed8-zRTR?usp=sharing', 'VisitFordaSitubondo'),
(85, 'Link Berita Acara Visit Forda Solo', 'https://drive.google.com/drive/folders/1lQQHQP-r8pzec059ftME_cr3MUdA4E_6?usp=sharing', 'VisitFordaSolo'),
(86, 'Link Berita Acara Visit Forda Sukoharjo', 'https://drive.google.com/drive/folders/1gOe8YxwaxB-BjLm_ZB6bieKrD1HwKb9Q?usp=sharing', 'VisitFordaSukoharjo'),
(87, 'Link Berita Acara Visit Forda Sulawesi Selatan', 'https://drive.google.com/drive/folders/1-5Nbz369JWm-XX_QqyPZxkSI4sorLNbJ?usp=sharing', 'VisitFordaSulsel'),
(88, 'Link Berita Acara Visit Forda Sulawesi Tenggara', 'https://drive.google.com/drive/folders/1IW9JiEhiFshidFqC08tWgCBiWejPxvOu?usp=sharing', 'VisitFordaSulawesiTenggara'),
(89, 'Link Berita Acara Visit Forda Sumatera Barat', 'https://drive.google.com/drive/folders/13LR5hmY_vDM2-x8YJS28HxFIieU6udj3?usp=sharing', 'VisitFordaSumateraBarat'),
(90, 'Link Berita Acara Visit Forda Sumbawa Besar', 'https://drive.google.com/drive/folders/1oMjk6-inMdlVIySZ-pehvu1JJA-AtyG-?usp=sharing', 'VisitFordaSumbawaBesar'),
(91, 'Link Berita Acara Visit Forda Sumenep', 'https://drive.google.com/drive/folders/1EGgjxdJFqAMkOcLknjlC8h0VFV7ATZ4Y?usp=sharing', 'VisitFordaSumenep'),
(92, 'Link Berita Acara Visit Forda Tangerang', 'https://drive.google.com/drive/folders/10QA8qj-zFJUWFtYeVKf1SUJ9kZikCwFt?usp=sharing', 'VisitFordaTangerang'),
(93, 'Link Berita Acara Visit Forda Tasikmalaya', 'https://drive.google.com/drive/folders/1cf7MlONcKyRt15_iZQXK34u8JvhE5y1R?usp=sharing', 'VisitFordaTasikmalaya'),
(94, 'Link Berita Acara Visit Forda Tegal', 'https://drive.google.com/drive/folders/1wEbFWa579qnvHjngIEqXhaDIaUF3NeSu?usp=sharing', 'VisitFordaTegal'),
(95, 'Link Berita Acara Visit FordaTuban', 'https://drive.google.com/drive/folders/1uEOogJLuDUlo0279va9sHnMPFGMuKBfU?usp=sharing', 'VisitFordaTuban'),
(96, 'Link Berita Acara Visit Forda Tulungagung', 'https://drive.google.com/drive/folders/1sLikY1uxpXx3baLqRi2EVPH54yCnrdDB?usp=sharing', 'VisitFordaTulungagung'),
(97, 'Link Berita Acara Visit Forda Yogyakarta', 'https://drive.google.com/drive/folders/1yU-0liWAXxkoYEzuRhUqGmOFK9lSa6dq?usp=sharing', 'VisitFordaYogyakarta'),
(98, 'Link Berita Acara Visit Forda Sulawesi Selatan 1', 'https://drive.google.com/drive/folders/1-5Nbz369JWm-XX_QqyPZxkSI4sorLNbJ?usp=sharing', 'VisitFordaSulawesiSelatan'),
(99, 'Link Berita Acara Visit Forda Kalimantan Barat 1', 'https://drive.google.com/drive/folders/1a8-AI0uI2zWTR00JRxDGo7l9frUKQSkE?usp=sharing', 'VisitFordaKalimantanBarat'),
(100, 'Informasi Upgrading Forda Day 2', 'https://drive.google.com/drive/folders/1WeCbr20ZiCTAHO1ibb4t1hB94sU32ZSW?usp=sharing', 'InformasiUpgradingFordaDay2'),
(101, 'Post Test Public Speaking', 'https://docs.google.com/forms/d/e/1FAIpQLSf3dv5EtK48HjMfBl9iD8XRshK6ky7xE9cL_fyL-yhgxLIQjw/viewform', 'PostTestMateri5'),
(102, 'Presensi Upgrading Forda Day 2', 'https://forms.gle/QnPRmXwiHNL1pJVn9', 'PresensiUpgradingFordaDay2'),
(103, 'Feedback Upgrading Forda Day 2', 'https://forms.gle/pCbFr2Tyz4C5T6mBA', 'FeedbackUpgradingFordaDay2'),
(104, 'Post Test Mengonsep Acara', 'https://docs.google.com/forms/d/e/1FAIpQLSc4El45E4BCedeg8agGkTPDk8uQASlPlKYUvhU2CCyjq98efA/viewform?usp=sf_link', 'PostTestMateri3'),
(105, 'Post Test Strategi dan Teknik Marketing', 'https://docs.google.com/forms/d/e/1FAIpQLScsDPuamlRGgMtrWy3c6lEOkAyL0_7NlxmT0c0-U0QXue49Hg/viewform?usp=sf_link', 'PostTestMateri4'),
(106, 'Contoh Presensi Visit Forda', 'https://forms.gle/u5onyAXNH9ojpzVV9', 'ContohPresensiVisitForda'),
(107, 'Background Google Form ILITS', 'https://drive.google.com/file/d/17QGTNi0zePBvZHiI5Hcc6Mya3UsMfryH/view?usp=sharing', 'BackgroundFormILITS'),
(108, 'Contoh Feedback Visit Forda', 'https://forms.gle/dZJHEMwd7HTYtYTD6', 'ContohFeedbackVisitForda'),
(109, 'Informasi Gathering Humas 2', 'https://drive.google.com/drive/folders/107fJZxmQ1OB0P3EJ7LTvXdOsY4CrqcWe?usp=sharing', 'InformasiGatheringHumas2'),
(110, 'Link Berita Acara Visit Forda Cirebon', 'https://drive.google.com/drive/folders/1C_l2k4dSUHpTVsatB6dHoNTThWf1I9Lz?usp=sharing', 'VisitCirebon'),
(111, 'Link Berita Acara Visit Forda Cirebon 1', 'https://drive.google.com/drive/folders/1C_l2k4dSUHpTVsatB6dHoNTThWf1I9Lz?usp=sharing', 'VisitFordaCirebon'),
(113, 'Feedback Upgrading Forda Day 3', 'https://docs.google.com/forms/d/17k5XenTiDrRknQWUo35bIh3LgfqqUKeY7nS62KXH9Nk/viewform', 'FeedbackUpgradingFordaDay3'),
(114, 'Presensi Upgrading Forda Day 3', 'https://forms.gle/Puknr9anQY1E44mLA', 'PresensiUpgradingFordaDay3'),
(115, 'TalkshowILITS2021', 'https://zoom.us/j/98461448996?pwd=SjJoekd6cFpwaEIyVTlsZyt1TDNyQT09', 'TalkshowILITS2021'),
(116, 'Post Test Presentasi yang menarik dan persuasif', 'https://docs.google.com/forms/d/e/1FAIpQLSfbZCSv4g0dEsqSIo-Bpj1izfsMRjiCsGdsL-aGQy_DGRkwDw/viewform?usp=sf_link', 'PostTestMateri6'),
(117, 'Informasi Upgrading Forda Day 3', 'https://drive.google.com/drive/folders/1gHf4llqCaq3miH65_t27ZtWLJ36z4bVp?usp=sharing', 'InformasiUpgradingFordaDay3'),
(118, 'Feedback Gathering 2 HMD', 'https://forms.gle/8txwuTvsSHMeS6x88', 'FeedbackGath2HMD'),
(119, 'Presensi Gathering 2 HMD', 'https://forms.gle/oxPh3n2ZEdU5UFgb7', 'PresensiGath2HMD'),
(120, 'Notulensi Gathering 2 HMD', 'https://docs.google.com/document/d/1TqCQ8ieU4rfhYU1G4VCL-m_VONDQhwWJbPjxzsTgg-w/edit', 'NotulensiGath2HMD'),
(121, 'Record Training Forda Day 123', 'https://drive.google.com/drive/folders/1iIns9knyvVLoAv3WZU3PzjR7g9bXlOnn?usp=sharing', 'RecordTrainingFordaDay123'),
(122, 'Informasi Gathering Forda 3', 'https://drive.google.com/drive/folders/1A0HVLqYKWMPGlZ2pmuWHGy6Q3wAO-9Gp?usp=sharing', 'InformasiGatheringForda3'),
(123, 'Presensi Gathering Forda 3', 'https://forms.gle/vPtvfwhnoiyqbZzX9', 'PresensiGathForda3'),
(124, 'Feedback Gathering Forda 3', 'https://forms.gle/hJsoqMj6FY9uYHZq5', 'FeedbackGathForda3'),
(125, 'Notulensi Gathering Forda 3 Inilhoits! 2021', 'https://docs.google.com/document/d/1SalxxPeNlA15LUa735sw2mZkbVzf5VxCGP4aQvm8ooM/edit?usp=sharing', 'NotulensiGathForda3'),
(126, 'Flowchart Pendaftaran Try Out', 'https://drive.google.com/file/d/1GT3FF1kIig0y-LjMgy5gHJCu-PJ-rIBL/view', 'FlowchartPendaftaranTO'),
(127, 'Video Kumpulan Departemen', 'https://docs.google.com/spreadsheets/d/1TFtyvJWNOetTP4RktSa4_SlbRkn2d2mxMFj9Ci9D7xs/edit?usp=sharing', 'KumpulanVideoDepartemen'),
(132, 'Booklet Merchandise Forda Ilits', 'https://drive.google.com/file/d/1ww6duAxO-WMSssLqs4_nEuAGYiJHLNVm/view?usp=sharing', 'bookletmerchandiseforda'),
(129, 'Merchandise ILITS 2021', 'https://docs.google.com/presentation/d/1AaovNVPGt6MeKIyK6DxThfPaDElg1JWn7Nyj685YRFU/edit?usp=sharing', 'MerchILITS2021'),
(130, 'Hasil Plot Sesi Try Out', 'https://docs.google.com/presentation/d/1_wLiWbfSehcbvrPaTt6oS2i_6zbNxza8/edit#slide=id.p1', 'HasilPlotSesiTO'),
(135, 'Super Grafis ILITS 2021', 'https://drive.google.com/drive/folders/1Nex3-WfYermOrYnHMKrA_akMr3bzfqj7?usp=sharing', 'SuperGrafisILITS2021'),
(136, 'Timeline VIrtual Expo', 'https://docs.google.com/spreadsheets/d/1-JHCWxMTWqR6Y707YXCbBIfziqhDgArrjqt_WgZ5Sak/edit#gid=0', 'TimelineVirtualExpo'),
(137, 'Data Website Pendaftaran Forda', 'https://docs.google.com/forms/d/e/1FAIpQLSf4mgveu_T28xlmkF0OKsGATAdbPnptUDmki-Swuajl1dc5dQ/viewform', 'DataWebsitePendaftaranForda'),
(138, 'Informasi Gathering Humas 3', 'https://drive.google.com/drive/folders/1wJZnPdo5rvBzgQX0Z6t1XM2yGVsHfd8U?usp=sharing', 'InformasiGatheringHumas3'),
(140, 'PPT dan Bahan Publikasi Merch Ilits Forda', 'https://drive.google.com/drive/folders/1efJS5Ns-4CAM-ZOFhRJxj_2RZ9DcWVqQ', 'pptmerchilits'),
(141, 'Presensi Gathering 3 HMD', 'https://forms.gle/3qKTgkvj615g2DhU6', 'PresensiGath3HMD'),
(142, 'Notulensi Gathering 3 HMD', 'https://docs.google.com/document/d/1yDYDSslcdE0e0dsdm0jvIIhlbQ-8xwfWK2VGBQcGKbM/edit', 'NotulensiGath3HMD'),
(143, 'Feedback Gathering 3 HMD', 'https://forms.gle/4Rdwj72opQMT14yL9', 'FeedbackGath3HMD'),
(144, 'Konten Virtual Expo', 'https://drive.google.com/drive/folders/1ZNQ6tPWUQF4q7iNMRBAbRw4bAnTGJUYs?usp=sharing', 'KontenVirpo'),
(145, 'Persiapan LO', 'https://drive.google.com/drive/folders/1oTaWo3ezlulDDku0sR7Gc6QA6ol5ZHWj?usp=sharing', 'PersiapanLO'),
(146, 'Presensi Gathering 3 HMD (2)', 'https://docs.google.com/spreadsheets/d/13c0GHR_tLNhy76bwstSdbGttCM9bg24195F0bgP-69A/edit#gid=0', 'PresensiGath3Humas'),
(147, 'PPT Rapat Koordinasi', 'https://docs.google.com/presentation/d/1ghQUgf9fYOoC3f3du3MlP3XwP17VKJAlF0335FiAExc/edit#slide=id.p1', 'PPTRapatKoordinasiOpenCampus'),
(148, 'Rapat Komunal Pertama', 'https://teams.microsoft.com/l/meetup-join/19%3af09137fc6a014ccf93981fd3600aa160%40thread.tacv2/1611912443561?context=%7b%22Tid%22%3a%221d5169ac-c7cb-4275-9764-bf8c9c364a4c%22%2c%22Oid%22%3a%2282baa186-fdd6-45fe-8fcf-fa5c34f2612a%22%7d', 'RapatKomunal1'),
(149, 'Data base pembicara open kampus', 'https://docs.google.com/spreadsheets/d/1EcVaF6GM17NEBS0F6Q-c8zx4UT0y0IU9RevrurX05_4/edit', 'DatabasePembicaraOpenCampus'),
(150, 'Informasi Open Campus HMD, Kadep, dan Dekan', 'https://drive.google.com/drive/folders/16LQyqoNEejNUNLSQy7krPJzYyKjAbNLx?usp=sharing', 'InformasiOpenCampusILITS2021'),
(151, 'Presensi Rakom I', 'https://forms.gle/w28zueHnxK8gSVpn8', 'PresensiRakom1'),
(152, 'Feedback Rapat Komunal 1', 'https://forms.gle/Bk2cVETWLHVpyjn99', 'FeedbackRakom1'),
(153, 'Database Forda Ini Lho ITS! 2021', 'https://docs.google.com/spreadsheets/d/1bG7JLoAEeYfBV5-3cCF64NiBEhNFvH8JzzJbXyAAHco/edit#gid=0', 'DatabaseFordaILITS2021'),
(154, 'Excel Uji Fungsi Poster', 'https://docs.google.com/spreadsheets/d/1fqfIyjBRse2Ng541Li02X8i4zcLTGXJrI7-BlhNQfGY/edit?usp=sharing', 'UjiFungsiPosterILITS2021'),
(155, 'Contoh Presensi Welcome Forda', 'https://forms.gle/HoEJ5uRfVQBeGLHz8', 'ContohPresensiWelcomeForda'),
(156, 'Analisis Platform', 'https://docs.google.com/spreadsheets/d/1aReMhDgwqoYp6BZSwkPGhvxO4wlJjqmOERa4gsDDKRo/edit?usp=sharing', 'AnalisisPlatform'),
(157, 'Poster Open Campus HD', 'https://drive.google.com/file/d/1vU9V3XDZqb_W2snSf8IZfJgHhX2DoxF9/view?usp=sharing', 'PosterOpenCampusHD'),
(158, 'Pengumpulan Materi ILITS 2021', 'https://drive.google.com/drive/folders/1VhUGCY0FeKhqBCl5QRSWRywpwUFtBr_3?usp=sharing', 'PengumpulanMateriILITS2021'),
(159, 'Bahan Boom Publikasi', 'https://drive.google.com/drive/u/8/folders/1zAqgA2BPZgiSoNvSdz7gF1gkOOwR6smd', 'BoomPublikasi'),
(160, 'Informasi Gladi Kotor Open Campus', 'https://drive.google.com/drive/folders/1aD1YYJjTWhLWfvWca-tcxZrshS_hv-jK?usp=sharing', 'InformasiGladiKotorILITS2021'),
(161, 'Peminjaman Zoom Ini Lho ITS! 2021', 'https://docs.google.com/spreadsheets/d/1S0r-8wkpy3QhmRBJktZluZXhknSJlJfUcNCDB_TriK0/edit#gid=0', 'BookingZoomILITS2021'),
(162, 'Informasi Gathering Forda 4', 'https://drive.google.com/drive/folders/1q8OBeEiVWoOMhbIlgP-ZAkcj2zCQx1cH?usp=sharing', 'InformasiGatheringForda4'),
(163, 'Link Gathering Forda 4', 'https://zoom.us/j/97357008911?pwd=VGwyb0dLTWwvWHNHclgrdnlTaGV0Zz09', 'LinkGathForda4'),
(181, 'D-Day Lur', 'https://drive.google.com/drive/folders/1HMPAXvau0NhAfNign0aBBpOfaWN6Ld90?usp=sharing', 'DDayLur'),
(164, 'Folder Publikasi Sayembara Kreasi Tiktok', 'https://drive.google.com/drive/folders/1t8c73lgSoiOAhixbGiG-1Jr306q9dd7w?usp=sharing', 'KontenSayembaraTiktokILITS2021'),
(165, 'Juklak Juknis Talkshow Inspiratif', 'https://docs.google.com/spreadsheets/d/1icaYbqYTAl3cxsA8j164ciYQqtEAALQM21enGmTJhPU/edit?usp=sharing', 'JuklakJuknisTalktif'),
(166, 'Juklak Juknis Talkshow Inspiratif (link alternatif)', 'https://docs.google.com/spreadsheets/d/1icaYbqYTAl3cxsA8j164ciYQqtEAALQM21enGmTJhPU/edit?usp=sharing', 'JuklakJuknisTalkshowInspiratif'),
(167, 'Notulensi Gathering Forda 4 Inilhoits! 2021', 'https://docs.google.com/document/d/1NQWZE5c0g0rZRbcmuljqryJzzuahqgqKJontaV1O5rs/edit?usp=sharing', 'NotulensiGathForda4'),
(168, 'Presensi Gathering Forda 4', 'https://forms.gle/WQR4Lu6YbjxDhnMK6', 'PresensiGathForda4'),
(169, 'Feedback Gathering Forda 4', 'https://forms.gle/4A55fYMAFgJEx5n2A', 'FeedbackGathForda4'),
(170, 'Presensi gladi kotor open campus', 'https://docs.google.com/spreadsheets/d/1xomkiRuVj4ZmF868-nzM3K5UhVXhd01czKcEBiJg9ec/edit#gid=0', 'PresensiGladiKotorOpenCampus'),
(171, 'Feedback Gladi Kotor Open Campus', 'https://forms.gle/NDtUWaG18nJ24AFA7', 'FeedbackGladiKotorOpenCampus'),
(172, 'PPT ILITS Rektor dan Satgas Covid', 'https://docs.google.com/presentation/d/1eZM42AYGIABi_OKRJP9VM9NGQcBQdc7ipDfIYwp_nSs/edit?usp=sharing', 'PPTIniLhoITS2021'),
(173, 'Pembagian Room Fakultas', 'https://linktr.ee/BreakoutRoomFakultas', 'BreakoutRoomFakultas'),
(174, 'Notulensi FDKBD', 'https://docs.google.com/document/d/1HP43nQh9xgxaGeTO2g8BEHZNIx-zq2WVO0CGOoDyKWA/edit', 'NotulensiFDKBD'),
(175, 'Notulensi FSAD', 'https://docs.google.com/document/d/1aRZBYGMKwr5auSmtcWuY7G4tefSabKWhU7HEAbfTAng/edit', 'NotulensiFSAD'),
(176, 'Notulensi FTEIC', 'https://docs.google.com/document/d/1ESnMx_4sByCBX01VIDP2JGhfBXhn17nXASCPPGGbfow/edit', 'NotulensiFTEIC'),
(177, 'Notulensi FTIRS', 'https://docs.google.com/document/d/1pZrSh17msw4SwdShriNFJLMzMJXBDjJHWoc9bxjx3Ok/edit', 'NotulensiFTIRS'),
(178, 'Notulensi FTK', 'https://docs.google.com/document/d/1cytc5csWySDLN1Z2yC8CSEmhDVvzG7hTn8fo49z92aI/edit', 'NotulensiFTK'),
(179, 'Notulensi FTSPK', 'https://docs.google.com/document/d/1Nkxzld9TLFG6bfPriooXfB-Jd-0o6BaJzEOhbDTO8bU/edit', 'NotulensiFTSPK'),
(180, 'Notulensi FV', 'https://docs.google.com/document/d/1rpAAIWdrV2EcbmkUIVbz-QQp7_N8Fs9Yj2VgxlaQKcI/edit', 'NotulensiFV'),
(182, 'Booklet ILITS', 'https://drive.google.com/drive/folders/1eyzQTYPUA1l_X5Ba1VaLV0DDyMG4-umV', 'Booklet'),
(183, 'Gladi Bersih Open Campus', 'https://zoom.us/j/97357008911?pwd=VGwyb0dLTWwvWHNHclgrdnlTaGV0Zz09', 'GladiBersihOpenCampus'),
(184, 'OpenCampusILITSSesi1', 'https://zoom.us/j/96173266330?pwd=YlpzeGR1NVlxR0VTd2RBTUszS3E1dz09', 'OpenCampusILITSSesi1'),
(185, 'OpenCampusILITSSesi2', 'https://zoom.us/j/94832939994?pwd=VHRrbDJzNGxFNldKU0tQcWM1ZUZuUT09', 'OpenCampusILITSSesi2'),
(186, 'OpenCampusILITSSesi3', 'https://zoom.us/j/96173266330?pwd=YlpzeGR1NVlxR0VTd2RBTUszS3E1dz09', 'OpenCampusILITSSesi3'),
(187, 'OpenCampusILITSSesi4', 'https://zoom.us/j/99680624737?pwd=REFFdnN4blYrelpJQXRtTS9GZE91QT09', 'OpenCampusILITSSesi4'),
(188, 'OpenCampusILITSSesi5', 'https://zoom.us/j/93742808534?pwd=Vzk2RVhDS0lLUEowSWdWK0g1RUZuQT09', 'OpenCampusILITSSesi5'),
(189, 'OpenCampusILITSSesi6', 'https://zoom.us/j/96497555398?pwd=eGpTTFg2bCsvUmR3SDBPMkQ0V1dLZz09', 'OpenCampusILITSSesi6'),
(190, 'OpenCampusILITSSesi7', 'https://zoom.us/j/96497555398?pwd=eGpTTFg2bCsvUmR3SDBPMkQ0V1dLZz09', 'OpenCampusILITSSesi7'),
(191, 'Presensi Talk Show', 'https://forms.gle/zmrT1WC6djvfPQFPA', 'PresensiTalkshowInspiratifILITS2021'),
(192, 'Feedback Talkshow', 'https://forms.gle/tbtLcEG7cQafHDDj9', 'FeedbackTalkshowInspiratifILITS2021'),
(193, 'Presensi Gladi Bersih', 'https://docs.google.com/spreadsheets/d/1Wg0yJfC92RAUgkHR0aav2-J6TlEwrdUf-glDCM1mdOs/edit#gid=0', 'PresensiGladiBersihOpenCampus'),
(194, 'Feedback Gladi Bersih Open Campus', 'https://forms.gle/WHuUPwqXDwWSa8Tx7', 'FeedbackGladiBersihOpenCampus'),
(195, 'LIVE YT TALKSHOW', 'https://youtu.be/eHWGpHi0U98', 'LiveTalkshowILITS2021'),
(202, 'PRESENSI VISIT SMAK PETRA 2', 'https://docs.google.com/forms/d/e/1FAIpQLScKYG21Zm7MDc1GtRgkReDYquptLTHJWTq2yGRCVQfULI0M1A/viewform?usp=sf_link', 'PRESENSIVISITSMAKPETRA2'),
(203, 'FEEDBACK VISIT SMAK PETRA 2', 'https://docs.google.com/forms/d/e/1FAIpQLScOHF8brc2paHm9d6D6rSf5juMfXgrIGVGgbuA9avDFeXTq9A/viewform?usp=sf_link', 'FEEDBACKVISITSMAKPETRA2'),
(206, 'Presensi Panitia Talkshow', 'https://forms.gle/V32HKzBFYcf254Pd8', 'PresensiPanitiaTalkshowInspiratif'),
(201, 'PRESENSI VISIT SMAN 9 SURABAYA', 'https://forms.gle/TxXVqdPJneNmgreU7', 'PresensiVisitSMAN9SURABAYA'),
(200, 'FEEDBACK VISIT SMAN 9 SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLScxVHqmxhRjwMtRGKC6eeES1qCKwC33vRVnpoduDVmuhtgO7w/viewform?usp=sf_link', 'FeedbackVisitSMAN9SURABAYA'),
(204, 'PRESENSI VISIT SMAN 10 SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLSf12bocoIHqx6h2omVsG_3KYbD_mdICkNcCH-Z1aLvmGAHc-w/viewform?usp=sf_link', 'PresensiVisitSMAN10Sby'),
(205, 'FEEDBACK VISIT SMAN 10', 'https://docs.google.com/forms/d/e/1FAIpQLSfB9JIFfu7OhgeoC3O3rLV7D3MUKz6clSfkse5twW7_Ft1UAw/viewform?usp=pp_url', 'FeedbackVisitSMAN10Sby'),
(207, 'Presensi Talkshow Ins', 'https://forms.gle/V32HKzBFYcf254Pd8', 'PresensiPanitiaTalkshowInspiratifILITS2021'),
(208, 'Publikasi Open Campus', 'https://docs.google.com/spreadsheets/d/1O-P0Umvd-JReV5rDl5qifI3u8Vnx5XtlmZx07FJ9YAI/edit#gid=317731843', 'ReminderOpenCampus'),
(209, 'Virtual Background Open Campus', 'https://drive.google.com/file/d/10XxaMG9B1GcHaNC3c8YkN2ul71s8BQoM/view?usp=sharing', 'VirtualBackgroundOpenCampus'),
(210, 'Juklak Juknis Open Campus Talkshow Ruang Mimpi', 'https://docs.google.com/spreadsheets/d/1gh7x3YBnzg7FN0bWYM0_lnID3D5e9ehSH2K0I_6K840/edit#gid=0', 'JuklakJuknisRumpi'),
(211, 'Presensi Open Campus', 'https://forms.gle/cvXHiNu3PXdwkMoj6', 'PresensiOpenCampusILITS2021'),
(212, 'Link Cadangan Departemen', 'https://docs.google.com/spreadsheets/d/131D73p87dWssfkp9Zmr5GM2jqNSaGD0RxvUglZFUD48/edit#gid=0', 'BreakoutRoomDepartemen'),
(213, 'Live Open Campus Sesi 1', 'https://youtu.be/DF66uBb2_HQ', 'LiveOpenCampusSesi1'),
(214, 'Teknik Mesin', 'https://meet.google.com/bmc-mkik-tab', 'BreakoutRoomTeknikMesin'),
(215, 'Teknik Kimia', 'https://meet.google.com/hgj-eqtp-mas', 'BreakoutRoomTeknikKimia'),
(216, 'Linktre Sesi 1', 'https://linktr.ee/BreakoutroomOpenCampusSesi1', 'BreakoutroomOpenCampusSesi1'),
(217, 'Feedback Open Campus Sesi 1', 'https://forms.gle/W8RP7Nk2u4Jz5gxX9', 'FeedbackOpenCampusSesi1'),
(218, 'Presensi Panitia DAY-1 SESI 1', 'https://forms.gle/CxEyjup7MXpygmqL9', 'PresensiPanitiaDay1Sesi1'),
(219, 'Presensi Open Campus Day-1 Sesi 2', 'https://forms.gle/sxhpBxowda7pwE7A8', 'PresensiOpenCampusDAY1Sesi2'),
(220, 'Feedback Open Campus Sesi 2', 'https://forms.gle/oqUDGgp8DJ7AhuWP7', 'FeedbackOpenCampusSesi2'),
(221, 'Live Open Campus Sesi 2', 'https://youtu.be/_Kg4Pt9wJrA', 'LiveOpenCampusSesi2'),
(222, 'Presensi Panitia DAY-1 SESI 2', 'https://forms.gle/QqSHLZ3booqcgYfh7', 'PresensiPanitiaDay1Sesi2'),
(223, 'Presensi Open Campus Day-1 Sesi 3', 'https://forms.gle/s3aUbuZSMhdY2ibY8', 'PresensiOpenCampusDAY1Sesi3'),
(224, 'Feedback Open Campus Sesi 3', 'https://forms.gle/RwzoBgNYhvm2kRCA6', 'FeedbackOpenCampusSesi3'),
(225, 'Presensi Panitia DAY-1 SESI 3', 'https://forms.gle/VqfQSzeV2GDSbo6R8', 'PresensiPanitiaDay1Sesi3'),
(226, 'Live Open Campus Sesi 3', 'https://youtu.be/et0i39JVvHU', 'LiveOpenCampusSesi3'),
(227, 'PRESENSI VISIT SMAN 15 SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLScTTFwKgvl2y6t8laXPz875BQRl2MWZ8Q7FczTnxWL-pY1K1g/viewform?usp=sf_link', 'PRESENSIVISITSMAN15SBY'),
(228, 'FEEDBACK VISIT SMAN 15 SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLSf7cwNaJnRlyImdSpEKWiGfwz1jwUvCumlaR4MehMtatK42hA/viewform?usp=sf_link', 'FEEDBACKVISITSMAN15SBY'),
(229, 'PRESENSI ROADSHOW UMUM', 'https://docs.google.com/forms/d/e/1FAIpQLSf2VtKFipAHP8h9xsP8M-Tuw3hzGVVdjhn2gBxvild4KJ3zKQ/viewform?usp=sf_link', 'PRESENSISCHOOLVISITILITS2021'),
(230, 'PRESENSI ROADSHOW UMUM', 'https://docs.google.com/forms/d/e/1FAIpQLSfovLR-n0IS_IySmNVqegNwr3V-OqNXp33ataU5rYBKrBoKZg/viewform?usp=sf_link', 'FEEDBACKSCHOOLVISITILITS2021'),
(231, 'Presensi Gladi bersih sesi 1', 'https://docs.google.com/spreadsheets/d/1WT1RfF3KgTWPMyDcjxdzYvmvUzIYxj0-THX6DMixen8/edit#gid=0', 'PresensiGladiBersihOpenCampusSesi1'),
(232, 'Gladi Bersih Open Campus Sesi 2', 'https://docs.google.com/spreadsheets/d/15pB_iYXBKZufYVFXNG5Wn7iTSsZkTBfi3wchAE-2Cjs/edit#gid=0', 'PresensiGladiBersihOpenCampusSesi2'),
(233, 'PRESENSI VISIT UMUM ILITS', 'https://docs.google.com/forms/d/e/1FAIpQLSe5AfwSlc73KqoIBfK8P7WJTJNADWBJUu0LHY4ffvIJb_fMlw/viewform?usp=sf_link', 'PresensiVisitUmumILITS2021'),
(234, 'FEEDBACK VISIT UMUM ILITS', 'https://docs.google.com/forms/d/e/1FAIpQLSciqNBvMbd4zAsc7yxFuaZMUhcXQkxLr5fTLmoHhDV38zM-mA/viewform?usp=sf_link', 'FeedbackVisitUmumILITS2021'),
(235, 'Feedback Gladi Kotor Open Campus 1', 'https://forms.gle/xekhRamqgA7aS2Y26', 'FeedbackGladiBersihOpenCampusSesi1'),
(236, 'Feedback Gladi Bersih Open Campus 2', 'https://forms.gle/XZHAQMPqHU8KPSqE9', 'FeedbackGladiBersihOpenCampusSesi2'),
(237, 'Plottingan Peserta Dummy', 'https://drive.google.com/file/d/1AQ_xtL45iy4Xhkf6pXZcajvv2KgRDGfM/view?usp=sharing', 'DummyData'),
(238, 'Video untuk Forda Visit dan Welcome', 'https://drive.google.com/drive/folders/1MN16bwZikzXou-jUD6voctyc8O0cv8HP?usp=sharing', 'VideoPendukungVisitWelcomeILITS2021'),
(239, 'Feedback Gathering Forda 5', 'https://forms.gle/CJTUhj133YGZdUddA', 'FeedbackGathForda5'),
(240, 'Presensi Gath Forda 5', 'https://forms.gle/UHszZ8upqm7s3S6w5', 'PresensiGathForda5'),
(241, 'Notulensi Gath Forda 5', 'https://docs.google.com/document/d/1bJudGVBQR_Vv5o800TsCgQUiazxaQHVvvPT5mtHt37M/edit?usp=sharing', 'NotulensiGathForda5'),
(242, 'Presensi Open Campus Day 2 Sesi 1', 'https://docs.google.com/forms/d/e/1FAIpQLSe5ItgoMMUWWDFygUyM6VvZDwB8QYWQ5dzzAxLZJIyHdm8-cg/viewform?usp=pp_url', 'PresensiOpenCampusDay2Sesi1'),
(243, 'Feedback Open Campus Day 2 Sesi 1', 'https://docs.google.com/forms/d/e/1FAIpQLSdUmkFgKy7nNakxKe0paVjlg0dx910e6Ngp0_ju8TpYpB4VaA/viewform?usp=pp_url', 'FeedbackOpenCampusDay2Sesi1'),
(244, 'Presensi Open Campus Day 2 Sesi 2', 'https://docs.google.com/forms/d/e/1FAIpQLSchihztAWNhmXLwVK_eAKQKo-ILNvmsDtMvuX0Ug8krGYFxvw/viewform?usp=pp_url', 'PresensiOpenCampusDay2Sesi2'),
(245, 'Feedback Open Campus Day 2 Sesi 2', 'https://docs.google.com/forms/d/e/1FAIpQLSeY3wFHq_MBCbIrg5ghfHnhnEKpbiQCC0HCJgvDOPjuH8r_Lw/viewform?usp=pp_url', 'FeedbackOpenCampusDay2Sesi2'),
(246, 'Presensi Panitia DAY-2 SESI 1', 'https://forms.gle/BoRP4XETe9PoxAT48', 'PresensiPanitiaDay2Sesi1'),
(247, 'Presensi Panitia DAY-2 SESI 2', 'https://forms.gle/v3mpRAhjASSn6hpQ6', 'PresensiPanitiaDay2Sesi2'),
(248, 'Live Open Campus Sesi 4', 'https://youtu.be/hEEdxpawQeQ', 'LiveOpenCampusSesi4'),
(249, 'Live Open Campus Sesi 5', 'https://youtu.be/cDtx7WlwttA', 'LiveOpenCampusSesi5'),
(250, 'Presensi Open Campus Day-3 Sesi 1', 'https://forms.gle/uX455RJ1qfT4tuW1A', 'PresensiOpenCampusDAY3Sesi1'),
(251, 'Feedback Open Campus Sesi 3', 'https://forms.gle/ctiGLN2Q4nq3Qikv6', 'FeedbackOpenCampusSesi6'),
(252, 'Presensi Open Campus Day-3 Sesi 2', 'https://forms.gle/Rta2XqVPLjkS2waw7', 'PresensiOpenCampusDAY3Sesi2'),
(253, 'Feedback Open Campus Sesi 7', 'https://forms.gle/FoojG6etjxcNArsc6', 'FeedbackOpenCampusSesi7'),
(254, 'Presensi Panitia DAY-3 SESI 1', 'https://forms.gle/o592VqycHxcyQGrbA', 'PresensiPanitiaDay3Sesi1'),
(255, 'Presensi Panitia DAY-3 SESI 2', 'https://forms.gle/Mhg8kpECpJApzw2B8', 'PresensiPanitiaDay3Sesi2'),
(256, 'Live Open Campus Sesi 6', 'https://youtu.be/doTuoltFlnE', 'LiveOpenCampusSesi6'),
(257, 'Live Open Campus Sesi 7', 'https://youtu.be/LvijV_n2V9c', 'LiveOpenCampusSesi7'),
(258, 'Presensi Rakom II', 'https://forms.gle/rctD7PncLvfUnjLv7', 'PresensiRakom2'),
(259, 'Feedback Rapat Komunal 2', 'https://forms.gle/FAGAWS2zjzJcbtM98', 'FeedbackRakom2'),
(261, 'PRESENSI VISIT SMA 5 SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLSeX4N1J35RBhQhN710G89-QyTyV3GuZuRd2Hab-qZ09Gza2pQ/viewform', 'PresensiVisitSMA5Surabaya'),
(262, 'FEEDBACK VISIT SMA 5 SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLSfovLR-n0IS_IySmNVqegNwr3V-OqNXp33ataU5rYBKrBoKZg/viewform', 'FeedbackVisitSMA5Surabaya'),
(263, 'Presensi Visit SMAN 4 Surabaya', 'https://docs.google.com/forms/d/e/1FAIpQLSe5yPhmTW4n_AF4tg9WwoQaYUp_FvKd8q0zvqNqtPTlhiYgHw/viewform?usp=sf_link', 'PRESENSIVISITSMAN4SBY'),
(264, 'Feedback Visit SMAN 4 Surabaya', 'https://docs.google.com/forms/d/e/1FAIpQLSfjSf5VPJY6SbdwvaGqK0z-iJdyjyLLNwM9R9_Q327lSDjLgA/viewform?usp=sf_link', 'FEEDBACKVISITSMAN4SBY'),
(265, 'Presensi Panitia Gathering Forda 5', 'https://forms.gle/xH777rbj2AZcC1MZ8', 'PresensiPanitiaGathForda5'),
(266, 'Welcome Surabaya', 'https://drive.google.com/drive/folders/1B0EkoHwi9npt_wHU8nwNpxd0sYpofD2L?usp=sharing', 'WelcomeSurabaya'),
(267, 'Design Per Departemen', 'https://drive.google.com/drive/folders/1azbFSK0p84Oz0ITJ1Dv3sYKkV8K-jHB1?usp=sharing', 'DesignDepartemen'),
(268, 'Video & Tatib untuk Forda', 'https://drive.google.com/drive/folders/1al9Bzs4_-hAOVZ_l0tqsOQSzA6WOifx9?usp=sharing', 'VideodanTatib'),
(270, 'Presensi Visit Umum 3.0', 'https://forms.gle/FnUCJYX7KMydU7Gw9', 'PresensiVisitUmum3'),
(271, 'Feedback Visit Umum 3.0', 'https://forms.gle/jGR1jrM5V5pAaw1t6', 'FeedbackVisitUmum3'),
(272, 'Jadwal Screening I Nose Panitia ILITS', 'https://docs.google.com/spreadsheets/d/1kIX58uLnOvmN7YvaFGSd4Dm4py9wlxvufcNhCT7Nkss/edit?usp=sharing', 'JadwalScreeningINosePanitiaILITS'),
(273, 'Contoh Feedback Welcome Forda', 'https://forms.gle/mGgY2U3gu324e8LX6', 'ContohFeedbackWelcomeForda'),
(274, 'Presensi Gladi Kotor Welcome', 'https://forms.gle/HwGLstBHSBsq6VU27', 'PresensiGladiKotorWelcome'),
(275, 'Record Gladi Kotor Pengawas', 'https://1drv.ms/u/s!Agzqpt0uGFnLsVrDIdfPon-XvMYD?e=gpteIf', 'RecordGladiKotorPengawas'),
(276, 'Record Gladi Kotor Pengawas', 'https://1drv.ms/u/s!Agzqpt0uGFnLsVruMwXgK88bckpP?e=oRNqLj', 'GladiKotorPengawas'),
(277, 'Jadwal Gladi Bersih Welcome Surabaya', 'https://docs.google.com/spreadsheets/d/1rBh1Zf1Yh0hbS0ma90xTMmoS0eidzjZu5yHI9gJCgB8/edit?usp=sharing', 'JadwalGladiBersihWelcomeSurabaya'),
(280, 'Presensi Welcome Surabaya Ini Lho ITS! 2021', 'https://forms.gle/wZJd9zyzLi1rEMFw7', 'PresensiRoom5'),
(279, 'Presensi Welcome Surabaya Room 8', 'https://docs.google.com/forms/d/e/1FAIpQLSfN-hyI5igbhgEy2-QX0tb16X-ccmybndGLG0g8BmY4NTFqpQ/viewform?usp=sf_link', 'PresensiRoom8'),
(281, 'Presensi Welcome SBY Ini Lho ITS 2021', 'https://docs.google.com/forms/d/e/1FAIpQLSfZeaaqZRzAzH66bl0LwhTQTVuSDx5CXVLGEGWR7IDR3r2UPA/viewform', 'PresensiBreakOutRoom7'),
(282, 'Presensi Breakout Room 9 Welcome Surabaya', 'https://docs.google.com/forms/d/e/1FAIpQLSe2frLgPkeDpFSxhgnOLaunRPqnaZziqQ6yXIhxmpcRJZKr9Q/viewform?usp=pp_url', 'PresensiBreakoutroom9'),
(290, 'BREAKOUT ROOM 10', 'https://docs.google.com/forms/d/e/1FAIpQLScaGlYV0KEzP4OvQAjnZHVo3CaE4yzPRT15OKcaEpeu9_MBHw/viewform?usp=sf_link', 'BREAKOUTROOM10'),
(286, 'Link Presensi', 'https://docs.google.com/forms/d/e/1FAIpQLSdolVxPW22k8NNLOj39Lk6-kRkz8CZXWE9U_thYOTIODIlfkA/viewform?usp=sf_link', 'Room4'),
(287, 'Presensi Welcome Room 1', 'https://forms.gle/YAEFYq5Fsp2amgjb9', 'PresensiWelcomeRoom1'),
(289, 'Presensi Welcome Surabaya Room 2', 'https://forms.gle/HrMcNYGU66kx9GmTA', 'PresensiBreakoutRoom2'),
(291, 'Feedback Welcome Surabaya', 'https://forms.gle/KFhc5AyuJrypyS6X7', 'FeedbackWelcomeSurabaya'),
(292, 'PRESENSI WELCOME SURABAYA ROOM 6', 'https://forms.gle/kvDmMPNyeWvfdGD3A', 'PresensiWelcomeSurabayaRoom6'),
(293, 'Jadwal Gladi Welcome Forda', 'https://docs.google.com/spreadsheets/d/1A0h6X4309_3FNORXH2BBDQJMJWi8cAxrIeU4bQ6u7T4/edit#gid=0', 'JadwalGladiWelcomeForda'),
(294, 'Presensi Visit SMK 5 Surabaya', 'https://docs.google.com/forms/d/e/1FAIpQLSdEWPF5dxdOgE-QvDefJN6GSyW4C2iriiO-5YyBzEbgMKD-rw/viewform?usp=sf_link', 'PresensiVisitSMK5Surabaya'),
(295, 'Feedback Visit SMK 5 Surabaya', 'https://docs.google.com/forms/d/e/1FAIpQLScsKy2VkqNVO9CxZGAkVACjjHKxtgSu0xKVJB2zR4dnEByCTw/viewform?usp=sf_link', 'FeedbackVisitSMK5Surabaya'),
(296, 'Presensi SMA AL HIKMAH', 'https://docs.google.com/forms/d/e/1FAIpQLSesCT370Jd_KuasKVwmTg3BNKsyLKurYe3ER3YMpFP--yybGQ/viewform?usp=sf_link', 'PresensiSMAALHIKMAH'),
(297, 'Feedback SMA AL HIKMAH SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLSd5upNDpiaYUbNGq07W5nlMI-PouhqjCaZ427V_G7g_kNZnJQ/viewform?usp=sf_link', 'FeedbackSMAALHIKMAH'),
(298, 'Dokumen dan Video Welcome Forda ILITS 2021', 'https://drive.google.com/drive/folders/1al9Bzs4_-hAOVZ_l0tqsOQSzA6WOifx9?usp=sharing', 'FileWelcomeFordaILITS2021'),
(299, 'Tata Tertib dan Petunjuk Teknis Peserta ILITS', 'https://docs.google.com/document/d/1noHPoABEnLSOB1JXLgOlQHpWZQ9EmeCW5U847WK0m7g/edit?usp=sharing', 'TatibJuknisTOPesertaILITS'),
(300, 'PRESENSI WELCOME SURABAYA ROOM 3', 'https://forms.gle/un2Xxhsyek1HWFbT8', 'PresensiWelcomeSurabayaRoom3'),
(301, 'PRESENSI PANITIA GLADI BERSIH WELCOME SURABAYA', 'https://docs.google.com/forms/d/e/1FAIpQLScIbeP13zhuAdytSJumAo8zJShYAfSXR-4AVaoAR627eFvGug/viewform?usp=sf_link', 'PresensiPanitiaGladiWelcome'),
(302, 'Proctor', 'https://docs.google.com/spreadsheets/d/1doE0BLhBGH68s2axdqaHZMsjMXAKKMvzQ3XweAWD15U/edit#gid=0', 'OALAHCUK'),
(304, 'Tracker Controlling Welcome Forda', 'https://docs.google.com/spreadsheets/d/1A0h6X4309_3FNORXH2BBDQJMJWi8cAxrIeU4bQ6u7T4/edit?usp=sharing', 'TrackerWelcomeForda'),
(305, 'Presensi TO Room 10', 'https://docs.google.com/forms/d/e/1FAIpQLScaGlYV0KEzP4OvQAjnZHVo3CaE4yzPRT15OKcaEpeu9_MBHw/viewform?usp=sf_link', 'PresensiTORoom10'),
(306, 'Presensi Welcome Surabaya', 'https://forms.gle/jKhp1k8CLVXbzLtRA', 'PresensiWelcomeSurabaya'),
(307, 'Feedback Welcome Surabaya', 'https://forms.gle/6xpCjCkJajqFC9mt6', 'FeedbackWelcomeSurabaya2021'),
(308, 'Plotting Room Welcome Ini Lho ITS! 2021', 'https://drive.google.com/file/d/1Zvc4hx5QTtMukvv7ZpK41-628QfDcEMp/view?usp=sharing', 'RoomPesertaSurabaya'),
(309, 'Live Report Welcome Forda', 'https://drive.google.com/drive/folders/1BW7dkq1nBDnEebGQuCVEJqMIBS5OXYu_?usp=sharing', 'LiveReportWelcomeForda'),
(310, 'Live Stream Welcome Surabaya Ini Lho ITS! 2021', 'https://youtu.be/V8hkvzorYL4', 'LiveStreamWelcome'),
(311, 'Live Stream Welcome Surabaya Ini Lho ITS! 2021 Ralat', 'https://www.youtube.com/watch?v=V8hkvzorYL4', 'LiveStreamWelcome2'),
(312, 'list kendala', 'https://docs.google.com/spreadsheets/d/1ctDLKz_QHg2hHJEisXvwGN2cOoxb0HclLE77Y8-hRjQ/edit#gid=0list', 'gatelcuk'),
(313, 'Database Panitia ILITS 2021', 'https://docs.google.com/spreadsheets/d/1rr92tMZoGRlxFVUGaKQEaFpFccIj-J3xkb8CAvotcX4/edit?usp=sharing', 'DatabasePanitiaILITS2021'),
(314, 'Rapat 3 Virtual Expo', 'https://docs.google.com/document/d/1jx-JnQer4DfKSM_LzkT9qR6wiiBrN1V4NX1y-TQVSoI/edit?usp=sharing', 'Rapat3Virpo'),
(315, 'NotulensiControllingForda', 'https://docs.google.com/document/d/1hI7jkAv_RK7XMPLEw8HP6S3k_7qczTaCNosw9eC4eQ4/edit?usp=sharing', 'NotulensiControllingForda'),
(316, 'Kesimpulan Rapat 3 Virtual Expo', 'https://docs.google.com/document/d/1L1ksKktd5Hz9wktZpdZBGX-lZbi4nMmh6Vf4H9MgGYc/edit', 'KesimpulanRapat3Virpo'),
(317, 'Format dan Kebutuhan Data LPJ ILITS 2021', 'https://docs.google.com/spreadsheets/d/16IZnmhIRDDhE0AaXib5UR7eyPOaZikgpGkbvRfUsMDg/edit?usp=sharing', 'KebutuhanDataLPJILITS2021'),
(318, 'Laporan Khusus Ini Lho ITS 2021', 'https://docs.google.com/spreadsheets/d/1cmvdernMwaPJvvxnMppZ4VGgU_nrUnTrNvIi8hLbvCU/edit?usp=sharing', 'LaporanKhususILITS2021'),
(319, 'Folder LPJ ILITS 2021', 'https://drive.google.com/drive/folders/1L1iNa-UptjGj7TECtej9EbHSvZrqDb4Y?usp=sharing', 'LPJILITS2021');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_bundle`
--

CREATE TABLE `tabel_bundle` (
  `id` int(11) NOT NULL,
  `product` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `hoodie` int(11) DEFAULT NULL,
  `shirt` int(11) DEFAULT NULL,
  `totebag` int(11) DEFAULT NULL,
  `cap` int(11) DEFAULT NULL,
  `keychain` int(11) DEFAULT NULL,
  `bracelet` int(11) DEFAULT NULL,
  `lanyard` int(11) DEFAULT NULL,
  `stickerbook` int(11) DEFAULT NULL,
  `data-target` varchar(128) NOT NULL,
  `weight` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_bundle`
--

INSERT INTO `tabel_bundle` (`id`, `product`, `price`, `hoodie`, `shirt`, `totebag`, `cap`, `keychain`, `bracelet`, `lanyard`, `stickerbook`, `data-target`, `weight`) VALUES
(1, 'Red Pack', '229000', NULL, 1, 1, 1, 1, 1, 1, 1, 'red-pack', 1100),
(2, 'Orange Pack', '199000', NULL, 1, 1, NULL, 1, 1, 1, 1, 'orange-pack', 850),
(3, 'Yellow Pack', '149000', NULL, NULL, 1, 1, 1, 1, NULL, 1, 'yellow-pack', 700),
(4, 'Green Pack', '149000', NULL, 1, NULL, NULL, 1, 1, 1, 1, 'green-pack', 650),
(5, 'Blue Pack', '285000', 1, NULL, 1, 1, 1, 1, 1, 1, 'blue-pack', 1300),
(6, 'Purple Pack', '249000', 1, NULL, 1, NULL, 1, 1, 1, 1, 'purple-pack', 1100),
(7, 'Lylac Pack', '185000', 1, NULL, NULL, NULL, 1, 1, 1, 1, 'lylac-pack', 900),
(8, 'Peach Pack', '94000', NULL, NULL, NULL, 1, 1, 1, 1, 1, 'peach-pack', 600);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_images`
--

CREATE TABLE `tabel_images` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `image` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_images`
--

INSERT INTO `tabel_images` (`id`, `code`, `image`) VALUES
(1, 'HD-01', 'hd01-front.png'),
(2, 'HD-01', 'hd01-back.png'),
(4, 'HD-02', 'hd02-front.png'),
(5, 'HD-02', 'hd02-back.png'),
(6, 'TS-01', 'ts01-front.png'),
(7, 'TS-01', 'ts01-back.png'),
(8, 'TS-02', 'ts02-front.png'),
(9, 'TS-02', 'ts02-back.png'),
(10, 'TS-TDYE-01', 'ts-tdye-01.png'),
(11, 'TS-TDYE-02', 'ts-tdye-02.png'),
(12, 'TS-TDYE-03', 'ts-tdye-03.png'),
(13, 'TB-01', 'tb01.png'),
(14, 'TB-02', 'tb02.png'),
(15, 'TB-TDYE-01', 'tb-tdye-01.png'),
(16, 'KC-01', 'kc01.png'),
(17, 'KC-02', 'kc02.png'),
(18, 'KC-03', 'kc03.png'),
(19, 'RB-01', 'rb02.jpg'),
(20, 'RB-02', 'rb01.jpg'),
(21, 'LY-01', 'ly01.png'),
(22, 'SB-01', 'stickerpack.png'),
(23, 'DC-01', 'dc01.jpg'),
(24, 'DC-02', 'dc02.jpg'),
(25, 'TB-01', 'tb01model.JPG'),
(26, 'TB-02', 'tb02model.png'),
(27, 'TS-01', 'ts01-1.JPG'),
(28, 'TS-01', 'ts01-2.JPG'),
(29, 'TS-01', 'ts01-3.JPG'),
(30, 'TS-01', 'ts01-4.JPG'),
(31, 'TS-02', 'ts02-1.JPG'),
(32, 'TS-02', 'ts02-2.JPG'),
(33, 'TS-02', 'ts02-3.JPG'),
(34, 'TS-02', 'ts02-4.JPG'),
(35, 'TS-TDYE-01', 'ts-tdye-01-1.JPG'),
(36, 'TS-TDYE-01', 'ts-tdye-01-2.JPG'),
(39, 'TS-TDYE-02', 'ts-tdye-02-1.JPG'),
(40, 'TS-TDYE-02', 'ts-tdye-02-2.JPG'),
(41, 'TS-TDYE-03', 'ts-tdye-03-1.JPG'),
(42, 'TS-TDYE-03', 'ts-tdye-03-2.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_product`
--

CREATE TABLE `tabel_product` (
  `id` int(11) NOT NULL,
  `product` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `category` varchar(128) NOT NULL,
  `code` varchar(50) NOT NULL,
  `catalog` varchar(128) NOT NULL,
  `weight` int(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_product`
--

INSERT INTO `tabel_product` (`id`, `product`, `price`, `category`, `code`, `catalog`, `weight`, `description`) VALUES
(31, 'Kampoes Perdjoeangan', '140000', 'Hoodie', 'HD-01', 'hd01-front.png', 500, 'Hoodie kampoes perdjoangan (HD-01)<br>\r\nHoodie Kampoes Perdjoeangan ini terinspirasi dari latar belakang kampus ITS yang didirikan dengan semangat perjuangan para pahlawan kita.<br>\r\nDiproduksi menggunakan bahan fleece yang halus dengan sablon digital printing, tentunya membuat kalian nyaman dan puas ketika memakai hoodie ini.<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(32, 'Arek ITS Cak', '140000', 'Hoodie', 'HD-02', 'hd02-front.png', 500, 'Hoodie arek its cak (HD-02)<br>\r\nHoodie Arek ITS CAK terinspirasi dari jargon yang dimiliki anak ITS (CAK) yang berarti Cerdas, Amanah, dan Kreatif.<br>\r\nDiproduksi menggunakan bahan fleece yang halus dengan sablon digital printing, tentunya membuat kalian nyaman dan puas ketika memakai hoodie ini.<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(33, 'Arek ITS Cak', '90000', 'T-Shirt', 'TS-01', 'ts01-front.png', 250, 'Kaos arek its cak (TS-01)<br>\r\nKaos Arek ITS CAK terinspirasi dari jargon yang dimiliki anak ITS (CAK) yang berarti Cerdas, Amanah, dan Kreatif.<br>\r\nDiproduksi menggunakan bahan cotton combed 30s premium dengan sablon digital printing, tentunya membuat kenyamanan dan kepuasan tersendiri buat kalian yang beli kaos ini.<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(34, 'Vivat 10 Nop', '90000', 'T-Shirt', 'TS-02', 'ts02-front.png', 250, 'Kaos vivat 10 nopember (TS-02)<br>\r\nKaos Vivat 10 Nopember terinspirasi dari ciri-ciri kampus kita tercinta yaitu berkaitan dengan teknologi.<br>\r\nDiproduksi menggunakan bahan cotton combed 30s premium dengan sablon digital printing, tentunya membuat kenyamanan dan kepuasan tersendiri buat kalian yang beli kaos ini.<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(35, 'Future Engineer Black', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-01', 'ts-tdye-01.png', 250, 'TS-TDYE-01<br>\r\nKaos tiedye \"Future Engineer\" ini cocok buat kamu yang suka dengan perpaduan warna yang unik.<br>\r\nDiproduksi menggunakan bahan cotton combed 30s premium dengan sablon digital printing, tentunya membuat kenyamanan dan kepuasan tersendiri buat kalian yang beli kaos ini!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa! '),
(36, 'Future Engineer Purple', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-02', 'ts-tdye-02.png', 250, 'TS-TDYE-02<br>\r\nKaos tiedye \"Future Engineer\" ini cocok buat kamu yang suka dengan perpaduan warna yang unik.<br>\r\nDiproduksi menggunakan bahan cotton combed 30s premium dengan sablon digital printing, tentunya membuat kenyamanan dan kepuasan tersendiri buat kalian yang beli kaos ini!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa! '),
(37, 'Future Engineer Blue', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-03', 'ts-tdye-03.png', 250, 'TS-TDYE-03<br>\r\nKaos tiedye \"Future Engineer\" ini cocok buat kamu yang suka dengan perpaduan warna yang unik.<br>\r\nDiproduksi menggunakan bahan cotton combed 30s premium dengan sablon digital printing, tentunya membuat kenyamanan dan kepuasan tersendiri buat kalian yang beli kaos ini!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa! '),
(38, 'Stay Up Late', '60000', 'Totebag', 'TB-01', 'tb01.png', 200, 'Totebag stay up late (TB-01<br>\r\nTerinspirasi dari kebiasaan mahasiswa ITS yang suka begadang karena kesibukan mereka, totebag ini hadir untuk melengkapimu!<br>\r\nDiproduksi menggunakan bahan kanvas yang halus dan tebal dengan sablon plastisol, tentunya tidak akan membuat kalian kecewa dengan membeli totebag ini!<br>\r\nEitsss, totebag ini juga dilengkapi dengan ritsleting yang dapat mengamankan barang kalian!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(39, 'Snooze or Sleep', '60000', 'Totebag', 'TB-02', 'tb02.png', 200, 'Totebag snooze to sleep (TB-02)<br>\r\nTotebag ini menggambarkan kebiasaan anak ITS yang menunda tidur untuk melakukan kesibukan mereka sehingga muncul jargon \"Iso Turu Sangar\"<br>\r\nDiproduksi menggunakan bahan kanvas yang halus dan tebal dengan sablon plastisol, tentunya tidak akan membuat kalian kecewa dengan membeli totebag ini!<br>\r\nEitsss, totebag ini juga dilengkapi dengan ritsleting yang dapat mengamankan barang kalian!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(40, 'Tie Dye World Class Engineer', '60000', 'Totebag', 'TB-TDYE-01', 'tb-tdye-01.png', 200, 'Totebag World Class Engineer (TB-TDYE-01)<Br>\r\nTotebag tiedye \"World Class Engineer\" ini cocok buat kamu yang suka dengan perpaduan warna yang unik.<br>\r\nDiproduksi menggunakan bahan kanvas yang halus dan tebal dengan sablon plastisol, tentunya tidak akan membuat kalian kecewa dengan membeli totebag ini!\r\n<br>\r\nEitsss, totebag ini juga dilengkapi dengan ritsleting yang dapat mengamankan barang kalian!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(41, '1957 ITS Robot', '15000', 'Keychain', 'KC-01', 'kc01.png', 100, 'Keychain 1957 ITS robot (KC-01)<br>\r\nGantungan kunci \"1957 ITS Robot\" ini terinspirasi dari ciri-ciri kampus kita tercinta yaitu berkaitan dengan teknologi.<br>\r\nDiproduksi menggunakan bahan acrylic dengan print dalam 2 sisi tentunya membuat gantungan kunci ini lebih menarik dan awet ketika dipakai!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(42, 'Attention Please', '15000', 'Keychain', 'KC-02', 'kc02.png', 100, 'Keychain attention please (KC-02)<br>\r\nGantungan kunci \"Attention Please!\" Ini terinspirasi dari banyaknya orang yang mengira bahwa ITS itu singkatan dari Institut Teknologi Surabaya, tetapi sebenarnya adalah Institut Teknologi Sepuluh Nopember.<br>\r\nDiproduksi menggunakan bahan acrylic dengan print dalam 2 sisi tentunya membuat gantungan kunci ini lebih menarik dan awet ketika dipakai!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(43, 'Your Future Engineer', '15000', 'Keychain', 'KC-03', 'kc03.png', 100, 'Keychain your future engineer (KC-03)<br>\r\nGantungan kunci \"Your Future Engineer\" ini cocok sebagai bahan motivasi kamu yang bercita-cita menjadi seorang engineer!<br>\r\nDiproduksi menggunakan bahan acrylic dengan print dalam 2 sisi tentunya membuat gantungan kunci ini lebih menarik dan awet ketika dipakai!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(44, '10 Nopember', '15000', 'Gelang', 'RB-01', 'rb02.jpg', 100, 'Gelang Sepuluh Nopember (RB-01)<br>\r\nGelang Seluluh Nopember ini cocok buat kamu yang cinta dengan kampus kebanggan kita semua yaitu ITS!<br>\r\nDiproduksi menggunakan bahan synthetic rubber dengan rubber printing tentunya membuat gelang ini menjadi lebih bagus dan awet ketika digunakan!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(45, 'World Class Engineer', '15000', 'Gelang', 'RB-02', 'rb01.jpg', 100, 'Gelang world class engineer (RB-02)<br>\r\nGelang \"World Class Engineer\" ini cocok sebagai bahan motivasi kamu yang bercita-cita menjadi seorang engineer yang hebat!<br>\r\nDiproduksi menggunakan bahan synthetic rubber dengan rubber printing tentunya membuat gelang ini menjadi lebih bagus dan awet ketika digunakan!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(46, 'World Class Engineer', '15000', 'Lanyard', 'LY-01', 'ly01.png', 100, 'Lanyard (LY-01)<br>\r\nLanyard \"World Class Engineer\" ini cocok sebagai bahan motivasi kamu yang bercita-cita menjadi seorang engineer yang hebat!<br>\r\nDiproduksi menggunakan bahan polyster yang kuat dengan sablon sublime printing, tentunya tidak akan membuat kalian kecewa dengan membeli lanyard ini!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(47, '8 in 1 Collection', '20000', 'Stiker', 'SB-01', 'stickerpack.png', 100, 'Stiker bundle (SB-01)<br>\r\nStiker bundle ini merupakan paket komplit yang wajib kalian miliki!<br>\r\nDiproduksi menggunakan bahan vinyl yang tahan air tentunya membuat stiker ini lebih awet!<br>\r\nDitambah dengan potongan kiss cut yang tentunya membuat potongan lebih rapi dan tidak menyusahkan kalian ketika mau memakai stiker ini!<br>Tunggu apalagi? Yuk segera diorder merchnyaa!'),
(48, 'OG 10 Nop', '40000', 'Dad Cap', 'DC-01', 'dc01.jpg', 200, 'Topi Og sepuluh nopember (DC-01)<br>\r\nDengan desain yang simpel dengan tulisan 10 Nopember, topi ini cocok buat kamu yang suka bepergian tapi takut kepanasan.<br>\r\nDiproduksi menggunakan bahan american drill dengan logo yang dibordir, tentunya membuat kalian yang beli topi ini gabakal kepanasan lagi deh ketika dipakai!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!'),
(49, 'OG Logo White', '40000', 'Dad Cap', 'DC-02', 'dc02.jpg', 200, 'Topi Og logo white (DC-02)<br>\r\nDengan desain yang simpel yaitu logo kampus tercinta kita ITS, topi ini cocok buat kamu yang suka bepergian tapi takut kepanasan.<br>\r\nDiproduksi menggunakan bahan american drill dengan logo yang dibordir, tentunya membuat kalian yang beli topi ini gabakal kepanasan lagi deh ketika dipakai!<br>\r\nTunggu apalagi? Yuk segera diorder merchnyaa!');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_referral`
--

CREATE TABLE `tabel_referral` (
  `id` int(11) NOT NULL,
  `code` varchar(128) DEFAULT NULL,
  `forda` varchar(128) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `max` int(20) DEFAULT NULL,
  `free` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_referral`
--

INSERT INTO `tabel_referral` (`id`, `code`, `forda`, `discount`, `max`, `free`) VALUES
(2, 'ILITSxTUBAN', 'Tuban', NULL, NULL, 'Gelang/Stiker'),
(3, 'ILITSxSAMARINDA', 'samarinda', NULL, NULL, 'Gelang/Stiker'),
(4, 'ILITSxSUMENEP', 'sumenep', NULL, NULL, 'Gelang/Stiker'),
(5, 'ILITSxSEMARANG', 'semarang', NULL, NULL, 'Gelang/Stiker'),
(6, 'ILITSxSULSEL', 'sulawesi selatan', NULL, NULL, 'Gelang/Stiker'),
(7, 'ILITSxSULUT', 'sulawesi utara', NULL, NULL, 'Gelang/Stiker'),
(8, 'ILITSxKALBAR', 'kalimantan barat', NULL, NULL, 'Gelang/Stiker'),
(9, 'ILITSxSULTENG', 'sulawesi tenggara', NULL, NULL, 'Gelang/Stiker'),
(10, 'ILITSxBANTEN', 'banten', NULL, NULL, 'Gelang/Stiker'),
(11, 'ILITSxBALIKPAPAN', 'balikpapan', NULL, NULL, 'Gelang/Stiker'),
(12, 'ILITSxBANDUNG', 'bandung', NULL, NULL, 'Gelang/Stiker'),
(13, 'ILITSxKUDUS', 'kudus', NULL, NULL, 'Gelang/Stiker'),
(14, 'ILITSxPEKALONGAN', 'pekalongan', NULL, NULL, 'Gelang/Stiker'),
(15, 'ILITSxKLATEN', 'klaten', NULL, NULL, 'Gelang/Stiker'),
(16, 'ILITSxPURWOREJO', 'purworejo', NULL, NULL, 'Gelang/Stiker'),
(17, 'ILITSxCIREBON', 'cirebon', NULL, NULL, 'Gelang/Stiker'),
(18, 'ILITSxTASIKMALAYA', 'tasikmalaya', NULL, NULL, 'Gelang/Stiker'),
(19, 'ILITSxSOLO', 'solo', NULL, NULL, 'Gelang/Stiker'),
(20, 'ILITSxLAMPUNG', 'lampung', NULL, NULL, 'Gelang/Stiker'),
(21, 'ILITSxJEMBER', 'jember', NULL, NULL, 'Gelang/Stiker'),
(22, 'ILITSxMADIUN', 'madiun', NULL, NULL, 'Gelang/Stiker'),
(23, 'ILITSxKEDIRI', 'kediri', NULL, NULL, 'Gelang/Stiker'),
(24, 'ILITSxBATU', 'batu', NULL, NULL, 'Gelang/Stiker'),
(25, 'ILITSxGRESIK', 'gresik', NULL, NULL, 'Gelang/Stiker'),
(26, 'ILITSxJOGJA', 'jogja', NULL, NULL, 'Gelang/Stiker'),
(27, 'ILITSxTULUNGAGUNG', 'tulungagung', NULL, NULL, 'Gelang/Stiker'),
(28, 'ILITSxBANYUWANGI', 'banyuwangi', NULL, NULL, 'Gelang/Stiker'),
(29, 'ILITSxBOJONEGORO', 'bojonegoro', NULL, NULL, 'Gelang/Stiker'),
(30, 'ILITSxBEKASI', 'bekasi', NULL, NULL, 'Gelang/Stiker'),
(31, 'ILITSxSUKOHARJO', 'sukoharjo', NULL, NULL, 'Gelang/Stiker'),
(32, 'ILITSxSIDOARJO', 'sidoarjo', NULL, NULL, 'Gelang/Stiker'),
(33, 'ILITSxMAGELANG', 'magelang', NULL, NULL, 'Gelang/Stiker'),
(34, 'ILITSxNGAWI', 'ngawi', NULL, NULL, 'Gelang/Stiker'),
(35, 'ILITSxPAMEKASAN', 'pamekasan', NULL, NULL, 'Gelang/Stiker'),
(36, 'ILITSxPONOROGO', 'ponorogo', NULL, NULL, 'Gelang/Stiker'),
(37, 'ILITSxDEPOK', 'depok', NULL, NULL, 'Gelang/Stiker'),
(38, 'ILITSxSUMBAR', 'sumatera barat', NULL, NULL, 'Gelang/Stiker'),
(39, 'ILITSxPROBOLINGGO', 'probolinggo', NULL, NULL, 'Gelang/Stiker'),
(40, 'ILITSxJAKARTA', 'jakarta', NULL, NULL, 'Gelang/Stiker'),
(41, 'ILITSxSITUBONDO', 'situbondo', NULL, NULL, 'Gelang/Stiker'),
(42, 'ILITSxTANGERANG', 'tangerang', NULL, NULL, 'Gelang/Stiker'),
(43, 'ILITSxSUMBAWA', 'sumbawa', NULL, NULL, 'Gelang/Stiker'),
(44, 'ILITSxBLITAR', 'blitar', NULL, NULL, 'Gelang/Stiker'),
(45, 'ILITSxMOJOKERTO', 'mojokerto', NULL, NULL, 'Gelang/Stiker'),
(46, 'ILITSxPATI', 'pati', NULL, NULL, 'Gelang/Stiker'),
(47, 'ILITSxKARANGANYAR', 'karanganyar', NULL, NULL, 'Gelang/Stiker'),
(48, 'ILITSxJOMBANG', 'jombang', NULL, NULL, 'Gelang/Stiker'),
(49, 'ILITSxSAMPANG', 'sampang', NULL, NULL, 'Gelang/Stiker'),
(50, 'ILITSxTEGAL', 'tegal', NULL, NULL, 'Gelang/Stiker'),
(51, 'ILITSxBANYUMAS', 'banyumas', NULL, NULL, 'Gelang/Stiker'),
(52, 'ILITSxCEPU', 'cepu', NULL, NULL, 'Gelang/Stiker'),
(53, 'ILITSxBENGKULU', 'bengkulu', NULL, NULL, 'Gelang/Stiker'),
(54, 'ILITSxBONTANG', 'bontang', NULL, NULL, 'Gelang/Stiker'),
(55, 'ILITSxRIAU', 'riau', NULL, NULL, 'Gelang/Stiker'),
(56, 'ILITSxBANGKALAN', 'bangkalan', NULL, NULL, 'Gelang/Stiker'),
(57, 'ILITSxPASURUAN', 'pasuruan', NULL, NULL, 'Gelang/Stiker'),
(58, 'ILITSxLOMBOK', 'lombok', NULL, NULL, 'Gelang/Stiker'),
(59, 'ILITSxNGANJUK', 'nganjuk', NULL, NULL, 'Gelang/Stiker'),
(60, 'ILITSxBALI', 'bali', NULL, NULL, 'Gelang/Stiker'),
(61, 'ILITSxLAMONGAN', 'lamongan', NULL, NULL, 'Gelang/Stiker'),
(62, 'ILITSxSALATIGA', 'salatiga', NULL, NULL, 'Gelang/Stiker'),
(64, 'ILITSxRODA', 'Robotika Smanisda (by Dev)', NULL, NULL, 'Stickerbook & Ganci'),
(65, 'LASTMINUTE', '20 feb', 100, 15000, '3 Stiker ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_order`
--
ALTER TABLE `data_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_store`
--
ALTER TABLE `data_store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `merchandise_slider`
--
ALTER TABLE `merchandise_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_bundle`
--
ALTER TABLE `order_bundle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shorten_link`
--
ALTER TABLE `shorten_link`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_bundle`
--
ALTER TABLE `tabel_bundle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_images`
--
ALTER TABLE `tabel_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_product`
--
ALTER TABLE `tabel_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_referral`
--
ALTER TABLE `tabel_referral`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_order`
--
ALTER TABLE `data_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `data_store`
--
ALTER TABLE `data_store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_bundle`
--
ALTER TABLE `order_bundle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT for table `shorten_link`
--
ALTER TABLE `shorten_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=320;

--
-- AUTO_INCREMENT for table `tabel_bundle`
--
ALTER TABLE `tabel_bundle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tabel_images`
--
ALTER TABLE `tabel_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tabel_product`
--
ALTER TABLE `tabel_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tabel_referral`
--
ALTER TABLE `tabel_referral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
