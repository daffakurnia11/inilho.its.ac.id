-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2021 at 12:27 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inilhoit_2021`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_order`
--

CREATE TABLE `data_order` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `province` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal` varchar(10) NOT NULL,
  `courier` varchar(10) NOT NULL,
  `package` varchar(25) NOT NULL,
  `weight` int(12) NOT NULL,
  `shipping` int(12) NOT NULL,
  `subtotal` int(12) NOT NULL,
  `referral` varchar(128) DEFAULT NULL,
  `total` int(12) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_order`
--

INSERT INTO `data_order` (`id`, `no_order`, `receiver`, `phone`, `address`, `province`, `city`, `postal`, `courier`, `package`, `weight`, `shipping`, `subtotal`, `referral`, `total`, `status`) VALUES
(38, '29012021-864', 'Daffa Kurnia Fatah', '085156317473', 'Buduran', 'Jawa Timur', 'Sidoarjo', '61252', 'jne', 'CTCYES', 1400, 20000, 324000, 'ilitsxsidoarjo', 182000, 'Belum Bayar'),
(39, '29012021-197', 'Daffa Kurnia Fatah', '085156317473', 'Buduran', 'Jawa Timur', 'Sidoarjo', '61252', 'jne', 'CTCYES', 1200, 10000, 234000, 'ilitsxsidoarjo', 127000, 'Belum Bayar');

-- --------------------------------------------------------

--
-- Table structure for table `data_store`
--

CREATE TABLE `data_store` (
  `id` int(11) NOT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` int(50) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_store`
--

INSERT INTO `data_store` (`id`, `sender`, `address`, `city`, `phone`) VALUES
(1, 'Daffa Kurnia Fatah', 'Perum. Gading Fajar 1 B6/21 RT/RW 19/05 Desa Siwalan Panji, Buduran, Sidoarjo, Jawa Timur', 444, '085156317473');

-- --------------------------------------------------------

--
-- Table structure for table `order_bundle`
--

CREATE TABLE `order_bundle` (
  `id` int(11) NOT NULL,
  `no_order` varchar(50) NOT NULL,
  `product_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `bundle` varchar(256) NOT NULL,
  `size` varchar(10) DEFAULT NULL,
  `hoodie` varchar(128) DEFAULT NULL,
  `tshirt` varchar(128) DEFAULT NULL,
  `totebag` varchar(128) DEFAULT NULL,
  `cap` varchar(128) DEFAULT NULL,
  `keychain` varchar(128) DEFAULT NULL,
  `bracelet` varchar(128) DEFAULT NULL,
  `lanyard` varchar(128) DEFAULT NULL,
  `stickerbook` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_bundle`
--

INSERT INTO `order_bundle` (`id`, `no_order`, `product_id`, `qty`, `bundle`, `size`, `hoodie`, `tshirt`, `totebag`, `cap`, `keychain`, `bracelet`, `lanyard`, `stickerbook`) VALUES
(3, '29012021-864', 8, 1, 'Bundle Peach Pack', 'L', NULL, NULL, NULL, 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(4, '29012021-197', 8, 1, 'Bundle Peach Pack', 'L', NULL, NULL, NULL, 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `product_id` int(8) NOT NULL,
  `notes` text DEFAULT NULL,
  `product` varchar(256) NOT NULL,
  `qty` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `no_order`, `product_id`, `notes`, `product`, `qty`) VALUES
(72, '29012021-864', 32, 'L', 'Hoodie Arek ITS Cak', 1),
(73, '29012021-864', 34, 'M', 'T-Shirt Vivat 10 Nop', 1),
(74, '29012021-197', 32, 'L', 'Hoodie Arek ITS Cak', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shorten_link`
--

CREATE TABLE `shorten_link` (
  `id` int(11) NOT NULL,
  `namalink` varchar(128) NOT NULL,
  `urllink` varchar(2000) NOT NULL,
  `shortenurl` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shorten_link`
--

INSERT INTO `shorten_link` (`id`, `namalink`, `urllink`, `shortenurl`) VALUES
(5, 'Absensi Gathering 1', 'https://forms.gle/H8YXXuwSPn76Rzgn6', 'Absensigathering1'),
(6, 'Feedback gathering 1', 'https://forms.gle/qewnTbKfjTUfVW9Z9', 'Feedbackgathering1'),
(7, 'Pendaftaran Forda ILITS 2021', 'https://drive.google.com/drive/folders/1FO9KHq2znZixqIVmeR9Z4lIx9GChN_Y-?usp=sharing', 'PendaftaranFordaILITS2021'),
(15, 'Informasi Gathering Forda 2', 'https://drive.google.com/drive/folders/1-T_whGaopcf9R0rrpCsNOCD4OvfSKjR8?usp=sharing', 'InformasiGatheringForda2'),
(10, 'Proposal Keikutsertaan Forda', 'https://docs.google.com/spreadsheets/d/10uQvsefC6sUVooKMRmaXbAnv0aIdEUpd/edit#gid=1615080396', 'ProposalKeikutsertaanForda'),
(22, 'Feedback Dan Evaluasi Gathering Forda 2 Inilhoits! 2021', 'https://forms.gle/SBawQgogU5YQAHFq8', 'FeedbackGathForda2'),
(18, 'Form Pertanyaan Booklet', 'https://docs.google.com/forms/d/e/1FAIpQLScUm20XIGvOsCA9IuI-J4STqpYJMfpN20PVoHjTYQpeDth4SQ/viewform', 'FormPertanyaanBooklet'),
(19, 'Informasi Gathering Forda 1', 'https://drive.google.com/drive/folders/1KkWxf4ZiawtJNYqsubOFlA4PxyXVShNF?usp=sharing', 'InformasiGatheringForda1'),
(20, 'Data Departemen 2021', 'https://docs.google.com/forms/d/e/1FAIpQLSeD2QKEGrb6jBqt0eXtnsxz0onnNiNvmHkBT21haURDOAzE3A/viewform', 'DataDepartemen2021'),
(21, 'Data BEMF 2021', 'https://docs.google.com/forms/d/1jvfc7t6D9a2AAzE7871i0E2VvOf9-pDHAOrNOGY3oX0/edit', 'DataBEMF2021'),
(23, 'Presensi Kehadiran Gathering Forda 2', 'https://forms.gle/Hgqo2xdyT7vbowg57', 'PresensiGathForda2'),
(24, 'Notulensi Gathering Forda 2 Inilhoits! 2021', 'https://docs.google.com/document/d/1uVGcZn3fAxwuR1Lfn_6xTqk_W4x6n2rfZ7z_POID4b4/edit?usp=sharing', 'NotulensiGathForda2'),
(26, 'PPT Gathering Forda II', 'https://drive.google.com/file/d/1Zungr3Y3lglajeZeTIhiOI_nzWIPugSI/view', 'PPTGatheringFordaII'),
(27, 'Pertanyaan Booklet 2', 'https://docs.google.com/document/d/1spsHpyf5Kew4O48zoD6gWb4BZgh0fLrLIpAj5m_8pmw/edit', 'PertanyaanBooklet2'),
(28, 'Presensi Kehadiran Panitia Gathering Forda 2', 'https://forms.gle/FE7hdQM3dhZHnECq8', 'PresensiPanitiaGathForda2'),
(29, 'Form Feedback Pemateri', 'https://docs.google.com/forms/d/e/1FAIpQLSf85XupX_dudlctttJKjQuEFaFRkegLfLzBWXSlCMdbbuVt5A/viewform?usp=sf_link', 'FeedbackPemateriTraining'),
(32, 'Form Pemesanan Merchandise Ilits', 'https://docs.google.com/forms/d/e/1FAIpQLSdV8abfZf6D5MCo29LhiNQ8_BxqmlkEYcH0BEOX_rX1Mz2Urw/viewform', 'FormPemesananMerch'),
(33, 'Informasi Upgrading Forda Day 1', 'https://drive.google.com/drive/folders/15HOM9lBOLI1tW36G5nSafr_cydln_xub?usp=sharing', 'InformasiUpgradingFordaDay1'),
(34, 'Presensi Upgrading Forda Day 1', 'https://forms.gle/ratfDPqGBnWuXsNVA', 'PresensiUpgradingFordaDay1'),
(35, 'Feedback Upgrading Forda Day 1', 'https://forms.gle/yXRVR2F9TcQfrytG6', 'FeedbackUpgradingFordaDay1'),
(36, 'Post Test Pengelolaan kepanitiaan', 'https://docs.google.com/forms/d/e/1FAIpQLScIvsnh-vAAVgZ9RbDntsEMB_jvLrL3yKeymkw-3n6rA5URGQ/viewform?usp=sf_link', 'PostTestMateri1'),
(37, 'Post Test Best Service Level', 'https://forms.gle/UnFe6iqrVk3tKNdV9', 'PostTestMateri2'),
(38, 'Link Berita Acara Visit Forda Bali', 'https://drive.google.com/drive/folders/1kRE9_662YnL7l_aCN752zoJWsbBRPV5o?usp=sharing', 'VisitFordaBali'),
(39, 'Link Berita Acara Visit Forda Balikpapan', 'https://drive.google.com/drive/folders/1QS6SxOLus6R64FTqmCQIdAZi3T8tXuR_?usp=sharing', 'VisitFordaBalikpapan'),
(40, 'Link Berita Acara Visit Forda Bandung', 'https://drive.google.com/drive/folders/11U7WQMjPHcYIXPAG7tKmRKFgvieSUSA7?usp=sharing', 'VisitFordaBandung'),
(41, 'Link Berita Acara Visit Forda Bangkalan', 'https://drive.google.com/drive/folders/1yxh-ilU5xN5llsNunotwHKQ3M2senBdc?usp=sharing', 'VisitFordaBangkalan'),
(42, 'Link Berita Acara Visit Forda Banten', 'https://drive.google.com/drive/folders/1OAN1TaLigDVWTT88CHESkeENMJu4KS9E?usp=sharing', 'VisitFordaBanten'),
(43, 'Link Berita Acara Visit Forda Banyumas', 'https://drive.google.com/drive/folders/12RTypjDBAsClKT4uppbKf6bnlAGZaqlE?usp=sharing', 'VisitFordaBanyumas'),
(44, 'Link Berita Acara Visit Forda Banyuwangi', 'https://drive.google.com/drive/folders/1KnUhzb7tj8ZxPBz8XwSk0koJuZc-bWa_?usp=sharing', 'VisitFordaBanyuwangi'),
(45, 'Link Berita Acara Visit Forda Batu', 'https://drive.google.com/drive/folders/1sGEE0AXYfjXfFxFJuAEu8CqsKAlvnxbw?usp=sharing', 'VisitFordaBatu'),
(46, 'Link Berita Acara Visit Forda Bekasi', 'https://drive.google.com/drive/folders/1c2KnnlqMjis5CXQdL50IpqiwGBLZopVz?usp=sharing', 'VisitFordaBekasi'),
(47, 'Link Berita Acara Visit Forda Bengkulu', 'https://drive.google.com/drive/folders/1BC1Ve5iezjq4u_MAekvbNeF9uI1_uh-m?usp=sharing', 'VisitFordaBengkulu'),
(48, 'Link Berita Acara Visit Forda Blitar', 'https://drive.google.com/drive/folders/1vgmV8XtcFq-UODBA1F1XprExCL4sO6A2?usp=sharing', 'VisitFordaBlitar'),
(49, 'Link Berita Acara Visit Forda Bojonegoro', 'https://drive.google.com/drive/folders/1f06wUlbPZM7kN4Yg6nO08cLQr28kabX6?usp=sharing', 'VisitFordaBojonegoro'),
(50, 'Link Berita Acara Visit Forda Bontang', 'https://drive.google.com/drive/folders/1v9KyiDCDHLJFHNbDdKTpfM3U4eVt5KiG?usp=sharing', 'VisitFordaBontang'),
(51, 'Link Berita Acara Visit Forda Cepu', 'https://drive.google.com/drive/folders/1LaZWMgkkHcUc7242-ie62EoZLBxOgMhr?usp=sharing', 'VisitFordaCepu'),
(52, 'Link Berita Acara Visit Forda Depok', 'https://drive.google.com/drive/folders/1tPK41auxYAlYT776t8YOSZl-gGQ8Ejr7?usp=sharing', 'VisitFordaDepok'),
(53, 'Link Berita Acara Visit Forda DKI JAKARTA', 'https://drive.google.com/drive/folders/1cIaUxurpA7OiaE3YOqY_pR8IYn73ghwD?usp=sharing', 'VisitFordaJakarta'),
(54, 'Link Berita Acara Visit Forda Gresik', 'https://drive.google.com/drive/folders/1o7wxoMwt12iuYxNGBu8a0f7SqzN_cUf-?usp=sharing', 'VisitFordaGresik'),
(55, 'Link Berita Acara Visit Forda Jember', 'https://drive.google.com/drive/folders/1BN0vOGq6Iyx_PQFQ-8QUojhfy2iXhj2H?usp=sharing', 'VisitFordaJember'),
(56, 'Link Berita Acara Visit Forda Jombang', 'https://drive.google.com/drive/folders/1Sk-otvFzlGf_ZXdPCHG2cvOfwvmAwP71?usp=sharing', 'VisitFordaJombang'),
(57, 'Link Berita Acara Visit Forda Kalimantan Barat', 'https://drive.google.com/drive/folders/1a8-AI0uI2zWTR00JRxDGo7l9frUKQSkE?usp=sharing', 'VisitFordaKalbar'),
(58, 'Link Berita Acara Visit Forda Karanganyar', 'https://drive.google.com/drive/folders/1I-_grXG9kedjf6Qv_e-jYBr7CHwo-Tka?usp=sharing', 'VisitFordaKaranganyar'),
(59, 'Link Berita Acara Visit Forda Kediri', 'https://drive.google.com/drive/folders/1bmXZM9XMsoBXn0Qksy_LVLTFU9j15-M0?usp=sharing', 'VisitFordaKediri'),
(60, 'Link Berita Acara Visit Forda Klaten', 'https://drive.google.com/drive/folders/1REWvJaWqneHzmZDOQ-9KG4sUOk7-_0we?usp=sharing', 'VisitFordaKlaten'),
(61, 'Link Berita Acara Visit Forda Pekalongan', 'https://drive.google.com/drive/folders/11FlAU2F4E7-pjkf3XW-fPL-7k7tR8-uI?usp=sharing', 'VisitFordaPekalongan'),
(62, 'Link Berita Acara Visit Forda Kudus', 'https://drive.google.com/drive/folders/1CU-o5ZKhRXzES3o9GQT6kvAqHXtXIx9f?usp=sharing', 'VisitFordaKudus'),
(63, 'Link Berita Acara Visit Forda Lamongan', 'https://drive.google.com/drive/folders/1c3JaAyY0JuhntC6tRDxpTAl-RENccZ1B?usp=sharing', 'VisitFordaLamongan'),
(64, 'Link Berita Acara Visit Forda Lampung', 'https://drive.google.com/drive/folders/1Ha69RJjvPoE_NZqZtjFrHGbA4-5W94KG?usp=sharing', 'VisitFordaLampung'),
(65, 'Link Berita Acara Visit Forda Lombok', 'https://drive.google.com/drive/folders/1fTp1VYMRvvS3C27iT6jgt1maOxD-d6Kz?usp=sharing', 'VisitFordaLombok'),
(66, 'Link Berita Acara Visit Forda Madiun', 'https://drive.google.com/drive/folders/1XA2F060rb5R1w0PHEXgtNZi4-ha7df4M?usp=sharing', 'VisitFordaMadiun'),
(67, 'Link Berita Acara Visit Forda Magelang', 'https://drive.google.com/drive/folders/1PhufjedbxfVIHnGV9qBOkN9t9cZvHhMM?usp=sharing', 'VisitFordaMagelang'),
(68, 'Link Berita Acara Visit Forda Manado', 'https://drive.google.com/drive/folders/13O-i__LZjdr2eX59533tKftpiqd4HzkP?usp=sharing', 'VisitFordaManado'),
(69, 'Link Berita Acara Visit Forda Mojokerto', 'https://drive.google.com/drive/folders/1GpTiO8eEQbxnecpmm6Mae2GOspCW-o0C?usp=sharing', 'VisitFordaMojokerto'),
(70, 'Link Berita Acara Visit Forda Nganjuk', 'https://drive.google.com/drive/folders/19figgbL4Hs4kzWMBTtuGOSgIEnWP-jmt?usp=sharing', 'VisitFordaNganjuk'),
(71, 'Link Berita Acara Visit Forda Ngaw', 'https://drive.google.com/drive/folders/1EqKAVG7wPb6M4T_FTg3nHL5O_I1tv_2x?usp=sharing', 'VisitFordaNgawi'),
(72, 'Link Berita Acara Visit Forda Pamekasan', 'https://drive.google.com/drive/folders/1m7WuggisycE6Q_a0Q94iaeppZhvxTLau?usp=sharing', 'VisitFordaPamekasan'),
(73, 'Link Berita Acara Visit Forda Pasuruan', 'https://drive.google.com/drive/folders/1hN3d7KXqPpYRCOM9088LtUI1CpsKK3L9?usp=sharing', 'VisitFordaPasuruan'),
(74, 'Link Berita Acara Visit Forda Pati', 'https://drive.google.com/drive/folders/1YlPDMthzMfIB7XHIO-LxVEEyZv0vvNoa?usp=sharing', 'VisitFordaPati'),
(75, 'Link Berita Acara Visit Forda Ponorogo', 'https://drive.google.com/drive/folders/1bQnfTH5yOGfPLKzCUJQykYzhJdjdu2aR?usp=sharing', 'VisitFordaPonorogo'),
(76, 'Link Berita Acara Visit Forda Probolinggo', 'https://drive.google.com/drive/folders/1c6AtnboaLsTdVtvdsR0f33oldB_HhAUD?usp=sharing', 'VisitFordaProbolinggo'),
(77, 'Link Berita Acara Visit Forda Purworejo', 'https://drive.google.com/drive/folders/1wW6Lxs0QYzlymvpx2sJvzR-uYJ4v5b_Z?usp=sharing', 'VisitFordaPurworejo'),
(78, 'Link Berita Acara Visit Forda Riau', 'https://drive.google.com/drive/folders/1xbPErpM30O5stQ5n_GBQSm-6rvgYX-zt?usp=sharing', 'VisitFordaRiau'),
(79, 'Link Berita Acara Visit Forda Salatiga', 'https://drive.google.com/drive/folders/1_6v3Ul99RULl3f4EmFCMC4ftLRLBleTS?usp=sharing', 'VisitFordaSalatiga'),
(80, 'Link Berita Acara Visit Forda Samarinda', 'https://drive.google.com/drive/folders/1AoxZMms39HjSfHqiN7bTVXd1VLyql69C?usp=sharing', 'VisitFordaSamarinda'),
(81, 'Link Berita Acara Visit Forda Sampang', 'https://drive.google.com/drive/folders/1bVnXcvTzoaw2qv09DWUWGb1ZdOqU5CuO?usp=sharing', 'VisitFordaSampang'),
(82, 'Link Berita Acara Visit Forda Semarang', 'https://drive.google.com/drive/folders/1-ap0dGwJOMjziG_jB4hQnQSx3sfcwKsP?usp=sharing', 'VisitFordaSemarang'),
(83, 'Link Berita Acara Visit Forda Sidoarjo', 'https://drive.google.com/drive/folders/15wmLDMlkXcCiEl0Yg7gVkF81LpF7Jd9-?usp=sharing', 'VisitFordaSidoarjo'),
(84, 'Link Berita Acara Visit Forda Situbondo', 'https://drive.google.com/drive/folders/1wVI4e_YQdfGp8Qhng6YWhdCbed8-zRTR?usp=sharing', 'VisitFordaSitubondo'),
(85, 'Link Berita Acara Visit Forda Solo', 'https://drive.google.com/drive/folders/1lQQHQP-r8pzec059ftME_cr3MUdA4E_6?usp=sharing', 'VisitFordaSolo'),
(86, 'Link Berita Acara Visit Forda Sukoharjo', 'https://drive.google.com/drive/folders/1gOe8YxwaxB-BjLm_ZB6bieKrD1HwKb9Q?usp=sharing', 'VisitFordaSukoharjo'),
(87, 'Link Berita Acara Visit Forda Sulawesi Selatan', 'https://drive.google.com/drive/folders/1-5Nbz369JWm-XX_QqyPZxkSI4sorLNbJ?usp=sharing', 'VisitFordaSulsel'),
(88, 'Link Berita Acara Visit Forda Sulawesi Tenggara', 'https://drive.google.com/drive/folders/1IW9JiEhiFshidFqC08tWgCBiWejPxvOu?usp=sharing', 'VisitFordaSulawesiTenggara'),
(89, 'Link Berita Acara Visit Forda Sumatera Barat', 'https://drive.google.com/drive/folders/13LR5hmY_vDM2-x8YJS28HxFIieU6udj3?usp=sharing', 'VisitFordaSumateraBarat'),
(90, 'Link Berita Acara Visit Forda Sumbawa Besar', 'https://drive.google.com/drive/folders/1oMjk6-inMdlVIySZ-pehvu1JJA-AtyG-?usp=sharing', 'VisitFordaSumbawaBesar'),
(91, 'Link Berita Acara Visit Forda Sumenep', 'https://drive.google.com/drive/folders/1EGgjxdJFqAMkOcLknjlC8h0VFV7ATZ4Y?usp=sharing', 'VisitFordaSumenep'),
(92, 'Link Berita Acara Visit Forda Tangerang', 'https://drive.google.com/drive/folders/10QA8qj-zFJUWFtYeVKf1SUJ9kZikCwFt?usp=sharing', 'VisitFordaTangerang'),
(93, 'Link Berita Acara Visit Forda Tasikmalaya', 'https://drive.google.com/drive/folders/1cf7MlONcKyRt15_iZQXK34u8JvhE5y1R?usp=sharing', 'VisitFordaTasikmalaya'),
(94, 'Link Berita Acara Visit Forda Tegal', 'https://drive.google.com/drive/folders/1wEbFWa579qnvHjngIEqXhaDIaUF3NeSu?usp=sharing', 'VisitFordaTegal'),
(95, 'Link Berita Acara Visit FordaTuban', 'https://drive.google.com/drive/folders/1uEOogJLuDUlo0279va9sHnMPFGMuKBfU?usp=sharing', 'VisitFordaTuban'),
(96, 'Link Berita Acara Visit Forda Tulungagung', 'https://drive.google.com/drive/folders/1sLikY1uxpXx3baLqRi2EVPH54yCnrdDB?usp=sharing', 'VisitFordaTulungagung'),
(97, 'Link Berita Acara Visit Forda Yogyakarta', 'https://drive.google.com/drive/folders/1yU-0liWAXxkoYEzuRhUqGmOFK9lSa6dq?usp=sharing', 'VisitFordaYogyakarta'),
(98, 'Link Berita Acara Visit Forda Sulawesi Selatan 1', 'https://drive.google.com/drive/folders/1-5Nbz369JWm-XX_QqyPZxkSI4sorLNbJ?usp=sharing', 'VisitFordaSulawesiSelatan'),
(99, 'Link Berita Acara Visit Forda Kalimantan Barat 1', 'https://drive.google.com/drive/folders/1a8-AI0uI2zWTR00JRxDGo7l9frUKQSkE?usp=sharing', 'VisitFordaKalimantanBarat'),
(100, 'Informasi Upgrading Forda Day 2', 'https://drive.google.com/drive/folders/1WeCbr20ZiCTAHO1ibb4t1hB94sU32ZSW?usp=sharing', 'InformasiUpgradingFordaDay2'),
(101, 'Post Test Public Speaking', 'https://docs.google.com/forms/d/e/1FAIpQLSf3dv5EtK48HjMfBl9iD8XRshK6ky7xE9cL_fyL-yhgxLIQjw/viewform', 'PostTestMateri5'),
(102, 'Presensi Upgrading Forda Day 2', 'https://forms.gle/QnPRmXwiHNL1pJVn9', 'PresensiUpgradingFordaDay2'),
(103, 'Feedback Upgrading Forda Day 2', 'https://forms.gle/pCbFr2Tyz4C5T6mBA', 'FeedbackUpgradingFordaDay2'),
(104, 'Post Test Mengonsep Acara', 'https://docs.google.com/forms/d/e/1FAIpQLSc4El45E4BCedeg8agGkTPDk8uQASlPlKYUvhU2CCyjq98efA/viewform?usp=sf_link', 'PostTestMateri3'),
(105, 'Post Test Strategi dan Teknik Marketing', 'https://docs.google.com/forms/d/e/1FAIpQLScsDPuamlRGgMtrWy3c6lEOkAyL0_7NlxmT0c0-U0QXue49Hg/viewform?usp=sf_link', 'PostTestMateri4'),
(106, 'Contoh Presensi Visit Forda', 'https://forms.gle/u5onyAXNH9ojpzVV9', 'ContohPresensiVisitForda'),
(107, 'Background Google Form ILITS', 'https://drive.google.com/file/d/17QGTNi0zePBvZHiI5Hcc6Mya3UsMfryH/view?usp=sharing', 'BackgroundFormILITS'),
(108, 'Contoh Feedback Visit Forda', 'https://forms.gle/dZJHEMwd7HTYtYTD6', 'ContohFeedbackVisitForda'),
(109, 'Informasi Gathering Humas 2', 'https://drive.google.com/drive/folders/107fJZxmQ1OB0P3EJ7LTvXdOsY4CrqcWe?usp=sharing', 'InformasiGatheringHumas2'),
(110, 'Link Berita Acara Visit Forda Cirebon', 'https://drive.google.com/drive/folders/1C_l2k4dSUHpTVsatB6dHoNTThWf1I9Lz?usp=sharing', 'VisitCirebon'),
(111, 'Link Berita Acara Visit Forda Cirebon 1', 'https://drive.google.com/drive/folders/1C_l2k4dSUHpTVsatB6dHoNTThWf1I9Lz?usp=sharing', 'VisitFordaCirebon'),
(113, 'Feedback Upgrading Forda Day 3', 'https://docs.google.com/forms/d/17k5XenTiDrRknQWUo35bIh3LgfqqUKeY7nS62KXH9Nk/viewform', 'FeedbackUpgradingFordaDay3'),
(114, 'Presensi Upgrading Forda Day 3', 'https://forms.gle/Puknr9anQY1E44mLA', 'PresensiUpgradingFordaDay3'),
(115, 'TalkshowILITS2021', 'http://inilho.its.ac.id/comingsoon/', 'TalkshowILITS2021'),
(116, 'Post Test Presentasi yang menarik dan persuasif', 'https://docs.google.com/forms/d/e/1FAIpQLSfbZCSv4g0dEsqSIo-Bpj1izfsMRjiCsGdsL-aGQy_DGRkwDw/viewform?usp=sf_link', 'PostTestMateri6'),
(117, 'Informasi Upgrading Forda Day 3', 'https://drive.google.com/drive/folders/1gHf4llqCaq3miH65_t27ZtWLJ36z4bVp?usp=sharing', 'InformasiUpgradingFordaDay3'),
(118, 'Feedback Gathering 2 HMD', 'https://forms.gle/8txwuTvsSHMeS6x88', 'FeedbackGath2HMD'),
(119, 'Presensi Gathering 2 HMD', 'https://forms.gle/oxPh3n2ZEdU5UFgb7', 'PresensiGath2HMD'),
(120, 'Notulensi Gathering 2 HMD', 'https://docs.google.com/document/d/1TqCQ8ieU4rfhYU1G4VCL-m_VONDQhwWJbPjxzsTgg-w/edit', 'NotulensiGath2HMD'),
(121, 'Record Training Forda Day 123', 'https://drive.google.com/drive/folders/1iIns9knyvVLoAv3WZU3PzjR7g9bXlOnn?usp=sharing', 'RecordTrainingFordaDay123'),
(122, 'Informasi Gathering Forda 3', 'https://drive.google.com/drive/folders/1A0HVLqYKWMPGlZ2pmuWHGy6Q3wAO-9Gp?usp=sharing', 'InformasiGatheringForda3');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_bundle`
--

CREATE TABLE `tabel_bundle` (
  `id` int(11) NOT NULL,
  `product` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `hoodie` int(11) DEFAULT NULL,
  `shirt` int(11) DEFAULT NULL,
  `totebag` int(11) DEFAULT NULL,
  `cap` int(11) DEFAULT NULL,
  `keychain` int(11) DEFAULT NULL,
  `bracelet` int(11) DEFAULT NULL,
  `lanyard` int(11) DEFAULT NULL,
  `stickerbook` int(11) DEFAULT NULL,
  `data-target` varchar(128) NOT NULL,
  `weight` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_bundle`
--

INSERT INTO `tabel_bundle` (`id`, `product`, `price`, `hoodie`, `shirt`, `totebag`, `cap`, `keychain`, `bracelet`, `lanyard`, `stickerbook`, `data-target`, `weight`) VALUES
(1, 'Red Pack', '229000', NULL, 1, 1, 1, 1, 1, 1, 1, 'red-pack', 1000),
(2, 'Orange Pack', '199000', NULL, 1, 1, NULL, 1, 1, 1, 1, 'orange-pack', 1000),
(3, 'Yellow Pack', '149000', NULL, NULL, 1, 1, 1, 1, NULL, 1, 'yellow-pack', 1000),
(4, 'Green Pack', '149000', NULL, 1, NULL, NULL, 1, 1, 1, 1, 'green-pack', 1000),
(5, 'Blue Pack', '285000', 1, NULL, 1, 1, 1, 1, 1, 1, 'blue-pack', 1000),
(6, 'Purple Pack', '249000', 1, NULL, 1, NULL, 1, 1, 1, 1, 'purple-pack', 1000),
(7, 'Lylac Pack', '185000', 1, NULL, NULL, NULL, 1, 1, 1, 1, 'lylac-pack', 1000),
(8, 'Peach Pack', '94000', NULL, NULL, NULL, 1, 1, 1, 1, 1, 'peach-pack', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_images`
--

CREATE TABLE `tabel_images` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `image` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_images`
--

INSERT INTO `tabel_images` (`id`, `code`, `image`) VALUES
(1, 'HD-01', 'hd01-front.png'),
(2, 'HD-01', 'hd01-back.png'),
(4, 'HD-02', 'hd02-front.png'),
(5, 'HD-02', 'hd02-back.png'),
(6, 'TS-01', 'ts01-front.png'),
(7, 'TS-01', 'ts01-back.png'),
(8, 'TS-02', 'ts02-front.png'),
(9, 'TS-02', 'ts02-back.png'),
(10, 'TS-TDYE-01', 'ts-tdye-01.png'),
(11, 'TS-TDYE-02', 'ts-tdye-02.png'),
(12, 'TS-TDYE-03', 'ts-tdye-03.png'),
(13, 'TB-01', 'tb01.png'),
(14, 'TB-02', 'tb02.png'),
(15, 'TB-TDYE-01', 'tb-tdye-01.png'),
(16, 'KC-01', 'kc01.png'),
(17, 'KC-02', 'kc02.png'),
(18, 'KC-03', 'kc03.png'),
(19, 'RB-01', 'rb01.jpg'),
(20, 'RB-02', 'rb02.jpg'),
(21, 'LY-01', 'ly01.jpg'),
(22, 'SB-01', 'stickerpack.png'),
(23, 'DC-01', 'dc01.jpg'),
(24, 'DC-02', 'dc02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_product`
--

CREATE TABLE `tabel_product` (
  `id` int(11) NOT NULL,
  `product` varchar(128) NOT NULL,
  `price` varchar(128) NOT NULL,
  `category` varchar(128) NOT NULL,
  `code` varchar(50) NOT NULL,
  `catalog` varchar(128) NOT NULL,
  `weight` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_product`
--

INSERT INTO `tabel_product` (`id`, `product`, `price`, `category`, `code`, `catalog`, `weight`) VALUES
(31, 'Kampoes Perdjoeangan', '140000', 'Hoodie', 'HD-01', 'hd01-front.png', 200),
(32, 'Arek ITS Cak', '140000', 'Hoodie', 'HD-02', 'hd02-front.png', 200),
(33, 'Arek ITS Cak', '90000', 'T-Shirt', 'TS-01', 'ts01-front.png', 200),
(34, 'Vivat 10 Nop', '90000', 'T-Shirt', 'TS-02', 'ts02-front.png', 200),
(35, 'Future Engineer Black', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-01', 'ts-tdye-01.png', 200),
(36, 'Future Engineer Purple', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-02', 'ts-tdye-02.png', 200),
(37, 'Future Engineer Blue', '90000', 'Tie Dye T-Shirt', 'TS-TDYE-03', 'ts-tdye-03.png', 200),
(38, 'Stay Up Late', '55000', 'Totebag', 'TB-01', 'tb01.png', 200),
(39, 'Snooze or Sleep', '55000', 'Totebag', 'TB-02', 'tb02.png', 200),
(40, 'Tie Dye World Class Engineer', '55000', 'Totebag', 'TB-TDYE-01', 'tb-tdye-01.png', 200),
(41, '1957 ITS Robot', '15000', 'Keychain', 'KC-01', 'kc01.png', 200),
(42, 'Attention Please', '15000', 'Keychain', 'KC-02', 'kc02.png', 200),
(43, 'Your Future Engineer', '15000', 'Keychain', 'KC-03', 'kc03.png', 200),
(44, '10 Nopember', '15000', 'Gelang', 'RB-01', 'rb01.jpg', 200),
(45, 'World Class Engineer', '15000', 'Gelang', 'RB-02', 'rb02.jpg', 200),
(46, 'World Class Engineer', '15000', 'Lanyard', 'LY-01', 'ly01.jpg', 200),
(47, '8 in 1 Collection', '20000', 'Stiker', 'SB-01', 'stickerpack.png', 200),
(48, 'OG 10 Nop', '40000', 'Dad Cap', 'DC-01', 'dc01.jpg', 200),
(49, 'OG Logo White', '40000', 'Dad Cap', 'DC-02', 'dc02.jpg', 200);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_referral`
--

CREATE TABLE `tabel_referral` (
  `id` int(11) NOT NULL,
  `code` varchar(128) DEFAULT NULL,
  `forda` varchar(128) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_referral`
--

INSERT INTO `tabel_referral` (`id`, `code`, `forda`, `discount`) VALUES
(1, 'ILITSxSIDOARJO', 'Sidoarjo', 50),
(3, 'ILITSxGRESIK', 'Gresik', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_order`
--
ALTER TABLE `data_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_store`
--
ALTER TABLE `data_store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_bundle`
--
ALTER TABLE `order_bundle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shorten_link`
--
ALTER TABLE `shorten_link`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_bundle`
--
ALTER TABLE `tabel_bundle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_images`
--
ALTER TABLE `tabel_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_product`
--
ALTER TABLE `tabel_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_referral`
--
ALTER TABLE `tabel_referral`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_order`
--
ALTER TABLE `data_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `data_store`
--
ALTER TABLE `data_store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_bundle`
--
ALTER TABLE `order_bundle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `shorten_link`
--
ALTER TABLE `shorten_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `tabel_bundle`
--
ALTER TABLE `tabel_bundle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tabel_images`
--
ALTER TABLE `tabel_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tabel_product`
--
ALTER TABLE `tabel_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tabel_referral`
--
ALTER TABLE `tabel_referral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
