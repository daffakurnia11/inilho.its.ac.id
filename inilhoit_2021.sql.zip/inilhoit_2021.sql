-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 07, 2021 at 01:30 PM
-- Server version: 5.6.50
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inilhoit_2021`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_order`
--

CREATE TABLE `data_order` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `province` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal` varchar(10) NOT NULL,
  `courier` varchar(10) NOT NULL,
  `package` varchar(25) NOT NULL,
  `weight` int(12) NOT NULL,
  `shipping` int(12) NOT NULL,
  `subtotal` int(12) NOT NULL,
  `referral` varchar(128) DEFAULT NULL,
  `bonus` varchar(128) DEFAULT NULL,
  `total` int(12) NOT NULL,
  `status` varchar(50) NOT NULL,
  `transfer` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_order`
--

INSERT INTO `data_order` (`id`, `no_order`, `receiver`, `phone`, `address`, `province`, `city`, `postal`, `courier`, `package`, `weight`, `shipping`, `subtotal`, `referral`, `bonus`, `total`, `status`, `transfer`) VALUES
(1, '05022021-607', 'Alia Dewi Kartika', '62081231071334', 'Jalan Raya Bringkang no 127, Menganti, Gresik, Jawa Timur 61174 (depan perumahan taman Menganti emas/ UD Sumber rejeki)', 'Jawa Timur', 'Gresik', '61174', 'jne', 'REG', 2200, 16000, 458000, NULL, NULL, 474000, 'Sudah Bayar', 'IMG20210205152439.jpg'),
(2, '05022021-941', 'Abdul Aziz Ardiansyah', '6281298941671', 'Jln. Gunung Halimun Blok H-115 Komplek Mabad Rempoa Kota Tangerang Selatan- Ciputat Timur', 'Banten', 'Tangerang Selatan', '15412', 'jne', 'REG', 600, 18000, 94000, NULL, NULL, 112000, 'Belum Bayar', 'A73B50FA-8B5A-4E02-90A4-87D21690A3D2.png'),
(3, '05022021-054', 'Alifia rahma', '6288809374547', 'Jl.panca 7 rt14/001 kelurahan serdang kecamatan kemayoran jakarta pusat nomor 10D', 'DKI Jakarta', 'Jakarta Pusat', '10650', 'jne', 'REG', 350, 15000, 105000, NULL, NULL, 120000, 'Belum Bayar', NULL),
(4, '05022021-372', 'Cinta Rinandyta', '6289687317881', 'Jalan Plemahan XI No. 35 D, RT 006, RW 009, Kelurahan Kedungdoro, Kecamatan Tegalsari, Kota Surabaya, Provinsi Jawa Timur, Kode Pos 60261', 'Jawa Timur', 'Surabaya', '60261', 'jne', 'CTCYES', 100, 10000, 15000, NULL, NULL, 25000, 'Belum Bayar', 'Bukti_Pembayaran_Merch_ILITS.jpg'),
(5, '05022021-591', 'Osha Aguisti', '6281294429206', 'Perumahan pondok kopi blok R 10/8 RT 003 RW 007 Duren sawit', 'DKI Jakarta', 'Jakarta Timur', '13460', 'jne', 'OKE', 250, 12000, 90000, NULL, NULL, 102000, 'Sudah Bayar', 'MBRC_16125275810221.png'),
(6, '05022021-237', 'Ardito Ghulam Nugraha', '62085971713118', 'Jalan Pusri No. 33 RT05/RW10 Balun Kandangdoro, Kec.Cepu', 'Jawa Tengah', 'Blora', '58311', 'jne', 'REG', 500, 23000, 140000, NULL, NULL, 163000, 'Sudah Bayar', 'IMG-20210205-WA00241.jpg'),
(7, '05022021-419', 'Aina Jabrail Zahrawani', '6281703874676', 'Western village blok b5 no 8, Kel.Sememi, Kec.Benowo', 'Jawa Timur', 'Surabaya', '60198', 'jne', 'CTC', 600, 7000, 94000, NULL, NULL, 101000, 'Belum Bayar', 'downloadMandiri16125286159331.jpg'),
(8, '05022021-851', 'Sarah Hanifah', '6282170989311', 'Jalan Pemuda, Komplek Sari Residence Blok B7 no. 10, Kel. Tirtasiak, Kec. Payung Sekaki', 'Riau', 'Pekanbaru', '28292', 'jne', 'OKE', 900, 46000, 180000, NULL, NULL, 226000, 'Belum Bayar', NULL),
(9, '05022021-603', 'Edgarrafi', '6282229621877', 'Puri Sewon Asri Blok D20, Panggungharjo, Sewon, Bantul Regency, Jogja, 55188', 'DI Yogyakarta', 'Bantul', '55188', 'jne', 'REG', 300, 15000, 75000, 'ILITSxJOGJA', 'Gelang/Stiker', 90000, 'Sudah Bayar', 'Screenshot_20210205-214203_OVO.jpg'),
(10, '05022021-204', 'Ardhea Yavanitta Putri', '62081342403010', 'Jl.MH.Thamrin gg. Ngalimun no.34', 'Jawa Timur', 'Bojonegoro', '62112', 'tiki', 'REG', 300, 10000, 55000, NULL, NULL, 65000, 'Belum Bayar', NULL),
(11, '06022021-812', 'Sarah Pontoh', '6282170989311', 'Jalan Pemuda, Komplek Sari Residence Blok B7 no. 10, Kel. Tirtasiak, Kec. Payung Sekaki', 'Riau', 'Pekanbaru', '28292', 'jne', 'OKE', 900, 46000, 180000, NULL, NULL, 226000, 'Belum Bayar', 'tf_06022021-812.jpg'),
(12, '06022021-806', 'Aditya Bayhaqi', '6287788907377', 'Apartemen Kalibata City Tower Damar Unit D05CS', 'DKI Jakarta', 'Jakarta Selatan', '12750', 'jne', 'OKE', 200, 12000, 40000, NULL, NULL, 52000, 'Sudah Bayar', 'bukti_trf_inilhoits.jpg'),
(13, '06022021-018', 'Vian Setya', '6285649281940', 'Dsn. Kembang sore RT 2 RW 2 Ds. Terung Kulon Kec. Krian Kab. Sidoarjo', 'Jawa Timur', 'Sidoarjo', '61262', 'jne', 'CTC', 750, 7000, 230000, NULL, NULL, 237000, 'Belum Bayar', NULL),
(14, '06022021-358', 'Nathanael Yoan Putra Lazarus', '6282112723565', 'Viscany Residence Blok E19, Jalan Raya Boulevard Grand Depok City, Kalimulya, Cilodong, Depok', 'Jawa Barat', 'Depok', '16413', 'jne', 'OKE', 250, 15000, 90000, NULL, NULL, 105000, 'Belum Bayar', '34212CAF-338E-4EC0-8F50-4FF61DA09325.png'),
(15, '07022021-701', 'Tegar Isnain Muharram', '62082334823132', 'Jalan Raya Nyalaran nomor 207 Pamekasan', 'Jawa Timur', 'Pamekasan', '69314', 'jne', 'REG', 850, 8000, 199000, NULL, NULL, 207000, 'Belum Bayar', 'MBRC_1612650150427.png'),
(17, '07022021-961', 'Krisna Hadi Prasetya', '6288803746574', 'Jl. Kyai Matlab, RT/RW 01/05, Tempeh Lor, Kec. Tempeh, Kab. Lumajang, Jawa Timur.', 'Jawa Timur', 'Lumajang', '67371', 'jne', 'REG', 350, 8000, 105000, NULL, NULL, 113000, 'Belum Bayar', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_store`
--

CREATE TABLE `data_store` (
  `id` int(11) NOT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(128) DEFAULT NULL,
  `city_id` int(50) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_store`
--

INSERT INTO `data_store` (`id`, `sender`, `address`, `city`, `city_id`, `phone`) VALUES
(1, 'Nabbil Gibran', 'Jl. ngagel tirto no.3\r\nkec. wonokromo/kel. ngagel rejo\r\n60245, surabaya', 'Surabaya', 444, '082234666582');

-- --------------------------------------------------------

--
-- Table structure for table `order_bundle`
--

CREATE TABLE `order_bundle` (
  `id` int(11) NOT NULL,
  `no_order` varchar(50) NOT NULL,
  `product_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `bundle` varchar(256) NOT NULL,
  `size` varchar(10) DEFAULT NULL,
  `hoodie` varchar(128) DEFAULT NULL,
  `tshirt` varchar(128) DEFAULT NULL,
  `totebag` varchar(128) DEFAULT NULL,
  `cap` varchar(128) DEFAULT NULL,
  `keychain` varchar(128) DEFAULT NULL,
  `bracelet` varchar(128) DEFAULT NULL,
  `lanyard` varchar(128) DEFAULT NULL,
  `stickerbook` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_bundle`
--

INSERT INTO `order_bundle` (`id`, `no_order`, `product_id`, `qty`, `bundle`, `size`, `hoodie`, `tshirt`, `totebag`, `cap`, `keychain`, `bracelet`, `lanyard`, `stickerbook`) VALUES
(1, '05022021-607', 1, 1, 'Bundle Red Pack', 'M', NULL, 'T-Shirt Vivat 10 Nop', 'Totebag Tie Dye World Class Engineer', 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(2, '05022021-607', 1, 1, 'Bundle Red Pack', 'M', NULL, 'T-Shirt Vivat 10 Nop', 'Totebag Tie Dye World Class Engineer', 'Dad Cap OG Logo White', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(3, '05022021-941', 8, 1, 'Bundle Peach Pack', NULL, NULL, NULL, NULL, 'Dad Cap OG 10 Nop', 'Keychain 1957 ITS Robot', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(4, '05022021-419', 8, 1, 'Bundle Peach Pack', NULL, NULL, NULL, NULL, 'Dad Cap OG 10 Nop', 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection'),
(5, '07022021-701', 2, 1, 'Bundle Orange Pack', 'M', NULL, 'Tie Dye T-Shirt Future Engineer Black', 'Totebag Tie Dye World Class Engineer', NULL, 'Keychain Your Future Engineer', 'Gelang World Class Engineer', 'Lanyard World Class Engineer', 'Stiker 8 in 1 Collection');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `no_order` varchar(25) NOT NULL,
  `product_id` int(8) NOT NULL,
  `notes` text,
  `product` varchar(256) NOT NULL,
  `qty` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `no_order`, `product_id`, `notes`, `product`, `qty`) VALUES
(1, '05022021-054', 34, 'S', 'T-Shirt Vivat 10 Nop', 1),
(2, '05022021-054', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(3, '05022021-372', 45, NULL, 'Gelang World Class Engineer', 1),
(4, '05022021-591', 35, 'M', 'Tie Dye T-Shirt Future Engineer Black', 1),
(5, '05022021-237', 31, 'XL', 'Hoodie Kampoes Perdjoeangan', 1),
(6, '05022021-851', 40, NULL, 'Totebag Tie Dye World Class Engineer', 1),
(7, '05022021-851', 41, NULL, 'Keychain 1957 ITS Robot', 1),
(8, '05022021-851', 46, NULL, 'Lanyard World Class Engineer', 1),
(9, '05022021-851', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(10, '05022021-851', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(11, '05022021-851', 43, NULL, 'Keychain Your Future Engineer', 2),
(12, '05022021-603', 45, NULL, 'Gelang World Class Engineer', 1),
(13, '05022021-603', 39, NULL, 'Totebag Snooze or Sleep', 1),
(14, '05022021-204', 49, NULL, 'Dad Cap OG Logo White', 1),
(15, '05022021-204', 42, NULL, 'Keychain Attention Please', 1),
(16, '06022021-812', 40, NULL, 'Totebag Tie Dye World Class Engineer', 1),
(17, '06022021-812', 41, NULL, 'Keychain 1957 ITS Robot', 2),
(18, '06022021-812', 43, NULL, 'Keychain Your Future Engineer', 1),
(19, '06022021-812', 46, NULL, 'Lanyard World Class Engineer', 1),
(20, '06022021-812', 47, NULL, 'Stiker 8 in 1 Collection', 1),
(21, '06022021-812', 48, NULL, 'Dad Cap OG 10 Nop', 1),
(22, '06022021-806', 49, NULL, 'Dad Cap OG Logo White', 1),
(23, '06022021-018', 32, 'M', 'Hoodie Arek ITS Cak', 1),
(24, '06022021-018', 34, 'L', 'T-Shirt Vivat 10 Nop', 1),
(25, '06022021-358', 37, 'M', 'Tie Dye T-Shirt Future Engineer Blue', 1),
(26, '07022021-961', 34, 'L', 'T-Shirt Vivat 10 Nop', 1),
(27, '07022021-961', 43, NULL, 'Keychain Your Future Engineer', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_order`
--
ALTER TABLE `data_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_store`
--
ALTER TABLE `data_store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_bundle`
--
ALTER TABLE `order_bundle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_order`
--
ALTER TABLE `data_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `data_store`
--
ALTER TABLE `data_store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_bundle`
--
ALTER TABLE `order_bundle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
