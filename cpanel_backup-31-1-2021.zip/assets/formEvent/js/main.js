(function ($) {
  "use strict";


    /*==================================================================
    [ Focus input ]*/
    $('.input100').each(function(){
      $(this).on('blur', function(){
        if($(this).val().trim() != "") {
          $(this).addClass('has-val');
        }
        else {
          $(this).removeClass('has-val');
        }
      })    
    })


    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

    $('.validate-form').on('submit',function(){
      var check = true;

      for(var i=0; i<input.length; i++) {
        if(validate(input[i]) == false){
          showValidate(input[i]);
          check=false;
        }
      }

      return check;
    });


    $('.validate-form .input100').each(function(){
      $(this).focus(function(){
       hideValidate(this);
     });
    });

    

    function validate (input) {
      if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
        if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
          return false;
        }
      } else if($(input).attr('type') == 'text' && $(input).attr('name') == 'no_hp') {
        if($(input).val().length < 10 || $(input).val().length > 15) {
          return false;
        }
      }
      else {
        if($(input).val().trim() == ''){
          return false;
        }
      }
    }

    function showValidate(input) {
      var thisAlert = $(input).parent();

      $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
      var thisAlert = $(input).parent();

      $(thisAlert).removeClass('alert-validate');
    }
    
    /*==================================================================
    [ Show pass ]*/
    var showPass = 0;
    $('.btn-show-pass').on('click', function(){
      if(showPass == 0) {
        $(this).next('input').attr('type','text');
        $(this).find('i').removeClass('zmdi-eye');
        $(this).find('i').addClass('zmdi-eye-off');
        showPass = 1;
      }
      else {
        $(this).next('input').attr('type','password');
        $(this).find('i').addClass('zmdi-eye');
        $(this).find('i').removeClass('zmdi-eye-off');
        showPass = 0;
      }

    });


    /*==================================================================
    [ Select Departement Prio ]*/
    // $('select[name="dept_prio"]').focus(function() {
    //   if ($('select[name="rute"]').val() == "1") {
    //     $('.rute-1-option').each(function(){
    //       $(this).show();
    //     });
    //     $('.rute-2-option').each(function(){
    //       $(this).hide();
    //     });
    //   } else if ($('select[name="rute"]').val() == "2") {
    //     $('.rute-1-option').each(function(){
    //       $(this).hide();
    //     });
    //     $('.rute-2-option').each(function(){
    //       $(this).show();
    //     });
    //   } else {
    //     $('.rute-1-option').each(function(){
    //       $(this).hide();
    //     });
    //     $('.rute-2-option').each(function(){
    //       $(this).hide();
    //     });
    //   }
    // });

    // $('input[type="checkbox"]').focus(function(){
    //   var sesi = $(this).val();
    //   if($(this).prop("checked") == true){
    //     $('.'+sesi+'-option').hide();
    //     $('select[name="'+sesi+'"]').val("");
    //     $('select[name="'+sesi+'"]').attr("required", true);
    //     $('select[name="'+sesi+'"]').removeClass("has-val");
    //     $('.'+sesi+'-div.wrap-input100').removeClass("validate-input");
    //     // $('.'+sesi+'-div.wrap-input100').removeClass("alert-validate");
    //   }
    //   else if($(this).prop("checked") == false){
    //     $('.'+sesi+'-option').show();
    //     $('select[name="'+sesi+'"]').attr("required", false);
    //     $('.'+sesi+'-div.wrap-input100').addClass("validate-input");
    //     // $('.'+sesi+'-div.wrap-input100').addClass("alert-validate");
    //   }
    // });

    $('.form-link').click(function() {
      $('.hide-and-seek:eq(0)').hide(1000);
      $('.hide-and-seek:eq(1)').show(1000);
      $('.back-icon-wrapper').fadeIn(1000);
    });
    $('.back-icon-wrapper').click(function() {
      $('.hide-and-seek:eq(0)').show(1000);
      $('.hide-and-seek:eq(1)').hide(1000);
      $('.back-icon-wrapper').fadeOut(1000);
    })
  })(jQuery);

  function checkbox_cek() {
    var checkBox = document.getElementById("lain");
    var form = document.getElementById("lain-lain");
    if (checkBox.checked == true){
      form.style.display = "block";
    } else {
      form.style.display = "none";
    }
  }


  function checkbox_sesi(ele) {
    var checkBox = document.getElementById(ele);
    var form = document.getElementById("select-"+ele);
    var select = document.getElementById("select-form-"+ele);
    if (checkBox.checked == true){
      form.style.display = "block";
      select.classList.add("select-active-"+ele);
    } else {
      form.style.display = "none";
      select.selectedIndex = 0;
      select.classList.remove("select-active-"+ele);
      select.classList.remove("has-val");
    }
  }

  function submit_data(){
    // var x = document.getElementById("myDIV").querySelectorAll(".input100");
    // x.forEach(check);

    // function check(item, index, arr){
    //   if(s1.classList.contains("active"))
    // }
    const s1 = document.querySelector("#select-form-sesi-1");
    const s2 = document.querySelector("#select-form-sesi-2");
    const s3 = document.querySelector("#select-form-sesi-3");
    const s4 = document.querySelector("#select-form-sesi-4");
    const s5 = document.querySelector("#select-form-sesi-5");
    const s6 = document.querySelector("#select-form-sesi-6");
    const s7 = document.querySelector("#select-form-sesi-7");
    var ss1 = s1.classList.contains("select-active-sesi-1");
    var ss2 = s2.classList.contains("select-active-sesi-2");
    var ss3 = s3.classList.contains("select-active-sesi-3");
    var ss4 = s4.classList.contains("select-active-sesi-4");
    var ss5 = s5.classList.contains("select-active-sesi-5");
    var ss6 = s6.classList.contains("select-active-sesi-6");
    var ss7 = s7.classList.contains("select-active-sesi-7");
    var msg;
    if (ss1 === true) {
      if(document.getElementById("select-form-sesi-1").selectedIndex == 0){
        event.preventDefault();
        if (msg == null) {
          msg = "Sesi 1";
        } else {
          msg = msg+", Sesi 1";
        }
      }
    }
    if (ss2 === true) {
      if(document.getElementById("select-form-sesi-2").selectedIndex == 0){
        event.preventDefault();
        if (msg == null) {
          msg = "Sesi 2";
        } else {
          msg = msg+", Sesi 2";
        }
      }
    }
    if (ss3 === true) {
      if(document.getElementById("select-form-sesi-3").selectedIndex == 0){
        event.preventDefault();
        if (msg == null) {
          msg = "Sesi 3";
        } else {
          msg = msg+", Sesi 3";
        }
      }
    }
    if (ss4 === true) {
      if(document.getElementById("select-form-sesi-4").selectedIndex == 0){
        event.preventDefault();
        if (msg == null) {
          msg = "Sesi 4";
        } else {
          msg = msg+", Sesi 4";
        }
      }
    }
    if (ss5 === true) {
     if(document.getElementById("select-form-sesi-5").selectedIndex == 0){
      event.preventDefault();
      if (msg == null) {
          msg = "Sesi 5";
        } else {
          msg = msg+", Sesi 5";
        }
    }
  }
  if (ss6 === true) {
    if(document.getElementById("select-form-sesi-6").selectedIndex == 0){
      event.preventDefault();
      if (msg == null) {
          msg = "Sesi 6";
        } else {
          msg = msg+", Sesi 6";
        }
    }
  }
  if (ss7 === true) {
    if(document.getElementById("select-form-sesi-7").selectedIndex == 0){
      event.preventDefault();
      if (msg == null) {
          msg = "Sesi 7";
        } else {
          msg = msg+", Sesi 7";
        }
    }
  }
  if (ss1 !== true && ss2 !== true && ss3 !== true && ss4 !== true && ss5 !== true && ss6 !== true && ss7 !== true) {
    event.preventDefault();
    alert("Silahkan pilih salah satu sesi dan pilih departemen prioritasnya!");
  }

  if (msg != null) {
    alert("Silahkan pilih departemen prioritas untuk "+msg+" terlebih dahulu!");
  }

  if($('div.info-checkbox.required :checkbox:checked').length <= 0){
      alert("Silahkan pilih darimana anda tahu informasi Open Campus INI LHO ITS! 2021");
    }
}

$(function () {
  $("#oprec").keypress(function (e) {
    var keyCode = e.keyCode || e.which;

            //Regex for Valid Characters i.e. Alphabets and Numbers.
            var regex = /^[A-Za-z0-9 @.-_ \n\r]+$/;
            
            //Validate TextBox value against the Regex.
            var isValid = regex.test(String.fromCharCode(keyCode));
            if (!isValid) {
              alert("Only Alphabets and Numbers allowed.");
            }

            return isValid;
          });
});