<body class="body-bg-oc">
 <div class="limiter">
  <div class="container-login100">
    <div class="wrap-login100">
      <div class="hide-and-seek">
        <form action="<?php echo base_url()."formopencampus" ?>" name="regoc" id="regoc" method="POST">
          <span class="login100-form-title">
           PENDAFTARAN OPEN CAMPUS INI LHO ITS! 2021
         </span>
         <span style="text-align: justify;">Open Campus INI LHO ITS! 2021 merupakan sebuah acara pengenalan kehidupan perkuliahan beserta keilmuan, prospek kerja, dan prestasi-prestasi membanggakan yang dimiliki oleh setiap departemen di ITS. Dengan bertemakan "Ruang Mimpi" diharapkan para peserta dapat memiliki gambaran yang lebih jelas mengenai keilmuan yang akan ditekuni serta semakin termotivasi untuk melangkah ke jenjang perguruan tinggi. Open Campus akan dilaksanakan selama tiga hari yaitu pada 7, 13, dan 14 Februari 2021 dalam 7 sesi dengan pembagian jadwal sebagai berikut:</br></br>
          <b>Minggu, 7 Februari 2021:</b></br>
          <ol>
            <li>
              Sesi 1 - FTIRS (08.00 - 11.30 WIB)
            </li>
            <li>
              Sesi 2 - FTK (11.45 - 14.55 WIB)
            </li>
            <li>
              Sesi 3 - FDKBD (15.00 - 18.30 WIB)
            </li>
          </ol>
          <b>Sabtu, 13 Februari 2021:</b></br>
          <ol>
            <li>
              Sesi 4 - FV (07.45 - 11.30 WIB)
            </li>
            <li>
              Sesi 5 - FTEIC (11.45 - 15.30 WIB)
            </li>
          </ol>
          <b>Minggu, 14 Februari 2021:</b></br>
          <ol>
            <li>
              Sesi 6 - FSAD (07.45 - 11.30 WIB)
            </li>
            <li>
              Sesi 7 - FTSPK (11.45 - 15.30 WIB)
            </li>
          </ol>
          Setelah memilih sesi yang kalian inginkan, jangan lupa <b>pilih satu departemen</b> yang ada dalam Fakultas tersebut sesuai minat kalian ya !</span>
          <hr>
          <span> LIST KUOTA PER DEPARTEMEN </span>
          <br>
          <br>
          <table width="100%">
            <tr>
              <td colspan="2" style="text-align: center; font-weight: bold;">FTIRS</td>
            </tr>
            <?php if (isset($FTIRSTM)) { ?>
              <tr>
                <td>Teknik Mesin</td>
                <td><?= $FTIRSTM ?>/300</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTIRSTF)) { ?>
              <tr>
                <td>Teknik Fisika</td>
                <td><?= $FTIRSTF ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTIRSTSI)) { ?>
              <tr>
                <td>Teknik Sistem dan Industri</td>
                <td><?= $FTIRSTSI ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTIRSTMM)) { ?>
              <tr>
                <td>Teknik Material dan Metalurgi</td>
                <td><?= $FTIRSTMM ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTIRSTK)) { ?>
              <tr>
                <td>Teknik Kimia</td>
                <td><?= $FTIRSTK ?>/200</td>
              </tr>
            <?php } ?>
            <tr>
              <td colspan="2" style="text-align: center; font-weight: bold;">FTK</td>
            </tr>
            <?php if (isset($FTKTP)) { ?>
              <tr>
                <td>Teknik Perkapalan</td>
                <td><?= $FTKTP ?>/160</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTKTSP)) { ?>
              <tr>
                <td>Teknik Sistem Perkapalan</td>
                <td><?= $FTKTSP ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTKTK)) { ?>
              <tr>
                <td>Teknik Kelautan</td>
                <td><?= $FTKTK ?>/120</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTKTTL)) { ?>
              <tr>
                <td>Teknik Transportasi Laut</td>
                <td><?= $FTKTTL ?>/50</td>
              </tr>
            <?php } ?>
            <tr>
              <td colspan="2" style="text-align: center; font-weight: bold;">FDKBD</td>
            </tr>
            <?php if (isset($FDKBDDP)) { ?>
              <tr>
                <td>Desain Produk</td>
                <td><?= $FDKBDDP ?>/120</td>
              </tr>
            <?php } ?>
            <?php if (isset($FDKBDDKV)) { ?>
              <tr>
                <td>Desain Komunikasi Visual</td>
                <td><?= $FDKBDDKV ?>/80</td>
              </tr>
            <?php } ?>
            <?php if (isset($FDKBDDI)) { ?>
              <tr>
                <td>Desain Interior</td>
                <td><?= $FDKBDDI ?>/80</td>
              </tr>
            <?php } ?>
            <?php if (isset($FDKBDMB)) { ?>
              <tr>
                <td>Manajemen Bisnis</td>
                <td><?= $FDKBDMB ?>/130</td>
              </tr>
            <?php } ?>
            <?php if (isset($FDKBDSP)) { ?>
              <tr>
                <td>Studi Pembangunan</td>
                <td><?= $FDKBDSP ?>/100</td>
              </tr>
            <?php } ?>
            <tr>
              <td colspan="2" style="text-align: center; font-weight: bold;">FV</td>
            </tr>
            <?php if (isset($VokasiTIS)) { ?>
              <tr>
                <td>Teknik Infrastruktur Sipil</td>
                <td><?= $VokasiTIS ?>/180</td>
              </tr>
            <?php } ?>
            <?php if (isset($VokasiTMI)) { ?>
              <tr>
                <td>Teknik Mesin Industri</td>
                <td><?= $VokasiTMI ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($VokasiTEO)) { ?>
              <tr>
                <td>Teknik Elektro Otomasi</td>
                <td><?= $VokasiTEO ?>/140</td>
              </tr>
            <?php } ?>
            <?php if (isset($VokasiTKI)) { ?>
              <tr>
                <td>Teknik Kimia Industri</td>
                <td><?= $VokasiTKI ?>/100</td>
              </tr>
            <?php } ?>
            <?php if (isset($VokasiTI)) { ?>
              <tr>
                <td>Teknik Instrumentasi</td>
                <td><?= $VokasiTI ?>/130</td>
              </tr>
            <?php } ?>
            <?php if (isset($VokasiSB)) { ?>
              <tr>
                <td>Statistika Bisnis</td>
                <td><?= $VokasiSB ?>/130</td>
              </tr>
            <?php } ?>
            <tr>
              <td colspan="2" style="text-align: center; font-weight: bold;">FTEIC</td>
            </tr>
            <?php if (isset($FTEICTE)) { ?>
              <tr>
                <td>Teknik Elektro</td>
                <td><?= $FTEICTE ?>/280</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTEICTB)) { ?>
              <tr>
                <td>Teknik Biomedik</td>
                <td><?= $FTEICTB ?>/80</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTEICTK)) { ?>
              <tr>
                <td>Teknik Komputer</td>
                <td><?= $FTEICTK ?>/80</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTEICTI)) { ?>
              <tr>
                <td>Teknik Informatika</td>
                <td><?= $FTEICTI ?>/300</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTEICSI)) { ?>
              <tr>
                <td>Sistem Informasi</td>
                <td><?= $FTEICSI ?>/220</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTEICIT)) { ?>
              <tr>
                <td>Teknologi Informasi</td>
                <td><?= $FTEICIT ?>/80</td>
              </tr>
            <?php } ?>
            <tr>
              <td colspan="2" style="text-align: center; font-weight: bold;">FSAD</td>
            </tr>
            <?php if (isset($FSADFIS)) { ?>
              <tr>
                <td>Fisika</td>
                <td><?= $FSADFIS ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FSADKIM)) { ?>
              <tr>
                <td>Kimia</td>
                <td><?= $FSADKIM ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FSADBIO)) { ?>
              <tr>
                <td>Biologi</td>
                <td><?= $FSADBIO ?>/120</td>
              </tr>
            <?php } ?>
            <?php if (isset($FSADMAT)) { ?>
              <tr>
                <td>Matematika</td>
                <td><?= $FSADMAT ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FSADST)) { ?>
              <tr>
                <td>Statistika</td>
                <td><?= $FSADST ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FSADAK)) { ?>
              <tr>
                <td>Aktuaria</td>
                <td><?= $FSADAK ?>/120</td>
              </tr>
            <?php } ?>
            <tr>
              <td colspan="2" style="text-align: center; font-weight: bold;">FTSPK</td>
            </tr>
            <?php if (isset($FTSPKTS)) { ?>
              <tr>
                <td>Teknik Sipil</td>
                <td><?= $FTSPKTS ?>/200</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTSPKTA)) { ?>
              <tr>
                <td>Teknik Arsitektur</td>
                <td><?= $FTSPKTA ?>/150</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTSPKTL)) { ?>
              <tr>
                <td>Teknik Lingkungan</td>
                <td><?= $FTSPKTL ?>/160</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTSPKTPWK)) { ?>
              <tr>
                <td>Teknik Perencanaan Wilayah Kota</td>
                <td><?= $FTSPKTPWK ?>/190</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTSPKTGM)) { ?>
              <tr>
                <td>Teknik Geomatika</td>
                <td><?= $FTSPKTGM ?>/150</td>
              </tr>
            <?php } ?>
            <?php if (isset($FTSPKTGF)) { ?>
              <tr>
                <td>Teknik Geofisika</td>
                <td><?= $FTSPKTGF ?>/100</td>
              </tr>
            <?php } ?>

          </table>
          <hr>

          <div class="container-login100-form-btn">
            <div class="wrap-login100-form-btn">
              <div class="login100-form-bgbtn"></div>
              <button class="login100-form-btn" name="submit" type="submit" form="regoc" value="Daftar!">
                Daftar!
              </button>
            </div>
          </div>
        </form>
        <div>
          <p>Udah daftar tapi lupa Nomer Registrasinya? Tenang, <a href="#" class="form-link">klik disini yuk</a></p>
        </div>
      </div>
      <div class="hide-and-seek" style="display:none;">
        <form action="<?php echo base_url()."cariopencampus"?>" name="search" id="search" method="POST">
          <span class="login100-form-title">
           CEK PENDAFTARAN TALKSHOW INSPIRATIF INI LOH ITS! 2021
         </span>
         <div class="wrap-input100 validate-input" data-validate = "Tulis email Anda">
          <input class="input100" type="email" name="email">
          <span class="focus-input100" data-placeholder="Masukkan Email Anda"></span>
        </div>
        <div class="container-login100-form-btn">
          <div class="wrap-login100-form-btn">
            <div class="login100-form-bgbtn"></div>
            <button class="login100-form-btn" name="submit" type="submit" form="search" value="Cek!">
              Cek!
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<div class="back-icon-wrapper" style="display:none;">
  <img src="<?php echo base_url(); ?>assets/formEvent/img/back-icon.png"/>
</div>
</body>
</html>