
<body class="body-bg-oc">
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form action="<?php echo base_url()."inputopencampus" ?>" class="login100-form validate-form" name="oprec" id="oprec" method="POST" enctype="multipart/form-data">
					<span class="login100-form-title">
						FORMULIR PENDAFTARAN<br>OPEN CAMPUS<br>INI LHO ITS! 2021
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Tulis Nama Lengkap">
						<input class="input100" type="text" name="nama">
						<span class="focus-input100" data-placeholder="Nama Lengkap"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Masukkan Asal Sekolah Anda">
						<input class="input100" type="text" name="sekolah">
						<span class="focus-input100" data-placeholder="Asal Sekolah"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Masukkan Nomor Telepon Valid Anda [10-15 digit angka]">
						<input class="input100" type="text" name="no_hp">
						<span class="focus-input100" data-placeholder="Nomor Telepon"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Masukkan ID Line Anda">
						<input class="input100" type="text" name="line">
						<span class="focus-input100" data-placeholder="ID Line"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Masukkan Email Anda">
						<input class="input100" type="email" name="email">
						<span class="focus-input100" data-placeholder="Email"></span>
						<span id="email_result"></span>
					</div>

					<label><p>Pilih Sesi yang ingin kamu ikuti :</p></label></label><br>
					<input type="checkbox" id="sesi-1" name="sesi[]" value="sesi-1" onclick="checkbox_sesi('sesi-1')">
					<label for="sesi-1"><b>DAY- 1 / Sesi 1 - FTIRS</b> <br><p>(FAKULTAS TEKNOLOGI INDUSTRI DAN REKAYASA SISTEM)</p></label><br>

					<input type="checkbox" id="sesi-2" name="sesi[]" value="sesi-2" onclick="checkbox_sesi('sesi-2')">
					<label for="sesi-2"><b>DAY- 1 / Sesi 2 - FTK</b> <br><p>(FAKULTAS TEKNOLOGI KELAUTAN)</p></label><br>

					<input type="checkbox" id="sesi-3" name="sesi[]" value="sesi-3" onclick="checkbox_sesi('sesi-3')">
					<label for="sesi-3"><b>DAY- 1 / Sesi 3 - FDKBD</b> <br><p>(FAKULTAS DESAIN KREATIF DAN BISNIS DIGITAL)</p></label><br>

					<input type="checkbox" id="sesi-4" name="sesi[]" value="sesi-4" onclick="checkbox_sesi('sesi-4')">
					<label for="sesi-4"><b>DAY- 2 / Sesi 1 - FV</b> <br><p>(FAKULTAS VOKASI)</p></label><br>

					<input type="checkbox" id="sesi-5" name="sesi[]" value="sesi-5" onclick="checkbox_sesi('sesi-5')">
					<label for="sesi-5"><b>DAY- 2 / Sesi 2 - FTEIC</b> <br><p>(FAKULTAS TEKNOLOGI ELEKTRO DAN INFORMATIKA CERDAS)</p></label><br>

					<input type="checkbox" id="sesi-6" name="sesi[]" value="sesi-6" onclick="checkbox_sesi('sesi-6')">
					<label for="sesi-6"><b>DAY- 3 / Sesi 1 - FSAD</b> <br><p>(FAKULTAS SAINS DAN ANALITIKA DATA)</p></label><br>

					<input type="checkbox" id="sesi-7" name="sesi[]" value="sesi-7" onclick="checkbox_sesi('sesi-7')">
					<label for="sesi-7"><b>DAY- 3 / Sesi 2 - FTSPK</b> <br><p>(FAKULTAS TEKNIK SIPIL, PERENCANAAN, DAN KEBUMIAN)</p></label><br>

					<div class="select-sesi">
						<div class="wrap-input100 " id="select-sesi-1" style="display: none;" data-validate = "Pilih Departemen yang paling di minati di sesi 1">
							<select name="sesi-1" id="select-form-sesi-1" class="input100" style="border: none; outline: 0">	
								<option selected hidden></option>
								<?php if ($FTIRSTM < 300) {?>
									<option class = "sesi-1-option" value="Teknik Mesin">FTIRS // Teknik Mesin</option>
								<?php }
								if ($FTIRSTF  < 200) {?>
									<option class = "sesi-1-option" value="Teknik Fisika">FTIRS // Teknik Fisika</option>
								<?php }
								if ($FTIRSTSI < 200) {?>
									<option class = "sesi-1-option" value="Teknik Sistem dan Industri">FTIRS // Teknik Sistem dan Industri</option>
								<?php }
								if ($FTIRSTMM < 200) {?>
									<option class = "sesi-1-option" value="Teknik Material dan Metalurgi">FTIRS // Teknik Material dan Metalurgi</option>
								<?php }
								if ($FTIRSTK < 200) {?>
									<option class = "sesi-1-option" value="Teknik Kimia">FTIRS // Teknik Kimia</option>
								<?php } ?>							
							</select>
							<span class="focus-input100" data-placeholder="Pilih Departemen Prioritas Sesi 1"></span>
						</div>

						<div class="wrap-input100 " id="select-sesi-2" style="display: none;" data-validate = "Pilih Departemen yang paling di minati di sesi 2">
							<select name="sesi-2" id="select-form-sesi-2" class="input100" style="border: none; outline: 0">	
								<option selected hidden></option>
								<?php
								if ($FTKTP < 160) {?>
									<option class = "sesi-2-option" value="Teknik Perkapalan">FTK // Teknik Perkapalan</option>
								<?php }
								if ($FTKTSP < 200) {?>
									<option class = "sesi-2-option" value="Teknik Sistem Perkapalan">FTK // Teknik Sistem Perkapalan</option>
								<?php }
								if ($FTKTK < 120) {?>
									<option class = "sesi-2-option" value="Teknik Kelautan">FTK // Teknik Kelautan</option>
								<?php }
								if ($FTKTTL < 50) {?>
									<option class = "sesi-2-option" value="Teknik Transportasi Laut">FTK // Teknik Transportasi Laut</option>
								<?php } ?>
							</select>
							<span class="focus-input100" data-placeholder="Pilih Departemen Prioritas Sesi 2"></span>
						</div>

						<div class="wrap-input100 " id="select-sesi-3" style="display: none;" data-validate = "Pilih Departemen yang paling di minati di sesi 3">
							<select name="sesi-3" id="select-form-sesi-3" class="input100" style="border: none; outline: 0">	
								<option selected hidden></option>
								<?php
								if ($FDKBDDKV < 120) {?>
									<option class = "sesi-3-option" value="Desain Produk">FDKBD // Desain Produk</option>
								<?php }
								if ($FDKBDDKV < 80) {?>
									<option class = "sesi-3-option" value="Desain Komunikasi Visual">FDKBD // Desain Komunikasi Visual</option>
								<?php }
								if ($FDKBDDI < 80) {?>
									<option class = "sesi-3-option" value="Desain Interior">FDKBD // Desain Interior</option>
								<?php }
								if ($FDKBDMB < 130) {?>
									<option class = "sesi-3-option" value="Manajemen Bisnis">FDKBD // Manajemen Bisnis</option>
								<?php }
								if ($FDKBDSP < 100) {?>
									<option class = "sesi-3-option" value="Studi Pembangunan">FDKBD // Studi Pembangunan</option>
								<?php }?>
							</select>
							<span class="focus-input100" data-placeholder="Pilih Departemen Prioritas Sesi 3"></span>
						</div>

						<div class="wrap-input100 " id="select-sesi-4" style="display: none;" data-validate = "Pilih Departemen yang paling di minati di sesi 4">
							<select name="sesi-4" id="select-form-sesi-4" class="input100" style="border: none; outline: 0">	
								<option selected hidden></option>
								<?php
								if ($VokasiTIS  < 180) {?>
									<option class = "sesi-4-option" value="Teknik Infrastruktur Sipil">FV // Teknik Infrastruktur Sipil</option>
								<?php }
								if ($VokasiTMI  < 200) {?>
									<option class = "sesi-4-option" value="Teknik Mesin Industri">FV // Teknik Mesin Industri</option>
								<?php }
								if ($VokasiTEO  < 140) {?>
									<option class = "sesi-4-option" value="Teknik Elektro Otomasi">FV // Teknik Elektro Otomasi</option>
								<?php }
								if ($VokasiTKI  < 100) {?>
									<option class = "sesi-4-option" value="Teknik Kimia Industri">FV // Teknik Kimia Industri</option>
								<?php }
								if ($VokasiTI  < 130) {?>
									<option class = "sesi-4-option" value="Teknik Instrumentasi">FV // Teknik Instrumentasi</option>
								<?php }
								if ($VokasiSB  < 130) {?>
									<option class = "sesi-4-option" value="Statistika Bisnis">FV // Statistika Bisnis</option>
								<?php }?>
							</select>
							<span class="focus-input100" data-placeholder="Pilih Departemen Prioritas Sesi 4"></span>
						</div>

						<div class="wrap-input100 " id="select-sesi-5" style="display: none;" data-validate = "Pilih Departemen yang paling di minati di sesi 5">
							<select name="sesi-5" id="select-form-sesi-5" class="input100" style="border: none; outline: 0">	
								<option selected hidden></option>
								<?php
								if ($FTEICTE < 280) {?>
									<option class = "sesi-5-option" value="Teknik Elektro">FTEIC // Teknik Elektro</option>
								<?php }
								if ($FTEICTB < 80) {?>
									<option class = "sesi-5-option" value="Teknik Biomedik">FTEIC // Teknik Biomedik</option>
								<?php }
								if ($FTEICTK < 80) {?>
									<option class = "sesi-5-option" value="Teknik Komputer">FTEIC // Teknik Komputer</option>
								<?php }
								if ($FTEICTI < 300) {?>
									<option class = "sesi-5-option" value="Teknik Informatika">FTEIC // Teknik Informatika</option>
								<?php }
								if ($FTEICSI < 220) {?>
									<option class = "sesi-5-option" value="Sistem Informasi">FTEIC // Sistem Informasi</option>
								<?php }
								if ($FTEICIT < 80) {?>
									<option class = "sesi-5-option" value="Teknologi Informasi">FTEIC // Teknologi Informasi</option>
								<?php }?>
							</select>
							<span class="focus-input100" data-placeholder="Pilih Departemen Prioritas Sesi 5"></span>
						</div>

						<div class="wrap-input100 " id="select-sesi-6" style="display: none;" data-validate = "Pilih Departemen yang paling di minati di sesi 6">
							<select name="sesi-6" id="select-form-sesi-6" class="input100" style="border: none; outline: 0">	
								<option selected hidden></option>
								<?php
								if ($FSADFIS < 200) {?>
									<option class = "sesi-6-option" value="Fisika">FSAD // Fisika</option>
								<?php }
								if ($FSADKIM < 200) {?>
									<option class = "sesi-6-option" value="Kimia">FSAD // Kimia</option>
								<?php }
								if ($FSADBIO < 120) {?>
									<option class = "sesi-6-option" value="Biologi">FSAD // Biologi</option>
								<?php }
								if ($FSADMAT < 200) {?>
									<option class = "sesi-6-option" value="Matematika">FSAD // Matematika</option>
								<?php }
								if ($FSADST < 200) {?>
									<option class = "sesi-6-option" value="Statistika">FSAD // Statistika</option>
								<?php }
								if ($FSADAK < 120) {?>
									<option class = "sesi-6-option" value="Aktuaria">FSAD // Aktuaria</option>
								<?php }?>
							</select>
							<span class="focus-input100" data-placeholder="Pilih Departemen Prioritas Sesi 6"></span>
						</div>

						<div class="wrap-input100 " id="select-sesi-7" style="display: none;" data-validate = "Pilih Departemen yang paling di minati di sesi 7">
							<select name="sesi-7" id="select-form-sesi-7" class="input100" style="border: none; outline: 0">	
								<option selected hidden></option>
								<?php
								if ($FTSPKTS < 200) {?>
									<option class = "sesi-7-option" value="Teknik Sipil">FTSPK // Teknik Sipil</option>
								<?php }
								if ($FTSPKTA < 150) {?>
									<option class = "sesi-7-option" value="Teknik Arsitektur">FTSPK // Teknik Arsitektur</option>
								<?php }
								if ($FTSPKTL < 160) {?>
									<option class = "sesi-7-option" value="Teknik Lingkungan">FTSPK // Teknik Lingkungan</option>
								<?php }
								if ($FTSPKTPWK < 190) {?>
									<option class = "sesi-7-option" value="Teknik Perencanaan Wilayah Kota">FTSPK // Teknik Perencanaan Wilayah Kota</option>
								<?php }
								if ($FTSPKTGM < 150) {?>
									<option class = "sesi-7-option" value="Teknik Geomatika">FTSPK // Teknik Geomatika</option>
								<?php }
								if ($FTSPKTGF < 100) {?>
									<option class = "sesi-7-option" value="Teknik Geofisika">FTSPK // Teknik Geofisika</option>
								<?php }?>
							</select>
							<span class="focus-input100" data-placeholder="Pilih Departemen Prioritas Sesi 7"></span>
						</div>
					</div>

					<label><p>Upload Bukti SS Instastory (Max. File Size 2MB)</p></label>
					<div class="wrap-input100 validate-input" data-validate = "Anda belum upload file">
						<input class="input100" type="file" name="file">
						<span class="focus-input100" data-placeholder=""></span>
						<p>Syarat Pendaftaran : Share slide pertama dari post feeds IG pada link berikut : <a href="https://www.instagram.com/p/CKrAM0spUkI/?igshid=nant0y3hhhn0"> https://www.instagram.com/p/CKrAM0spUkI/?igshid=nant0y3hhhn0</a> ke instastory kalian masing-masing. Jangan lupa tag min. 3 teman kalian dan beri kalimat ajakan semenarik mungkin !</p>
					</div>

					<label><p>Dari mana kalian tahu informasi tentang Open Campus INI LHO ITS! 2021?</p></label>
					<div class="info-checkbox required">
						<input type="checkbox" id="sekolah" name="info[]" value="sekolah">
						<label for="sekolah">Sekolah</label><br>

						<input type="checkbox" id="teman" name="info[]" value="teman">
						<label for="teman">Teman</label><br>

						<input type="checkbox" id="keluarga" name="info[]" value="keluarga">
						<label for="keluarga">Keluarga</label><br>

						<input type="checkbox" id="medsos" name="info[]" value="media sosial">
						<label for="medsos">Media Sosial</label><br>

						<input type="checkbox" id="lain" onclick="checkbox_cek()">
						<label for="lain">Lain - Lain</label><br>
					</div>

					<div class="wrap-input100" id="lain-lain" data-validate = "Field ini tidak boleh kosong" style="display: none;">
						<input class="input100" type="text" name="lain">
						<span class="focus-input100" data-placeholder="Lain-lain"></span>
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" name="submit" type="submit" form="oprec" value="submit" onclick="submit_data()">
								Yuk Daftar!
							</button>
						</div>
					</div>

				</form>
			</div>
		</div>
	</div>