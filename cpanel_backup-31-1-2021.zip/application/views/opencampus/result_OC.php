<?php 
$sesi1 = array('Teknik Mesin','Teknik Fisika','Teknik Sistem dan Industri','Teknik Material dan Metalurgi','Teknik Kimia');
$sesi2 = array('Teknik Perkapalan','Teknik Sistem Perkapalan','Teknik Kelautan','Teknik Transportasi Laut');
$sesi3 = array('Desain Produk','Desain Komunikasi Visual','Desain Interior','Manajemen Bisnis','Studi Pembangunan');
$sesi4 = array('Teknik Infrastruktur Sipil','Teknik Mesin Industri','Teknik Elektro Otomasi','Teknik Kimia Industri','Teknik Instrumentasi','Statistika Bisnis');
$sesi5 = array('Teknik Elektro','Teknik Biomedik','Teknik Komputer','Teknik Informatika','Sistem Informasi','Teknologi Informasi');
$sesi6 = array('Fisika','Kimia','Biologi','Matematika','Statistika','Aktuaria');
$sesi7 = array('Teknik Sipil','Teknik Arsitektur','Teknik Lingkungan','Teknik Perencanaan Wilayah Kota','Teknik Geomatika','Teknik Geofisika');

?>
<body class="body-bg-oc">

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<?php if ($status == "GAGAL" ) { ?>
					<form action="<?php echo base_url()."DaftarOpenCampusILITS2021" ?>" class="login100-form validate-form" name="done" id="done" method="POST">
						<span class="login100-form-title">
							Data tidak ditemukan
						</span>
						<span class="login100-form-titlex">
							Email yang kamu masukkan mungkin salah, yuk coba cek lagi emailnya
						</span>
						<span class="login100-form-title">

						</span>
						<div class="container-login100-form-btn">
							<div class="wrap-login100-form-btn">
								<div class="login100-form-bgbtn"></div>
								<button class="login100-form-btn" name="submit" type="submit" form="done" value="submit">
									Klik untuk kembali!
								</button>
							</div>
						</div>
					</form>
				<?php } else { ?>
					<form action="<?php echo base_url()."DaftarOpenCampusILITS2021" ?>" class="login100-form validate-form" name="done" id="done" method="POST">
						<span class="login100-form-title">
							Selamat kamu sudah terdaftar!
						</span>

						<span class="login100-form-titlex">
							Kamu sudah terdaftar nih jadi peserta OPEN CAMPUS INI LHO ITS 2021!
							<br> 
							<hr>
							<?php 
							foreach ($link as $key) {
								if (in_array($key->dept_prio, $sesi1)) {
									$snm = "FTIRS";
									$link = 'OpenCampusILITSSesi1';
									$tgl = 'Minggu, 7 Februari 2021, Pukul 08.00 - 11.30 WIB';
								} else if (in_array($key->dept_prio, $sesi2)) {
									$snm = "FTK";
									$link = 'OpenCampusILITSSesi2';
									$tgl = 'Minggu, 7 Februari 2021, Pukul 11.45 - 14.55 WIB';
								} else if (in_array($key->dept_prio, $sesi3)) {
									$snm = "FDKBD";
									$link = 'OpenCampusILITSSesi3';
									$tgl = 'Minggu, 7 Februari 2021, Pukul 15.00 - 18.30 WIB';
								} else if (in_array($key->dept_prio, $sesi4)) {
									$snm = "FV";
									$link = 'OpenCampusILITSSesi4';
									$tgl = 'Sabtu, 13 Februari 2021, Pukul 07.45 - 11.30 WIB';
								} else if (in_array($key->dept_prio, $sesi5)) {
									$snm = "FTEIC";
									$link = 'OpenCampusILITSSesi5';
									$tgl = 'Sabtu, 13 Februari 2021, Pukul 11.45 - 15.30 WIB';
								} else if (in_array($key->dept_prio, $sesi6)) {
									$snm = "FSAD";
									$link = 'OpenCampusILITSSesi6';
									$tgl = 'Minggu, 14 Februari 2021, Pukul 07.45 - 11.30 WIB';
								} else if (in_array($key->dept_prio, $sesi7)) {
									$snm = "FTSPK";
									$link = 'OpenCampusILITSSesi7';
									$tgl = 'Minggu, 14 Februari 2021, Pukul 11.45 - 15.30 WIB';
								} 
								echo "<b>Untuk ".strtoupper($key->sesi);
								echo " :<br>".$tgl."</b><br>";
								echo "Gunakan format nama berikut :<br><b>".$key->no_regis."</b><br>";
								echo "Serta berikut adalah link zoom untuk ".strtoupper($key->sesi)."(".$snm.") :";
								echo "<br><b><a href='https://inilho.its.ac.id/".$link."'>https://inilho.its.ac.id/".$link."</a></b><br><hr>";
							}
							?>
							Agar tidak tertinggal informasi lainnya, pantau terus instagram kita di <a href="https://www.instagram.com/inilhoits/"><b>@inilhoits</b></a>.
							<br><r>

							Terima kasih banyak, Sampai ketemu di room zoom. See you there!
						</span>

						<form action="<?php echo base_url()."DaftarOpenCampusILITS2021" ?>" class="login100-form validate-form" name="done" id="done">
							<div class="container-login100-form-btn">
								<div class="wrap-login100-form-btn">
									<div class="login100-form-bgbtn"></div>
									<button class="login100-form-btn" name="submit" type="submit" form="done" value="submit">
										Klik untuk kembali ke Daftar Open Campus ILITS2021!
									</button>
								</div>
							</div>
						</form>
					<?php } ?>
				</div>
			</div>
		</div>