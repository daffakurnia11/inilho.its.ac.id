<body class="body-bg-ts">
   <div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100">
            <div class="hide-and-seek">
                <span class="login100-form-title">
					Pendaftaran Talkshow sudah di tutup
				</span>
				<span class="login100-form-titlex">
					Karena kuota pendaftar telah mencapai batas maksimum jadi 
					mohon maaf ya, pendaftarannya di tutup. <br>
					Pantau terus instagram <a href="https://www.instagram.com/inilhoits/"><b>@inilhoits</b></a>
					agar tidak ketinggalan informasi mengenai event-event yang akan di adakan oleh kami.
				</span>
				<span class="login100-form-title">
				</span>
				<div>
                <p>Untuk yang mau cek pendaftaran, bisa <a href="#" class="form-link">cek disini yaa</a></p>
                </div>
        </div>
        <div class="hide-and-seek" style="display:none;">
            <form action="<?php echo base_url()."cari"?>" name="search" id="search" method="POST">
                <span class="login100-form-title">
                 CEK PENDAFTARAN TALKSHOW INI LHO ITS! 2021
             </span>
             <div class="wrap-input100 validate-input" data-validate = "Tulis email Anda">
                <input class="input100" type="text" name="email">
                <span class="focus-input100" data-placeholder="Masukkan Email Anda"></span>
            </div>
            <div class="container-login100-form-btn">
                <div class="wrap-login100-form-btn">
                    <div class="login100-form-bgbtn"></div>
                    <button class="login100-form-btn" name="submit" type="submit" form="search" value="Cek!">
                        Cek!
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
<div class="back-icon-wrapper" style="display:none;">
    <img src="<?php echo base_url(); ?>assets/formEvent/img/back-icon.png"/>
</div>