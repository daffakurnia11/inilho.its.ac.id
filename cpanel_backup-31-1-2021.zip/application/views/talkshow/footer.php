	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/animsition/js/animsition.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/bootstrap/js/popper.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/select2/select2.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/daterangepicker/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/daterangepicker/daterangepicker.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/vendor/countdowntime/countdowntime.js"></script>
	<script src="<?php echo base_url(); ?>assets/formEvent/js/main.js"></script>
</body>
</html>