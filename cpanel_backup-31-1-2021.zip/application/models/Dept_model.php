<?php
class Dept_model extends CI_Model
{
    function fakultas()
    {
        $q = "SELECT * FROM fakultas";
        $query = $this->db->query($q);
        return $query;
    }

    function prestasi()
    {
        $q = "SELECT * FROM land_prestasi";
        return $this->db->query($q)->result_array();
    }

    function fasilitas()
    {
        $q = "SELECT * FROM land_fasilitas";
        return $this->db->query($q)->result_array();
    }

    function select_fasilitas()
    {
        $q = "SELECT * FROM fasilitas";
        $query = $this->db->query($q);
        return $query;
    }

    function select_prestasi($id)
    {
        $q = "SELECT * FROM prestasi WHERE kode_prestasi = " . $id;
        return $this->db->query($q)->result_array();
    }

    function all_prestasi()
    {
        $q = "SELECT * FROM prestasi";
        return $this->db->query($q)->result_array();
    }

    function departemenbyid($id)
    {
        $q = "SELECT * FROM departemen WHERE id_departemen= " . $id;
        $query = $this->db->query($q);
        return $query;
    }

    function profilbyid($id)
    {
        $q = "SELECT * FROM profil_departemen WHERE id_departemen= " . $id . " LIMIT 1";
        $query = $this->db->query($q);
        return $query;
    }

    function alumnibyid($id)
    {
        $q = "SELECT * FROM alumni_departemen WHERE id_departemen= " . $id;
        $query = $this->db->query($q);
        return $query;
    }

    function prospekbyid($id)
    {
        $q = "SELECT * FROM prospek_kerja WHERE id_departemen= " . $id;
        return $this->db->query($q)->result_array();
    }

    function lombabyid($id)
    {
        $q = "SELECT * FROM prestasi_departemen WHERE id_departemen= " . $id;
        $query = $this->db->query($q);
        return $query;
    }

    function labbyid($id)
    {
        $q = "SELECT * FROM lab_departemen WHERE id_departemen= " . $id;
        return $this->db->query($q)->result_array();
    }


    function all_fakultas()
    {
        $q = "SELECT * FROM fakultas";
        return $this->db->query($q)->result_array();
    }

    function fkbyid($id)
    {
        $q = "SELECT * FROM departemen WHERE id_fakultas = " . $id;
        return $this->db->query($q)->result_array();
    }

    function cari_dept($title){
		$this->db->like('nama_departemen', $title , 'both');
		$this->db->order_by('nama_departemen', 'ASC');
		$this->db->limit(10);
		return $this->db->get('departemen')->result();
	}
	
	function todept($nama)
    {
        $q = "SELECT * FROM departemen WHERE nama_departemen = \"$nama\" ";
        return $this->db->query($q)->result_array();
    }
    
}