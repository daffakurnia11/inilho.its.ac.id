<?php 

class M_data extends CI_Model{
    function input_data($data,$table){
        $this->db->insert($table,$data);
    }
    
    function input_data_return_id($data,$table){
        $this->db->insert($table,$data);

        return $this->db->insert_id();
    }

    function get_data($where,$table){
        $this->db->where($where);
        return $this->db->get($table);
    }

    function get_all($table){
    	return $this->db->get($table);
    }
}

?>