<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
  public function index()
  {
    $data['nav'] = 0;
    $this->load->model('dept_model');
    $this->load->view('home/template/header');
    $this->load->view('home/template/navbar', $data);
    $this->load->view('home/index');
    $this->load->view('home/template/footer');
  }
  
  public function fasilitas()
  {
    $this->load->model('dept_model');
    $data['fasilitas'] = $this->dept_model->select_fasilitas()->result();
    $data['nav'] = 1;
    $this->load->view('home/template/header');
    $this->load->view('home/template/navbar', $data);
    $this->load->view('home/fasilitas', $data);
    $this->load->view('home/template/footer');
  }

  public function prestasi()
  {
    $this->load->model('dept_model');
    $data['nav'] = 1;
    $this->load->view('home/template/header');
    $this->load->view('home/template/navbar', $data);
    $this->load->view('home/prestasi');
    $this->load->view('home/template/footer');
  }

  public function departemen($id)
  {
    $this->load->model('dept_model');
    $data['nav'] = 1;
    $data['header'] = $this->dept_model->departemenbyid($id)->result();
    if (empty($data['header'])) {
      redirect('home');
    }
    $data['profil'] = $this->dept_model->profilbyid($id)->result();
    $data['prospek'] = $this->dept_model->prospekbyid($id);
    $data['alumni'] = $this->dept_model->alumnibyid($id)->result();
    $data['lomba'] = $this->dept_model->lombabyid($id)->result();
    $data['lab'] = $this->dept_model->labbyid($id);

    $this->load->view('home/template/header');
    $this->load->view('home/template/navbar', $data);
    $this->load->view('home/departemen', $data);
    $this->load->view('home/template/footer');
  }

  function complete(){
		if (isset($_GET['term'])) {
        $this->load->model('dept_model');
		  	$result = $this->dept_model->cari_dept($_GET['term']);
		   	if (count($result) > 0) {
		    foreach ($result as $row)
		     	$arr_result[] = array(
					'label'	=> $row->nama_departemen,
				);
		     	echo json_encode($arr_result);
		   	}
		}
  }
  
 function search(){
    $title=$this->input->get('departemen');
    $this->load->model('dept_model');
    
	$data=$this->dept_model->todept($title);
    if (count($data) > 0) {
      foreach ($data as $row)
      $id = $row['id_departemen'];
        $this->departemen($id);
      } else {
        $this->index();
      };
   }
    
}