<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Opencampus extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct(){
		parent::__construct();		
		$this->load->model('m_data');
		$this->load->library('upload');
	}

	function cek_jml(){
		$table = 'opencampus_sesi';
		$where = array('dept_prio' => 'Teknik Mesin');
		$query = $this->m_data->get_data($where, $table);
		$FTIRSTM = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Fisika');
		$query = $this->m_data->get_data($where, $table);
		$FTIRSTF = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Sistem dan Industri');
		$query = $this->m_data->get_data($where, $table);
		$FTIRSTSI = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Material dan Metalurgi');
		$query = $this->m_data->get_data($where, $table);
		$FTIRSTMM = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Kimia');
		$query = $this->m_data->get_data($where, $table);
		$FTIRSTK = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Perkapalan');
		$query = $this->m_data->get_data($where, $table);
		$FTKTP = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Sistem Perkapalan');
		$query = $this->m_data->get_data($where, $table);
		$FTKTSP = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Kelautan');
		$query = $this->m_data->get_data($where, $table);
		$FTKTK = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Transportasi Laut');
		$query = $this->m_data->get_data($where, $table);
		$FTKTTL = $query->num_rows();

		$where = array('dept_prio' => 'Desain Produk');
		$query = $this->m_data->get_data($where, $table);
		$FDKBDDP = $query->num_rows();

		$where = array('dept_prio' => 'Desain Komunikasi Visual');
		$query = $this->m_data->get_data($where, $table);
		$FDKBDDKV = $query->num_rows();

		$where = array('dept_prio' => 'Desain Interior');
		$query = $this->m_data->get_data($where, $table);
		$FDKBDDI = $query->num_rows();

		$where = array('dept_prio' => 'Manajemen Bisnis');
		$query = $this->m_data->get_data($where, $table);
		$FDKBDMB = $query->num_rows();

		$where = array('dept_prio' => 'Studi Pembangunan');
		$query = $this->m_data->get_data($where, $table);
		$FDKBDSP = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Infrastruktur Sipil');
		$query = $this->m_data->get_data($where, $table);
		$VokasiTIS = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Mesin Industri');
		$query = $this->m_data->get_data($where, $table);
		$VokasiTMI = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Elektro Otomasi');
		$query = $this->m_data->get_data($where, $table);
		$VokasiTEO = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Kimia Industri');
		$query = $this->m_data->get_data($where, $table);
		$VokasiTKI = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Instrumentasi');
		$query = $this->m_data->get_data($where, $table);
		$VokasiTI = $query->num_rows();

		$where = array('dept_prio' => 'Statistika Bisnis');
		$query = $this->m_data->get_data($where, $table);
		$VokasiSB = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Elektro');
		$query = $this->m_data->get_data($where, $table);
		$FTEICTE = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Biomedik');
		$query = $this->m_data->get_data($where, $table);
		$FTEICTB = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Komputer');
		$query = $this->m_data->get_data($where, $table);
		$FTEICTK = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Informatika');
		$query = $this->m_data->get_data($where, $table);
		$FTEICTI = $query->num_rows();

		$where = array('dept_prio' => 'Sistem Informasi');
		$query = $this->m_data->get_data($where, $table);
		$FTEICSI = $query->num_rows();

		$where = array('dept_prio' => 'Teknologi Informasi');
		$query = $this->m_data->get_data($where, $table);
		$FTEICIT = $query->num_rows();

		$where = array('dept_prio' => 'Fisika');
		$query = $this->m_data->get_data($where, $table);
		$FSADFIS = $query->num_rows();

		$where = array('dept_prio' => 'Kimia');
		$query = $this->m_data->get_data($where, $table);
		$FSADKIM = $query->num_rows();

		$where = array('dept_prio' => 'Biologi');
		$query = $this->m_data->get_data($where, $table);
		$FSADBIO = $query->num_rows();

		$where = array('dept_prio' => 'Matematika');
		$query = $this->m_data->get_data($where, $table);
		$FSADMAT = $query->num_rows();

		$where = array('dept_prio' => 'Statistika');
		$query = $this->m_data->get_data($where, $table);
		$FSADST = $query->num_rows();

		$where = array('dept_prio' => 'Aktuaria');
		$query = $this->m_data->get_data($where, $table);
		$FSADAK = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Sipil');
		$query = $this->m_data->get_data($where, $table);
		$FTSPKTS = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Arsitektur');
		$query = $this->m_data->get_data($where, $table);
		$FTSPKTA = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Lingkungan');
		$query = $this->m_data->get_data($where, $table);
		$FTSPKTL = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Perencanaan Wilayah Kota');
		$query = $this->m_data->get_data($where, $table);
		$FTSPKTPWK = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Geomatika');
		$query = $this->m_data->get_data($where, $table);
		$FTSPKTGM = $query->num_rows();

		$where = array('dept_prio' => 'Teknik Geofisika');
		$query = $this->m_data->get_data($where, $table);
		$FTSPKTGF = $query->num_rows();

		if($FTIRSTM+$FTIRSTF+$FTIRSTSI+$FTIRSTMM+$FTIRSTK+$FTKTP+$FTKTSP+$FTKTK+$FTKTTL+$FDKBDDP+$FDKBDDKV+$FDKBDDI+$FDKBDMB+$FDKBDSP+$VokasiTIS+$VokasiTMI+$VokasiTEO+$VokasiTKI+$VokasiTI+$VokasiSB+$FTEICTE+$FTEICTB+$FTEICTK+$FTEICTI+$FTEICSI+$FTEICIT+$FSADFIS+$FSADKIM+$FSADBIO+$FSADMAT+$FSADST+$FSADAK+$FTSPKTS+$FTSPKTA+$FTSPKTL+$FTSPKTPWK+$FTSPKTGM+$FTSPKTGF < 6050){
			$data = array(
				'FTIRSTM' => $FTIRSTM,
				'FTIRSTF' => $FTIRSTF,
				'FTIRSTSI' => $FTIRSTSI,
				'FTIRSTMM' => $FTIRSTMM,
				'FTIRSTK' => $FTIRSTK,
				'FTKTP' => $FTKTP,
				'FTKTSP' => $FTKTSP,
				'FTKTK' => $FTKTK,
				'FTKTTL' => $FTKTTL,
				'FDKBDDP' => $FDKBDDP,
				'FDKBDDKV' => $FDKBDDKV,
				'FDKBDDI' => $FDKBDDI,
				'FDKBDMB' => $FDKBDMB,
				'FDKBDSP' => $FDKBDSP,
				'VokasiTIS' => $VokasiTIS,
				'VokasiTMI' => $VokasiTMI,
				'VokasiTEO' => $VokasiTEO,
				'VokasiTKI' => $VokasiTKI,
				'VokasiTI' => $VokasiTI,
				'VokasiSB' => $VokasiSB,
				'FTEICTE' => $FTEICTE,
				'FTEICTB' => $FTEICTB,
				'FTEICTK' => $FTEICTK,
				'FTEICTI' => $FTEICTI,
				'FTEICSI' => $FTEICSI,
				'FTEICIT' => $FTEICIT,
				'FSADFIS' => $FSADFIS,
				'FSADKIM' => $FSADKIM,
				'FSADBIO' => $FSADBIO,
				'FSADMAT' => $FSADMAT,
				'FSADST' => $FSADST,
				'FSADAK' => $FSADAK,
				'FTSPKTS' => $FTSPKTS,
				'FTSPKTA' => $FTSPKTA,
				'FTSPKTL' => $FTSPKTL,
				'FTSPKTPWK' => $FTSPKTPWK,
				'FTSPKTGM' => $FTSPKTGM,
				'FTSPKTGF' => $FTSPKTGF
			);
			return $data;
		} else {
			redirect('penuhopencampus');
		}

	}

	public function opencampus()
	{
		$this->session->sess_destroy();
		$data = $this->cek_jml();
		$this->load->view('opencampus/header');
		$this->load->view('opencampus/home_OC', $data);
		$this->load->view('opencampus/footer');
	}

	public function form_oc()
	{
		$this->session->sess_destroy();
		$data = $this->cek_jml();
		$this->load->view('opencampus/header');
		$this->load->view('opencampus/form_OC', $data);
		$this->load->view('opencampus/footer');
	}

	public function input_opencampus()
	{
		$email	= $this->input->post('email');
		$where	= array('email' => $email);
		$query	= $this->m_data->get_data($where, 'opencampus');
		$check	= $query->num_rows();

		if ($check == 1) {
			redirect('terdaftaropencampus');	
		} else {
			

			$nama		= $this->input->post('nama');
			$sekolah	= $this->input->post('sekolah');
			$hp			= $this->input->post('no_hp');
			$line		= $this->input->post('line');
			$info		= substr(implode(', ', $this->input->post('info')), 0);
			// $sesi		= substr(implode(', ', $this->input->post('sesi')), 0);

			$dept_prio = array();
			if (!empty($this->input->post('sesi-1'))) {
				array_push($dept_prio,$this->input->post('sesi-1'));
			} 
			if (!empty($this->input->post('sesi-2'))) {
				array_push($dept_prio,$this->input->post('sesi-2'));
			} 
			if (!empty($this->input->post('sesi-3'))) {
				array_push($dept_prio,$this->input->post('sesi-3'));
			} 
			if (!empty($this->input->post('sesi-4'))) {
				array_push($dept_prio,$this->input->post('sesi-4'));
			} 
			if (!empty($this->input->post('sesi-5'))) {
				array_push($dept_prio,$this->input->post('sesi-5'));
			} 
			if (!empty($this->input->post('sesi-6'))) {
				array_push($dept_prio,$this->input->post('sesi-6'));
			} 
			if (!empty($this->input->post('sesi-7'))) {
				array_push($dept_prio,$this->input->post('sesi-7'));
			}

			if ($this->input->post('lain') != NULL) {
				if(!empty($info)){
					$info = $info.', '.$this->input->post('lain');
				} else {
					$info = $this->input->post('lain');
				}
			}

			$config['file_name']			= 'bukti-'.$nama;
			$config['allowed_types']        = 'gif|jpg|png|pdf';

			$img = $this->upload->data('file_name');

			$data = array(
				'nama'		=>	$nama,
				'sekolah'	=>	$sekolah,
				'hp'		=>	$hp,
				'line'		=>	$line,
				'email'		=>	$email,
				'bukti'		=>	$img,
				'info'		=>	$info
				// 'sesi'		=>	$sesi,
				// 'dept_prio' =>	$dept_prio
			);

			$id_insert = $this->m_data->input_data_return_id($data,'opencampus');

			if (!is_null($id_insert)) {

				$sesi = $this->input->post('sesi');

				$num = strlen($id_insert);
				if($num == 1){
					$cid = "000".$id_insert;
				} else if($num == 2){
					$cid = "00".$id_insert;
				} else if($num == 3){
					$cid = "0".$id_insert;
				} else if($num == 4){
					$cid = $id_insert;
				}

				for ($i=0; $i < count($sesi) ; $i++) { 

					if ($dept_prio[$i] == 'Teknik Mesin') {
						$cdept = "001";
					} else if ($dept_prio[$i] == 'Teknik Fisika') {
						$cdept = "002";
					} else if ($dept_prio[$i] == 'Teknik Sistem dan Industri') {
						$cdept = "003";
					} else if ($dept_prio[$i] == 'Teknik Material dan Metalurgi') {
						$cdept = "004";
					} else if ($dept_prio[$i] == 'Teknik Kimia') {
						$cdept = "005";
					} else if ($dept_prio[$i] == 'Teknik Perkapalan') {
						$cdept = "006";
					} else if ($dept_prio[$i] == 'Teknik Sistem Perkapalan') {
						$cdept = "007";
					} else if ($dept_prio[$i] == 'Teknik Kelautan') {
						$cdept = "008";
					} else if ($dept_prio[$i] == 'Teknik Transportasi Laut') {
						$cdept = "009";
					} else if ($dept_prio[$i] == 'Desain Produk') {
						$cdept = "010";
					} else if ($dept_prio[$i] == 'Desain Komunikasi Visual') {
						$cdept = "011";
					} else if ($dept_prio[$i] == 'Desain Interior') {
						$cdept = "012";
					} else if ($dept_prio[$i] == 'Manajemen Bisnis') {
						$cdept = "013";
					} else if ($dept_prio[$i] == 'Studi Pembangunan') {
						$cdept = "014";
					} else if ($dept_prio[$i] == 'Teknik Infrastruktur Sipil') {
						$cdept = "015";
					} else if ($dept_prio[$i] == 'Teknik Mesin Industri') {
						$cdept = "016";
					} else if ($dept_prio[$i] == 'Teknik Elektro Otomasi') {
						$cdept = "017";
					} else if ($dept_prio[$i] == 'Teknik Kimia Industri') {
						$cdept = "018";
					} else if ($dept_prio[$i] == 'Teknik Instrumentasi') {
						$cdept = "019";
					} else if ($dept_prio[$i] == 'Statistika Bisnis') {
						$cdept = "020";
					} else if ($dept_prio[$i] == 'Teknik Elektro') {
						$cdept = "021";
					} else if ($dept_prio[$i] == 'Teknik Biomedik') {
						$cdept = "022";
					} else if ($dept_prio[$i] == 'Teknik Komputer') {
						$cdept = "023";
					} else if ($dept_prio[$i] == 'Teknik Informatika') {
						$cdept = "024";
					} else if ($dept_prio[$i] == 'Sistem Informasi') {
						$cdept = "025";
					} else if ($dept_prio[$i] == 'Teknologi Informasi') {
						$cdept = "026";
					} else if ($dept_prio[$i] == 'Fisika') {
						$cdept = "027";
					} else if ($dept_prio[$i] == 'Kimia') {
						$cdept = "028";
					} else if ($dept_prio[$i] == 'Biologi') {
						$cdept = "029";
					} else if ($dept_prio[$i] == 'Matematika') {
						$cdept = "030";
					} else if ($dept_prio[$i] == 'Statistika') {
						$cdept = "031";
					} else if ($dept_prio[$i] == 'Aktuaria') {
						$cdept = "032";
					} else if ($dept_prio[$i] == 'Teknik Sipil') {
						$cdept = "033";
					} else if ($dept_prio[$i] == 'Teknik Arsitektur') {
						$cdept = "034";
					} else if ($dept_prio[$i] == 'Teknik Lingkungan') {
						$cdept = "035";
					} else if ($dept_prio[$i] == 'Teknik Perencanaan Wilayah Kota') {
						$cdept = "036";
					} else if ($dept_prio[$i] == 'Teknik Geomatika') {
						$cdept = "037";
					} else if ($dept_prio[$i] == 'Teknik Geofisika') {
						$cdept = "038";
					} 

					// if ($sesi[$i] == 'sesi-1') {
					// 	$csesi = "01";
					// } else if ($sesi[$i] == 'sesi-2') {
					// 	$csesi = "02";
					// } else if ($sesi[$i] == 'sesi-3') {
					// 	$csesi = "03";
					// } else if ($sesi[$i] == 'sesi-4') {
					// 	$csesi = "04";
					// } else if ($sesi[$i] == 'sesi-5') {
					// 	$csesi = "05";
					// } else if ($sesi[$i] == 'sesi-6') {
					// 	$csesi = "06";
					// } else if ($sesi[$i] == 'sesi-7') {
					// 	$csesi = "07";
					// }

					// $no_reg = $csesi.$cdept.$cid."_".$nama;
					$no_reg = $cdept."_".$cid."_".$nama;

					$data = array(
						'id_user' => $id_insert,
						'no_regis' => $no_reg,
						'sesi' => $sesi[$i],
						'dept_prio' => $dept_prio[$i]
					);

					$this->m_data->input_data($data,'opencampus_sesi');
				}
			}

			$session = array(
				'email' => $email,
				'id_user' => $id_insert,
				'status' => 'success'
			);

			$this->session->set_userdata($session);

			redirect('hasilopencampus');
		}
	}


	public function search_opencampus()
	{
		$where	= array('email' => $this->input->post('email'));
		$query	= $this->m_data->get_data($where, 'opencampus');
		$check	= $query->num_rows();
		$value	= $query->row();

		if ($check == 1) {
			$session = array(
				'email' => $email,
				'id_user' => $value->id,
				'status' => 'success'
			);
			$this->session->set_userdata($session);
			redirect('hasilopencampus');		
		} else {
			redirect('hasilopencampus');
		}
	}

	public function opencampus_hasil()
	{
		if ($this->session->status == "success") {
			$data['status'] = "BERHASIL";
			// $data['dept_prio'] = $this->session->dept_prio;
			$where	= array('id_user' => $this->session->id_user);
			$query	= $this->m_data->get_data($where, 'opencampus_sesi');
			$data['link']	= $query->result();
		} else {
			$data['status'] = "GAGAL";
		}
		$this->load->view('opencampus/header');
		$this->load->view('opencampus/result_OC', $data);
		$this->load->view('opencampus/footer');
	}

	public function check_daftar_oc()
	{
		if ($this->session->status == "success") {
			$data['status'] = "BERHASIL";
		} else {
			$data['status'] = "GAGAL";
		}
		$this->load->view('opencampus/header');
		$this->load->view('opencampus/result_OC', $data);
		$this->load->view('opencampus/footer');
	}

	public function opencampus_available()
	{
		$this->load->view('opencampus/header');
		$this->load->view('opencampus/dupli_OC');
		$this->load->view('opencampus/footer');
	}

	public function close()
	{
		$this->load->view('opencampus/header');
		$this->load->view('opencampus/close_OC');
		$this->load->view('opencampus/footer');
	}
}
